﻿using UnityEngine;
using System.Collections;

public class Player : MonoBehaviour {

	public float speed = 10f;
	public float jumpPower = 350f;

	public Vector2 maxVelocity = new Vector2 (3, 5);

	public GameObject feetGameObject;
	private Feet feetClass;


	private Rigidbody2D body2d;
	void Awake(){
		feetClass = feetGameObject.GetComponent<Feet> ();
	}
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {

		Movment ();

	}
		
	void Movment(){
		
		var forceX = 0f;
		var forceY = 0f;

		var absValueX = Mathf.Abs (GetComponent<Rigidbody2D> ().velocity.x);
		var absValueY = Mathf.Abs (GetComponent<Rigidbody2D> ().velocity.y);



		if (Input.GetKey ("right")) {
		
			if (absValueX < maxVelocity.x) {
				forceX = speed;

			}
			GetComponent<Transform> ().localScale = new Vector3 (Mathf.Abs (GetComponent<Transform>().localScale.x), GetComponent<Transform>().localScale.y, GetComponent<Transform>().localScale.z);

		} else if (Input.GetKey ("left")) {
			if (absValueX < maxVelocity.x) {
				forceX = -speed;

			}
			GetComponent<Transform> ().localScale = new Vector3 (-Mathf.Abs (GetComponent<Transform> ().localScale.x), GetComponent<Transform> ().localScale.y, GetComponent<Transform> ().localScale.z);
		}

		if (Input.GetKey ("space")) {
			//Debug.Log ("ImHere");
			if(feetClass.standing){
				//Debug.Log ("Standing");

				if (absValueY < maxVelocity.y ) {
					forceY = jumpPower; 
				}
			}


		}
		GetComponent<Rigidbody2D> ().AddForce (new Vector2 (forceX, forceY));


	}








}
