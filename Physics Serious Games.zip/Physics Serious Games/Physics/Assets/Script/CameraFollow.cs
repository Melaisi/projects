﻿using UnityEngine;
using System.Collections;


public class CameraFollow : MonoBehaviour {

	public GameObject target;
	private Transform _t;
	public float zValue = -10;

	void Awake(){
		//GetComponent<Camera> ().orthographicSize = ((Screen.height / 2.0f) / 100f); //All the pixel art is 100 pixel for each unit in Unity
	}

	// Use this for initialization
	void Start () {
		_t = target.GetComponent<Transform> ().transform;
	}

	// Update is called once per frame
	void Update () {
		if(_t)
			GetComponent<Transform> ().position = new Vector3 (_t.position.x, _t.position.y, GetComponent<Transform>().position.z);
	}

}