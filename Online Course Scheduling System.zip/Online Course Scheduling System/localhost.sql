-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 12, 2013 at 02:45 AM
-- Server version: 5.5.24-log
-- PHP Version: 5.4.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `admin`
--
CREATE DATABASE `admin` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `admin`;

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `username` varchar(25) NOT NULL,
  `password` varchar(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `username`, `password`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3');
--
-- Database: `schedule2`
--
CREATE DATABASE `schedule2` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `schedule2`;

-- --------------------------------------------------------

--
-- Table structure for table `building`
--

CREATE TABLE IF NOT EXISTS `building` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `lab` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `building`
--

INSERT INTO `building` (`id`, `name`, `lab`) VALUES
(1, '1', 0),
(2, '2', 1);

-- --------------------------------------------------------

--
-- Table structure for table `class`
--

CREATE TABLE IF NOT EXISTS `class` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weekday_id` int(11) NOT NULL,
  `room_id` int(11) NOT NULL,
  `hour` int(11) NOT NULL,
  `groups_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `class`
--

INSERT INTO `class` (`id`, `weekday_id`, `room_id`, `hour`, `groups_id`) VALUES
(1, 1, 5, 8, 4),
(2, 1, 5, 9, 3),
(3, 1, 6, 9, 8),
(4, 1, 5, 10, 5),
(5, 1, 6, 10, 9),
(6, 1, 5, 11, 6),
(7, 1, 5, 13, 7),
(8, 1, 5, 14, 10);

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE IF NOT EXISTS `department` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `code` varchar(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `code` (`code`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`id`, `name`, `code`) VALUES
(1, 'computer science', 'CS'),
(2, 'computer network', 'CN'),
(3, 'computer information', 'CI');

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE IF NOT EXISTS `groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(10) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `class_type` varchar(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`,`subject_id`,`teacher_id`),
  KEY `class_type` (`class_type`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `name`, `subject_id`, `teacher_id`, `class_type`) VALUES
(3, 'G1', 6, 6, 'lecture'),
(4, 'G1', 7, 6, 'lecture'),
(5, 'G2', 6, 7, 'lecture'),
(6, 'G3', 6, 5, 'lecture'),
(7, 'G1', 6, 6, 'lab'),
(8, 'G2', 6, 5, 'lab'),
(9, 'G3', 6, 6, 'lab'),
(10, 'G1', 8, 5, 'lecture'),
(11, 'G1', 8, 5, 'lab');

-- --------------------------------------------------------

--
-- Table structure for table `level`
--

CREATE TABLE IF NOT EXISTS `level` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `name_2` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=29 ;

--
-- Dumping data for table `level`
--

INSERT INTO `level` (`id`, `name`) VALUES
(10, 'level 1'),
(13, 'level 2'),
(15, 'level 3'),
(17, 'level 4'),
(21, 'level 5');

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

CREATE TABLE IF NOT EXISTS `room` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `lab` tinyint(1) NOT NULL,
  `building_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `building_id` (`building_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `room`
--

INSERT INTO `room` (`id`, `name`, `lab`, `building_id`) VALUES
(5, 'ffrf', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE IF NOT EXISTS `subject` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `code` varchar(10) NOT NULL,
  `lecture_hour` int(3) DEFAULT '0',
  `lab_hour` int(3) DEFAULT '0',
  `level_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `level_id` (`level_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`id`, `name`, `code`, `lecture_hour`, `lab_hour`, `level_id`) VALUES
(6, 'sub56', 's5', 3, 5, 21),
(7, 'sub6', 'ds6', 5, 6, 17),
(8, 'sub3', 's3', 3, 0, 21);

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE IF NOT EXISTS `teacher` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `department_id` int(11) NOT NULL,
  `academic_disciplines` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `depatment_id` (`department_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`id`, `name`, `department_id`, `academic_disciplines`) VALUES
(5, 'RER', 3, 'ERER'),
(6, 'cnnn', 3, 'cnnn'),
(7, 'CSS', 1, 'cSSS'),
(8, 'Rfeek', 1, 'lecturer');

-- --------------------------------------------------------

--
-- Table structure for table `weekday`
--

CREATE TABLE IF NOT EXISTS `weekday` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `day` varchar(3) NOT NULL,
  `work` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `weekday`
--

INSERT INTO `weekday` (`id`, `day`, `work`) VALUES
(1, 'SAT', 1),
(2, 'SUN', 1),
(3, 'MON', 1),
(4, 'TUE', 1),
(5, 'WED', 1),
(6, 'TUE', 0),
(7, 'FRI', 0);

-- --------------------------------------------------------

--
-- Table structure for table `worktime`
--

CREATE TABLE IF NOT EXISTS `worktime` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `start` int(11) NOT NULL,
  `end` int(11) NOT NULL,
  `break` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `worktime`
--

INSERT INTO `worktime` (`id`, `start`, `end`, `break`) VALUES
(1, 8, 18, 12);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
