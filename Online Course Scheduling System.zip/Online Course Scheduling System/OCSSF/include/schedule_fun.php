<?php 
	// Genral //
	
	 
	if(!include_once("db.php")){
		die('There are some missing files ..');
	}
	
	// STATUS //
		function get_weekdays(){
			$db_con = $GLOBALS['con_schedule'];
			
			$sql="select * from weekday where weekday.work=1";
			
			if(!$result=mysql_query($sql,$db_con)){
					die('Mysql Query Error: '.mysql_error());
			}
			if(!$num_rows=mysql_num_rows($result)){
			
				echo "plese chose some days as work day from <a href='option.php'>option page</a> ";
				return 0;
			}
			while($row=mysql_fetch_assoc($result)){
				$weekdays[]= $row;
			}
			return $weekdays;
		}
		
		function get_worktime(){
			$db_con = $GLOBALS['con_schedule'];
			$sql="select * from  worktime LIMIT 1";
			if(!$result=mysql_query($sql,$db_con)){
					die('Mysql Query Error: '.mysql_error());
			}
			if(!$num_rows=mysql_num_rows($result)){
			
				echo "plese Add START , END , BREAK hour from <a href='option.php'>option page</a> ";
				return 0;
			}
			$row=mysql_fetch_assoc($result);
			
			return $row;
		}
		
		function get_room_num(){
			$db_con = $GLOBALS['con_schedule'];
			$sql="select COUNT( room.id ) as room_num from room";
			
			if(!$result=mysql_query($sql,$db_con)){
					die('Mysql Query Error: '.mysql_error());
			}
			
			if(!$num_rows=mysql_num_rows($result)){
			
				echo "plese Add room from <a href='room.php'>room page</a> ";
				return 0;
			}
			$row=mysql_fetch_assoc($result);
			return $row['room_num'];
			
			
		}
		
		function get_teacher_num(){
			$db_con = $GLOBALS['con_schedule'];
			$sql="select COUNT( teacher.id ) as teacher_num from teacher";
			
			if(!$result=mysql_query($sql,$db_con)){
					die('Mysql Query Error: '.mysql_error());
			}
			
			if(!$num_rows=mysql_num_rows($result)){
			
				echo "plese Add teacher from <a href='teacher.php'>teacher page</a> ";
				return 0;
			}
			$row=mysql_fetch_assoc($result);
			echo $row['teacher_num'];
			
		
		}
		
		function get_level_num(){
			$db_con = $GLOBALS['con_schedule'];
			$sql="select COUNT( level.id ) as level_num from level";
			
			if(!$result=mysql_query($sql,$db_con)){
					die('Mysql Query Error: '.mysql_error());
			}
			
			if(!$num_rows=mysql_num_rows($result)){
			
				echo "plese Add level from <a href='level.php'>level page</a> ";
				return 0;
			}
			$row=mysql_fetch_assoc($result);
			echo $row['level_num'];
			
		}
		
		function get_subject_num(){
			$db_con = $GLOBALS['con_schedule'];
			$sql="select COUNT( subject.id ) as subject_num from subject";
			
			if(!$result=mysql_query($sql,$db_con)){
					die('Mysql Query Error: '.mysql_error());
			}
			
			if(!$num_rows=mysql_num_rows($result)){
			
				echo "plese Add subject from <a href='subject.php'>subject page</a> ";
				return 0;
			}
			$row=mysql_fetch_assoc($result);
			echo $row['subject_num'];
			
		}
		
		function get_groups_num(){
			$db_con = $GLOBALS['con_schedule'];
			$sql="select COUNT( groups.id ) as group_num from groups";
			
			if(!$result=mysql_query($sql,$db_con)){
					die('Mysql Query Error: '.mysql_error());
			}
			
			if(!$num_rows=mysql_num_rows($result)){
			
				echo "plese Add group from <a href='group.php'>group page</a> ";
				return 0;
			}
			$row=mysql_fetch_assoc($result);
			echo $row['group_num'];
			
		}
		
		function get_lectures_hour(){
			//foreach (groups as group){
			//	lecture=subject_lecture_hour+subject_lab_hour;
			//	lectures=lectures+lecture
			//}
			$db_con = $GLOBALS['con_schedule'];
			$sql="select * from groups";
			if(!$result=mysql_query($sql,$db_con)){
					die('Mysql Query Error: '.mysql_error());
			}
			
			if(!$num_rows=mysql_num_rows($result)){
			
				echo "plese Add group from <a href='group.php'>group page</a> ";
				return 0;
			}
			while($row=mysql_fetch_assoc($result)){
				$groups[]=$row;
			}
			$lectures_hour=0;
			foreach($groups as $group){
				$sql="select subject.lecture_hour,subject.lab_hour from subject where subject.id=".$group['subject_id'];
				if(!$result=mysql_query($sql,$db_con)){
					die('Mysql Query Error: '.mysql_error());
				}
				$row=mysql_fetch_assoc($result);
				if($group['class_type']=="lab"){
					$lectures_hour=$lectures_hour+$row['lab_hour'];
					}
				else{
					$lectures_hour=$lectures_hour+$row['lecture_hour'];
				}
			}
			
			return $lectures_hour;
		}
		
		function get_avaliable_class(){
			$db_con = $GLOBALS['con_schedule'];
			
			$worktime=get_worktime();
			$weekdays =get_weekdays();
			$rooms = get_room_num();
			
			$dayhour=($worktime['end']-$worktime['break']-1)+($worktime['break']-$worktime['start']);
			$days=0;
			foreach($weekdays as $weekday ){$days++;} 
			
			return $avaliable_class= $days*$dayhour*$rooms;
			
		}
		
	// STEP_1 //
		function check_group_subjects_id(){
			$db_con = $GLOBALS['con_schedule'];
			$sql="select * from groups";
			
			$erorr_start="<br>These groups are missing subject_id plese delete it before go to next step. <br> <table>";
			
			if(!$result=mysql_query($sql,$db_con)){
				die('Mysql Query Error:197 '.mysql_error());
			}
			while($row=mysql_fetch_assoc($result)){
				$groups[]=$row;
			}
			
			foreach ($groups as $group ){
				
				
				$sql="select * from subject where id=".$group['subject_id']."";
				
				if(!$result=mysql_query($sql,$db_con)){
					die('Mysql Query Error:205 '.mysql_error());
				}
			
				if(!$num_rows=mysql_num_rows($result)){
			
					if($erorr_start){echo $erorr_start;}
					echo "		
								<tr>
									<td>".$group['name']."</td>
									<td>".$group['teacher_name']."</td>
									<td>
										
										<a href='group_remove.php?group_id=".$group['id']."'><img src='include/images/remove.png' title='remove this group' /></a>
									</td>
								</tr>
							";
					$erorr_start=0;
				}
				if(!$erorr_start){echo "</table>";}
			}
			return 0;
		}
		
		function check_group_teacher_id(){
			$db_con = $GLOBALS['con_schedule'];
			$sql="	select groups.id,groups.name,groups.subject_id,groups.teacher_id, subject.name as subject_name
					from groups
					LEFT JOIN subject ON groups.subject_id = subject.id
					ORDER BY groups.id ";
			$erorr_start="<br>These groups are missing teacher_id plese delete,edit it before go to next step. <br> <table>";
			if(!$result=mysql_query($sql,$db_con)){
				die('Mysql Query Error:237 '.mysql_error());
			}
			while($row=mysql_fetch_assoc($result)){
				$groups[]=$row;
			}
			
			
			
			foreach ($groups as $group ){
				$sql="select * from teacher where id=".$group['teacher_id']."";
				
				if(!$result=mysql_query($sql,$db_con)){
					die('Mysql Query Error:244 '.mysql_error());
				}
			
				if(!$num_rows=mysql_num_rows($result)){
					
					if($erorr_start){echo $erorr_start;}
					echo "		
								<tr>
									<td>".$group['name']."</td>
									<td>".$group['subject_name']."</td>
									<td>
										<a href='display_subject.php?display=".$subject['id']."'><img src='include/images/display.png' title='display subject information' /></a>
										<a href='subject_edit.php?subject_id".$subject['id']."'><img src='include/images/edit.png' title='edit this subject' /></a>
										<a href='subject_remove.php?subject_id=".$subject['id']."'><img src='include/images/remove.png' title='remove this subject' /></a>
									</td>
								</tr>
							";
					$erorr_start=0;
				}
			}
			return 0;
		}
		
		function check_subject_level_id(){
			$db_con = $GLOBALS['con_schedule'];
			$sql="select * from subject";
			
			$erorr_start="<br>These subject are missing level_id plese delete,edit it before go to next step. <br> <table>";
			
			if(!$result=mysql_query($sql,$db_con)){
				die('Mysql Query Error:274 '.mysql_error());
			}
			while($row=mysql_fetch_assoc($result)){
				$groups[]=$row;
			}
			foreach ($groups as $group ){
				$sql="select * from level where id=".$group['level_id'];
				
				if(!$result=mysql_query($sql,$db_con)){
					die('Mysql Query Error:282 '.mysql_error());
				}
			
				if(!$num_rows=mysql_num_rows($result)){
			
					if($erorr_start){echo $erorr_start;}
					echo "		
								<tr>
									<td>".$subject['name']."</td>
									<td>
										
										
									</td>
								</tr>
							";
					$erorr_start=0;
				}
				if(!$erorr_start){echo "</table>";}
			}
			return 0;
			
		}
		
		
	// Create // 
		function get_worktime_Hour(){
		
			$worktime=get_worktime();
			$start=(int)$worktime['start'];
			$break=(int)$worktime['break'];
			$end=(int)$worktime['end'];
			
			for($start;$start<=$end;$start++){
				if($start != $break){
					$hours[]=$start;
				}
				
			}
			return $hours;
		}
	//step1
		function is_status_checked(){
				if(isset($_SESSION['status']) == TRUE){
					return TRUE;
				}
				else{
					return FALSE;
				}
			}
	//create_Schedule 
		function is_step1_checked(){
				if(isset($_SESSION['step1']) == TRUE){
					return TRUE;
				}
				else{
					return FALSE;
				}
			}
	// class
	function get_classs(){
		$sql="	select 
				`class`.weekday_id, `class`.room_id, `class`.hour , `class`.groups_id,
				weekday.day , 
				room.lab as room_lab, room.name as room_name,
				groups.name as group_name, groups.subject_id,groups.teacher_id,groups.class_type,
				subject.name as subject_name ,subject.code as subject_code ,subject.lecture_hour,subject.lab_hour,subject.level_id,
				teacher.name as teacher_name,
				level.name as level_name
				From `class` 
				Left Join weekday on `class`.weekday_id=weekday.id
				Left Join room on `class`.room_id=room.id
				Left Join groups on `class`.groups_id=groups.id
				Left Join subject on groups.subject_id=subject.id
				Left Join teacher on groups.teacher_id=teacher.id
				Left Join level on subject.level_id=level.id"; 
		$db_con = $GLOBALS['con_schedule'];
		if(!$result=mysql_query($sql,$db_con)){
					die('Mysql Query Error: '.mysql_error());
		}
		if(!$num_rows=mysql_num_rows($result)){
				header( "Location: schedule_create.php" ) ;
			}
		while($row= mysql_fetch_assoc($result)){
			$classs[]=$row;
		}
		return $classs;
	}
?>
