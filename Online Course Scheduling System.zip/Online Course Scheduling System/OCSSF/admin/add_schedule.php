<?php
	if(!$_POST){
		header( "Location: schedule_create.php" ) ;
	}
	include_once('/include/functions.php');
	include_once('/include/schedule_fun.php');
	if(!is_admin_login()){
		redirct_to("index.php");
	}
	if(!$_POST['classArr'] || empty($_POST['classArr']) ){
		header( "Location: schedule_create.php" ) ;
	}
	
	$classArr=json_decode($_POST['classArr']);
	
	$weekdays 	= get_weekdays();
	$worktime 	= get_worktime_Hour();
	$rooms 		= get_rooms();
	
	$d=0;
	foreach($weekdays as $day_name => $day ){
		
		foreach($worktime as $hour){
	
		}
		foreach($rooms as $room_name => $room){
		
			foreach($worktime as $hour_name => $hour){
		  
			}		
		}
		$d++;
	}
	
	foreach($classArr as $day_num =>$day){
		
		foreach($day as $hour_num => $hour){
		
			foreach($hour as $room_num => $room){
				if($room){
				
					$d=$day_num +1;
					$lectures[]=array(
								"day" => $d,
								"room_id" =>$rooms[$room_num]['id'],
								"hour" => $worktime[$hour_num],
								"group_id" => $room->id,
								);
				}
			}
		}
	}
	
	$sql="TRUNCATE TABLE `class`;";
	$db_con = $GLOBALS['con_schedule'];
		if(!$result=mysql_query($sql,$db_con)){
					die('Mysql Query Error: '.mysql_error());
			}
	
	$sql = "INSERT INTO `schedule2`.`class` ( `weekday_id`, `room_id`, `hour`, `groups_id`) VALUES ";
	$i=1;
	foreach($lectures as $lecture){
		
		$sql=$sql."(".$lecture['day'].",".$lecture['room_id'].",".$lecture['hour'].",".$lecture['group_id'].")";
		if($i==count($lectures)){
			$sql=$sql.";";
		}
		else{
			$sql=$sql.",";
		}
		$i++;
	}
	
	$db_con = $GLOBALS['con_schedule'];
		if(!$result=mysql_query($sql,$db_con)){
					die('Mysql Query Error: '.mysql_error());
		}
	header( "Location: schedule_Display.php" )
?>