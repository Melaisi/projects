<!doctype html>
<?php
	include_once('/include/functions.php');
	if(!is_admin_login()){
		header( 'Location: index.php' ) ;
	}
	$add_room_error="";
	
	if(isset($_POST['room_name'])){
		if(!$add_room_error=check_add_room()){
			
			
			redirct_to("room.php");
		}
	}
	
	
?>



<html>
	<head>
		<title>Add room</title>
		<link href="include/style.css" rel="stylesheet" />
	</head>
	<body>
	<?php
		include_once('/include/header.html');
		include_once('/include/navbar.html');
		?>
		<div id="content">
			<div id="form_add_room">
				<div id="title">Add Room</div>
				<form id="add_room" action="" method="POST" class="align_left">
					<?php 
					if ($buildings=get_buildings()){ ?>
					Room Name : <input id="room_name" name="room_name" type="text" /><br />
					
					Select building : <select name="room_building">
					<?php 
							foreach($buildings as $building){
								if($building['lab']==0){
						?>
							<option value="<?php echo $building['name']; ?>"><?php echo $building['name'];?></option>
					<?php 
								}
							} ?>
					
					</select> <br />
					<input type="hidden" name="lab" value="false" />
					<input id="add_room_submit" type="submit" />
					<?php 
					} 
					else { ?>
						<p class="error_input">There are no building stored in database plese Add at least one building from :<a href="add_building.php">Add building page</a></p>
					<?php 
					} ?>
				</form>
				<p class="error_input"><?php echo $add_room_error;  ?></p>
			</div>
			
		</div>
	</body>
</html>