<!doctype html>
<?php
	include_once('/include/functions.php');
	if(!is_admin_login()){
		header( 'Location: index.php' ) ;
	}
	$edit_teacher_error="";
	
	if(!isset($_GET['teacher_id'])){
			redirct_to("teacher.php?error=get");
	}
	
	//elseif(isset($_POST['teacher_id'])){
		if(!$teacher_info=get_teacher($_GET['teacher_id'])){
			redirct_to("teacher.php?error=info");
		}
	//}
	if(isset($_POST['teacher_name'])){
		if(!$edit_teacher_error=check_edit_teacher()){
			redirct_to("teacher.php");
		}
	}
?>



<html>
	<head>
		<title>edit teacher</title>
		<link href="include/style.css" rel="stylesheet" />
	</head>
	<body>
	<?php
		include_once('/include/header.html');
		include_once('/include/navbar.html');
		?>
		<div id="content">
			<div id="form_edit_teacher">
				<div id="title">Edit Teacher</div>
				<form id="edit_teacher" action="" method="POST" class="align_left">
					<?php 
					if ($departments=get_departments()){ ?>
					Teacher Name : <input id="teacher_name" name="teacher_name" value="<?php echo $teacher_info['name']; ?>"  type="text" /><br />
					
					Select department : <select name="teacher_department">
					<?php 
							foreach($departments as $department){
						?>
							<option value="<?php echo $department['code']; ?>" <?php if($department['code']==$teacher_info['code']){echo "selected='selected'";}?>><?php echo $department['code'];?></option>
					<?php 
							} ?>
					
					</select> <br />
					
					Teacher academic disciplines : <input id="teacher_academic_disciplines" name="teacher_academic_disciplines" value="<?php echo $teacher_info['academic_disciplines']; ?>" type="text" /><br />
					
					<input type="hidden" name="teacher_id" value="<?php echo $_GET['teacher_id']; ?>" /> 
					<input id="edit_teacher_submit" type="submit" />
					<?php 
					} 
					else { ?>
						There are no department stored in database plese Add at least one department from :<a href="add_department.php">Add department page</a>
					<?php 
					} ?>
				</form>
			<p class="error_input"><?php echo $edit_teacher_error;  ?></p>
			</div>
			
		</div>
	</body>
</html>