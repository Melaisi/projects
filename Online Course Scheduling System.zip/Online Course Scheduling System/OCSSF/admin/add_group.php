<!doctype html>
<?php
	include_once('/include/functions.php');
	if(!is_admin_login()){
		header( 'Location: index.php' ) ;
	}
	$add_group_error="";
	
	if(isset($_POST['group_name'])){
		if(!$add_group_error=check_add_group()){
			
			
			redirct_to("display_subject.php?display=".$_POST['subject_id']);
		}
	}
	if(!isset($_GET['subject_id'])){
		redirct_to("subject.php?error=17");
	}
	if(!$subject_info=check_subject_exist($_GET['subject_id'])){
			
			
			redirct_to("subject.php?error=22");
	}
?>



<html>
	<head>
		<title>Add Group</title>
		<link href="include/style.css" rel="stylesheet" />
	</head>
	<body>
	<?php
		include_once('/include/header.html');
		include_once('/include/navbar.html');
		?>
		<div id="content">
			<div id="form_add_group">
				<div id="title">Add Group</div>
				<form id="add_group" action="" method="POST"  class="align_left">
					<?php 
					if ($teachers=get_teachers()){ ?>
					Group Name : <input id="group_name" name="group_name" type="text" /><br />
					<input type="hidden" name="subject_id" value="<?php echo $subject_info['id']; ?>" />
					Class type:
					<br><input type="radio" name="class_type" value="lecture" <?php if(isset($_GET['class_type'])){if($_GET['class_type']=="lecture"){echo " checked='yes'";}} ?>>lecture
					<br><input type="radio" name="class_type" value="lab" <?php if(isset($_GET['class_type'])){if($_GET['class_type']=="lab"){echo " checked='yes'";}} ?>>lab
					<br>Select Teacher : <select name="teacher_id">
					<?php 
							foreach($teachers as $teacher){
						?>
							<option value="<?php echo $teacher['id']; ?>"><?php echo $teacher['name'];?></option>
					<?php 
							} ?>
					
					</select> <br />
					
					<input id="add_group_submit" type="submit" />
					<?php 
					} 
					else { ?>
						<p class="error_input">There are no teacher stored in database plese Add at least one teacher from :<a href="add_teacher.php">Add teacher page</a></p>
					<?php 
					} ?>
				</form>
			<p class="error_input"><?php echo $add_group_error;  ?></p>
			</div>
			
		</div>
	</body>
</html>