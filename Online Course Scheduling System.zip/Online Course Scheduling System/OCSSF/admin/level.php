<!doctype html>
<?php
	
	include_once('/include/functions.php');
	if(!is_admin_login()){
		redirct_to("index.php");
	}
?>
<html>
	<head>
		<title>Level</title>
		<link href="include/style.css" rel="stylesheet" />
	</head>
	<body>
	<?php
		include_once('/include/header.html');
		include_once('/include/navbar.html');
		?>
		<div id="content">
			<div id="level_list">
				<div id="title">Levels List</div>
				<table id="level_list_table">
					<tr id="header">
						<th>LeveL Name</th>
						<th>Number of subjects</th>
						<th>Actions</th>
					</tr>
					
						<?php 
							if($levels=get_levels()){
							
								foreach($levels as $level){
						?>	<tr id="">
							<td><?php echo $level['name']; ?></td>
							<td><?php echo $level['subject_number']; ?></td>
							<td>
								<a href="display_level.php?display=<?php echo $level['id'];?>"><img src="include/images/display.png" title="display level information" /></a>
								<a href="level_remove.php?level_id=<?php echo $level['id'];?>"><img src="include/images/remove.png" title="remove this level" /></a>
							</td>
							</tr>
						<?php
								}
							}
							else {
						?>
							<tr>
								<td><p class="error_input">there are no level stored in db, plese add a new level!</p></td>
							</tr>
						<?php
							}
							
						?>
					</tr>
					<tr id="footer">
						<td><a href="add_level.php"><img src="include/images/add.png" title="Add new level" /></a></td>
					</tr>
				</table>
			</div>
			
		</div>
	</body>
</html>