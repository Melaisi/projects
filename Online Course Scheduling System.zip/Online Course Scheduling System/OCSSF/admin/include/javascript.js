var lvl,sub,grp,sel,selObj;
var inf;
var lvlVis,subVis,grpVis;
var can=0;
var visTeacher;
//conflict 
//[teacher_id][Day][Hour]

function selGrp(o){
	if(grpVis[o.a][o.b][o.c]==1){
		o.c++;
		if(group[o.a][o.b][o.c])
			selGrp(o);
		return;
	}
	var x=document.getElementsByClassName("el");
	for(var i=0;i<x.length;++i)
		document.getElementById(x[i].id).style.backgroundColor="#F9F9F9";
	document.getElementById(o.a+"A").style.backgroundColor="lightgreen";
	document.getElementById(o.b+"B").style.backgroundColor="lightgreen";
	document.getElementById(o.c+"C").style.backgroundColor="lightgreen";
	
	sel=o;
	selObj=group[o.a][o.b][o.c];
	
	display_GroupInfo(selObj,sel);
	conflict_teacher(selObj.teacher_id);
	
}
function selSub(o){
	if(subVis[o.a][o.b]==1){
		o.b++;
		if(subject[o.a][o.b])
			selSub(o);
		return;
	}
	grp.innerHTML="";
	for(var i=0;i<group[o.a][o.b].length;++i)
		if(grpVis[o.a][o.b][i]!=1)
			grp.innerHTML+="<div id='"+i.toString()+"C'class='el' onclick='selGrp({"+'"a":'+o.a.toString()+',"b":'+o.b.toString()+',"c":'+"parseInt(this.id)});'>"+group[o.a][o.b][i].name+"</div>";
	selGrp({"a":o.a,"b":o.b,"c":0});
}
function selLvl(o){
	sub.innerHTML="";
	for(var i=0;i<subject[o].length;++i)
		if(subVis[o][i]!=1)
			sub.innerHTML+="<div id='"+i.toString()+"B'class='el' onclick='selSub({"+'"a":'+o.toString()+',"b":'+"parseInt(this.id)});'>"+subject[o][i]+"</div>";
	selSub({"a":o,"b":0});
}
function update(){
	for(var i=0;i<level.length;++i){
		var f2=0;
		for(var j=0;j<subject[i].length;++j){
			var f3=0;
			for(var k=0;k<group[i][j].length;++k)
				f3=f3||grpVis[i][j][k]!=1;
			f2=f2||f3;
			if(f3==0)
				subVis[i][j]=1;
			else
				subVis[i][j]=0;
		}
		if(f2==0)
			lvlVis[i]=1;
		else
			lvlVis[i]=0;
	}
	lvl.innerHTML="";
	sub.innerHTML="";
	grp.innerHTML="";
	for(var i=0;i<level.length;++i)
		if(lvlVis[i]!=1)
			lvl.innerHTML+="<div id='"+i.toString()+"A'class='el' onclick='selLvl(parseInt(this.id));'>"+level[i]+"</div>";
}
function selectFirst(){
	can=0;
	update();
	for(var i=0;i<level.length;++i){
		if(lvlVis[i]!=1)
		for(var j=0;j<subject[i].length;++j){
			if(subVis[i][j]!=1)
			for(var k=0;k<group[i][j].length;++k){
				if(grpVis[i][j][k]!=1){
					selLvl(i);
					selSub({"a":i,"b":j});
					selGrp({"a":i,"b":j,"c":k});
					return;
				}
			}
		}
	}
	
	can =1;
	GroupDetails=document.getElementById('group_details');
	 if(can==1){
		GroupDetails.innerHTML="Thanks To Add All subjects if you want to save the table plese click on add to database butoon:";
		GroupDetails.innerHTML+="<br />";
		GroupDetails.innerHTML+="<button  type='button' value='' onclick='SendToDatabase()'>Add to Database</button>";
	}
}
function info(o){
	if(o.innerHTML=="-")
		return;
	eval("var zz="+o.id+";");
	/*inf.style.left=o.offsetLeft-o.scrollLeft+180;
	inf.style.top=o.offsetTop-o.scrollTop+170;*/
	inf.innerHTML="Level: "+level[zz.a];
	inf.innerHTML+="<br />";
	inf.innerHTML+="Subject: "+subject[zz.a][zz.b];
	inf.innerHTML+="<br />";
	inf.innerHTML+="Name: "+group[zz.a][zz.b][zz.c].name;
	inf.innerHTML+="<br />";
	inf.innerHTML+="Time: "+group[zz.a][zz.b][zz.c].class_time;
	inf.innerHTML+="<br />";
	inf.innerHTML+="Teacher: "+group[zz.a][zz.b][zz.c].teacher_name;
	inf.style.display="block";
	//inf.innerHTML+="<br />And all other info...";
}
function hide(o){
	inf.style.display="none";
}
function add(o){
	
	if(o.id!=""){
		o.innerHTML="-";
		eval("var zz="+o.id+";");
		o.id="";
		
		hide(o);
		grpVis[zz.a][zz.b][zz.c]=0;
		eval("var cell_name="+o.getAttribute("name"));
		classs[cell_name.d][cell_name.t][cell_name.r]=null;
		o.style.boxShadow="inset 0px 0px 12px 1px lightblue";
		selectFirst();
		return;
	}
	if(o.id=="red")
		return;
	if(can==1){
		return;
	}
	if(conflict_teacher = check_teacher_conflict(o,selObj)){
		alert(" There are another class for this teacher at this time, find another time plese ");
		return ;
	}
	if(conflict_level_group=check_level_group_conflict(o,selObj)){
		alert(" There are another class for this teacher at this time, find another time plese ");
		return ;
	}
	grpVis[sel.a.toString()][sel.b.toString()][sel.c.toString()]=1;
	o.id="{'a':"+sel.a.toString()+",'b':"+sel.b.toString()+",'c':"+sel.c.toString()+"}";
	o.style.boxShadow="inset 0px -5px 19px 6px lightgreen";
	o.innerHTML=selObj.subject_name;
	
	eval("var cell_name="+o.getAttribute("name"));
	classs[cell_name.d][cell_name.t][cell_name.r]=selObj;
	selectFirst();	
	info(o);
}
window.onload=function(){
	inf=document.getElementById("inf");
	lvlVis=new Array(level.length);
	subVis=new Array(level.length);
	grpVis=new Array(level.length);
	for(var i=0;i<lvlVis.length;++i){
		lvlVis[i]=0;
		subVis[i]=new Array(subject[i].length);
		grpVis[i]=new Array(subject[i].length);
		for(var j=0;j<subject[i].length;++j){
			subVis[i][j]=0;
			grpVis[i][j]=new Array(group[i][j].length);
			for(var k=0;k<grpVis[i][j].length;++k)
				grpVis[i][j][k]=0;
		}
	}
	visTeacher=new Array(max_id);
	for(var i=0;i<max_id;++i){
		visTeacher[i]=new Array(day_length);
		for(var k=0;k<day_length;++k){
		visTeacher[i][k]=new Array(hour_length);
		
		}
	}
	lvl=document.getElementById('level');
	sub=document.getElementById('subject');
	grp=document.getElementById('group');
	selectFirst();
};
function display_GroupInfo(selObj,sel){
	if(can==1){
		return;
	}
	
	
	GroupDetails=document.getElementById('group_details');
	GroupDetails.innerHTML="Level: "+level[sel.a];
	GroupDetails.innerHTML+="<br />";
	GroupDetails.innerHTML+="Subject: "+subject[sel.a][sel.b];
	GroupDetails.innerHTML+="<br />";
	GroupDetails.innerHTML+="Name: "+group[sel.a][sel.b][sel.c].name;
	GroupDetails.innerHTML+="<br />";
	GroupDetails.innerHTML+="Time: "+group[sel.a][sel.b][sel.c].class_time;
	GroupDetails.innerHTML+="<br />";
	GroupDetails.innerHTML+="Teacher: "+group[sel.a][sel.b][sel.c].teacher_name;
	GroupDetails.innerHTML+="<br />";
	GroupDetails.innerHTML+="class type: "+group[sel.a][sel.b][sel.c].class_type;
}

function SendToDatabase(){
	document.getElementById("classArr").value=JSON.stringify(classs);
	
	document.getElementById("classs").submit();
	
}
function check_teacher_conflict(o,selObj){
	eval("var cell_name="+o.getAttribute("name"));
	for(var r=0;r<room_length;r++){
		if(classs[cell_name.d][cell_name.t][r] != null){
			if(classs[cell_name.d][cell_name.t][r].teacher_id == selObj.teacher_id){
				return true;
			}
		}
	}
	return false;

}
function check_level_group_conflict(o,selObj){
	eval("var cell_name="+o.getAttribute("name"));
	for(var r=0;r<room_length;r++){
		if(classs[cell_name.d][cell_name.t][r] != null){
			if(classs[cell_name.d][cell_name.t][r].level_id == selObj.level_id && 
				classs[cell_name.d][cell_name.t][r].name == selObj.name ){
				return true;
			}
		}
	}
	return false;
}
