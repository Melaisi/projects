<?php 
	// Genral //
	
	session_start(); 
	if(!include_once("db.php")){
		die('There are some missing files ..');
	}
	
		//login 
			function is_admin_login(){
				if(isset($_SESSION['logged']) == TRUE){
					return TRUE;
				}
				else{
					return FALSE;
				}
			}
			
			function create_login_seesion(){
				echo $_SESSION['logged']= TRUE;
			}
	
	function redirct_to($page){
		header( "Location: $page" ) ;
	}
	
	////////////////////////////////////////////////////////////////////////
	// valid //
	
	function valid_login($input_value,$input_type=""){
		if(empty($input_value)){
			return "empty input : $input_type";
		}
		$input_value =preg_replace(array('/\s{2,}/', '/[\t\n]/'), ' ', $input_value);
		$input_value=stripslashes($input_value);
		if(preg_match("/[^A-z|^0-9|\\s]/",$input_value)){
			return $error=$input_type." should contain only alphaptical charachter or number or single space";
		}
		if ($input_value ==" "){
			return "plese enter level name !";
		}
		else{
			return "";
		}
	}
	
	function valid_level($level_name){
		if(empty($level_name)){
			return "plese enter level name !";
		}
		$level_name =preg_replace(array('/\s{2,}/', '/[\t\n]/'), ' ', $level_name);
		$level_name=stripslashes($level_name);
		if(preg_match("/[^A-z|^0-9|\\s]/",$level_name)){
			return $error="level name should contain only alphaptical charachter or number or single space";
		}
		if ($level_name ==" "){
			return "plese enter level name !";
		}
		else{
			return "";
		}
	}
	
	function valid_id($id,$input_type=""){
		
		if(empty($id)){
			return "empty input : $input_type";
		}
		$id =preg_replace(array('/\s{2,}/', '/[\t\n]/'), ' ', $id);
		$id=stripslashes($id);
		if(preg_match("/[^0-9]/",$id)){
			return $error=$input_type." id should contain only number";
		}
		if ($id ==" "){
			return "plese enter level name !";
		}
		else{
			return "";
		}
		
	}
	
	function valid_number($number,$input_type=""){
		
		if($number == NULL){
			return "empty input : $input_type";
		}
		$id =preg_replace(array('/\s{2,}/', '/[\t\n]/'), ' ', $id);
		$number=stripslashes($number);
		if(preg_match("/[^0-9]/",$number)){
			return $error=$input_type." should contain only number";
		}
		if ($number ==" "){
			return "plese enter level name !";
		}
		else{
			return "";
		}
		
	}
	
	function valid_teacher($input_value,$input_type="") {
		
		if(empty($input_value)){
			return "empty input : $input_type";
		}
		$input_value =preg_replace(array('/\s{2,}/', '/[\t\n]/'), ' ', $input_value);
		$input_value=stripslashes($input_value);
		
		if(preg_match("/[^A-z|^0-9|\\s]/",$input_value)){
			$error="".$input_type." should contain only alphaptical charachter or number or single space";
			return $error;
		}
		if ($input_value ==" "){
			return "plese enter level name !";
		}
		else{
			return false;
		}
	}
	
	function valid_name($input_value,$input_type="") {
		
		if(empty($input_value)){
			return "empty input : $input_type";
		}
		$input_value =preg_replace(array('/\s{2,}/', '/[\t\n]/'), ' ', $input_value);
		$input_value=stripslashes($input_value);
		if(preg_match("/[^A-z|^0-9|\\s]/",$input_value)){
			$error="".$input_type." should contain only alphaptical charachter or number or single space";
			return $error;
		}
		if ($input_value ==" "){
			return "plese enter level name !";
		}
		else{
			return false;
		}
	}
	
	function valid_bolean($input_value,$input_type=""){
		
		if(empty($input_value)){
			return "empty input : $input_type";
		}
		$input_value =preg_replace(array('/\s{2,}/', '/[\t\n]/'), ' ', $input_value);
		$input_value=stripslashes($input_value);
		if(($input_value == "false") || ($input_value == "true")){
			return false;
		}
		
		else{
			$error="".$input_type." should contain only bolean value 1 or 0 ";
			return $error;
		}
	}
	
	function valid_class_type($class_type){
		if(empty($class_type)){
			return "empty input : $input_type";
		}
		$class_type =preg_replace(array('/\s{2,}/', '/[\t\n]/'), ' ', $class_type);
		$class_type=stripslashes($class_type);
		if(($class_type == "lecture") || ($class_type == "lab")){
			return false;
		}
		else{
			$error="".$input_type." should contain only (lecture or lab) ";
			return $error;
		}
		
	}
	//////////////////////////////////////////////////////////////////////////
	
	// db //
	
		//login
			function login_db_check($username,$password){
				// global var //
				$db_con = $GLOBALS['con_admin'];
				
				$sql_check_login="select id from login where username='".$username."' AND password=MD5('".$password."')";
				if(!$result= mysql_query($sql_check_login,$db_con))
				{
					die('Could not connect whith database '.mysql_error());
				}
				if(!$row = mysql_fetch_assoc($result)){
					return $db_error="The username or the password is wrong plese try again!";
				}
				else {
					return false;
				}
			}
		
		// levels
			function get_levels(){
					$db_con = $GLOBALS['con_schedule'];
					$sql="SELECT level.id,level.name FROM level";
					
					if(!$result = mysql_query($sql,$db_con)){
						die('Mysql Query Error: '.mysql_error());
					}
					
					if(!$num_rows=mysql_num_rows($result)){
						return false;
					}
					while($row= mysql_fetch_assoc($result)){
					
						$sql_get_subject_num="select count(subject.level_id) as subject_number from subject where ".$row['id']."=subject.level_id";
						if(!$result2=mysql_query($sql_get_subject_num,$db_con)){
							die('Mysql Query Error: '.mysql_error());
						}
						if(!$level_subject_num=mysql_fetch_assoc($result2)){
							$levels[]=array(
										'id'	=>$row['id'],
										'name'	=>$row['name'],
										'subject_number'=>0);
						}
						else{
							$levels[]=array(
										'id'	=>$row['id'],
										'name'	=>$row['name'],
										'subject_number'=>$level_subject_num['subject_number']);
						}
						
					}
					return $levels;
			}
	
			function db_add_level($level_name){
				
				// global var //
				$db_con = $GLOBALS['con_schedule'];
				
				$sql_add_level="insert into level (name) values ('".$level_name."')";
				$sql_check_if_exist="select id from level where name='".$level_name."'";
				
				if(!$result = mysql_query($sql_check_if_exist,$db_con)){
					
					die('Could not connect whith database error in check '.mysql_error());
				}
				if($row=mysql_fetch_assoc($result)){
					
					return "the level is alredy exist !!";
				}
				
				if(!$result = mysql_query($sql_add_level,$db_con)){
					
					die('Could not connect whith database error in add'.mysql_error());
				}
				return false;
			}
	
			function get_level_subject($level_ID){
				
				// global var //
				$db_con = $GLOBALS['con_schedule'];
				
				$sql_subject_info =" Select * from subject where level_id=".$level_ID." ";
				if(!$result = mysql_query($sql_subject_info,$db_con)){
					
					die('error in query '.mysql_error());
				}
				
				if(!$row=mysql_fetch_assoc($result)){
					
					return false;
				}
				$level_subject[]=array(
										'id'=>$row['id'],
										'code'=>$row['name'],
										'name'=>$row['code']
										);
				while($row=mysql_fetch_assoc($result)){
					$level_subject[]=array(
										'id'=>$row['id'],
										'code'=>$row['name'],
										'name'=>$row['code']
										);
				}
				return $level_subject;
			
			}
	
			function check_level_exist($level_id){
				// global var //
				$db_con = $GLOBALS['con_schedule'];
				$sql_check_if_exist="select * from level where id='".$level_id."'";
				
				if(!$result = mysql_query($sql_check_if_exist,$db_con)){
					
					die('Could not connect whith database error in check '.mysql_error());
				}
				if($row=mysql_fetch_assoc($result)){
					$level_info=array('id'=>$row['id'], 'name' =>$row['name']);
					return $level_info;
				}
				return false;
			}	
	
			function remove_level ($level_id){
				// global var //
				$db_con = $GLOBALS['con_schedule'];
				$sql_delete_level="delete from level where id='".$level_id."'";
				
				if(!$result = mysql_query($sql_delete_level,$db_con)){
					
					die('Could not connect whith database error in check '.mysql_error());
				}
				if(mysql_affected_rows() !=1 ){
					return false;
				}
				if(mysql_affected_rows() == -1){
					return false;
				} 
				return true;
			}
	
		// teachers 
			function get_teachers(){
				$db_con = $GLOBALS['con_schedule'];
				$sql="SELECT 
				teacher.id, teacher.name, teacher.academic_disciplines, department.code
				FROM teacher
				LEFT JOIN department ON teacher.department_id = department.id
				ORDER BY teacher.id ";
				
				if(!$result=mysql_query($sql,$db_con)){
					die('Mysql Query Error: '.mysql_error());
				}
				if(!$num_rows=mysql_num_rows($result)){
						return false;
				}
				while($row= mysql_fetch_assoc($result)){
					
					$sql_get_subject_num="select DISTINCT count(groups.subject_id) as subject_number from groups where groups.teacher_id=".$row['id'];
					if(!$result2=mysql_query($sql_get_subject_num,$db_con)){
						die('Mysql Query Error: '.mysql_error());
					}
					if(!$teacher_subject_num=mysql_fetch_assoc($result2)){
						$teachers[]=array(
									'id'	=>$row['id'],
									'name'	=>$row['name'],
									'department'=>$row['code'],
									'academic_disciplines'=>$row['academic_disciplines'],
									'subject_number'=>0);
					}
					else{
						$teachers[]=array(
									'id'	=>$row['id'],
									'name'	=>$row['name'],
									'department'=>$row['code'],
									'academic_disciplines'=>$row['academic_disciplines'],
									'subject_number'=>$teacher_subject_num['subject_number']);
					}
						
				}
				return $teachers;
			}
			
			function db_add_teacher($teacher_name,$teacher_department_code,$teacher_academic_disciplines){
				
				// global var //
				$db_con = $GLOBALS['con_schedule'];
				
				
				$sql_check_if_exist="select id from teacher where name='".$teacher_name."'";
				
				$sql_check_department_code="SELECT * FROM department WHERE code='".$teacher_department_code."'";
				
				if(!$result = mysql_query($sql_check_if_exist,$db_con)){
					
					die('Could not connect whith database error in check '.mysql_error());
				}
				if($row=mysql_fetch_assoc($result)){
					
					return "the teacher is alredy exist !!";
				}
				if(!$result = mysql_query($sql_check_department_code,$db_con)){
					
					die('Could not connect whith database error in check '.mysql_error());
				}
				if(!$row=mysql_fetch_assoc($result)){
					
					return "the department is not exist !!";
				}
				$teacher_department_id=$row['id'];
				$sql_add_teacher="
					insert into teacher 
					(name,department_id,academic_disciplines)
					values 
					('".$teacher_name."','".$teacher_department_id."','".$teacher_academic_disciplines."')";
					
				if(!$result = mysql_query($sql_add_teacher,$db_con)){
					
					die('Could not connect whith database error in add'.mysql_error());
				}
				return false;
			}
			
			function db_edit_teacher($teacher_id,$teacher_name,$teacher_department_code,$teacher_academic_disciplines){
				
				// global var //
				$db_con = $GLOBALS['con_schedule'];
				
				
				$sql_check_if_exist="select * from teacher where id='".$teacher_id."'";
				
				$sql_check_department_code="SELECT * FROM department WHERE code='".$teacher_department_code."'";
				
				if(!$result = mysql_query($sql_check_if_exist,$db_con)){
					
					die('Error Query sql_check_if_exist: '.mysql_error());
				}
				if(!$row_teacher=mysql_fetch_assoc($result)){
					
					return "the teacher is Not exist !!";
				}
				if(!$result = mysql_query($sql_check_department_code,$db_con)){
					
					die('Error sql_check_department_code '.mysql_error());
				}
				if(!$row_department=mysql_fetch_assoc($result)){
					
					return "the department is not exist !!";
				}
				$teacher_department_id=$row_department['id'];
				$sql_edit_teacher="
					UPDATE teacher SET 
					teacher.name='".$teacher_name."',
					teacher.department_id='".$teacher_department_id."',
					teacher.academic_disciplines='".$teacher_academic_disciplines."' 
					WHERE teacher.id=".$row_teacher['id']."";
					
				if(!$result = mysql_query($sql_edit_teacher,$db_con)){
					
					die('Error in Edit Teacher: '.mysql_error());
				}
				
					return false;
			
			}
			
			
			function get_teacher($teacher_id){
				if(!$error=valid_id($teacher_id,"teacher")){
					// global var //
					$db_con = $GLOBALS['con_schedule'];
					
					$sql_get_teacher="SELECT teacher.id, teacher.name, teacher.academic_disciplines, department.code
						FROM teacher
						LEFT JOIN department ON teacher.department_id = department.id
						where teacher.id=".$teacher_id;
					if(!$result=mysql_query($sql_get_teacher,$db_con)){
						die('Query Error'.mysql_error());
					}
					if(!$num_rows=mysql_num_rows($result)){
						
						
						return false;
					}
					else{
						if(!$row=mysql_fetch_assoc($result)){
							die('Error in fetch teacher information'.mysql_error());
						}
						$teacher_info=array(	
							'id'=>$row['id'],
							'name'=>$row['name'],
							'academic_disciplines'=>$row['academic_disciplines'],
							'code'=>$row['code']);
						return $teacher_info;
					}
					
					
				}
				echo "vslidate";
				return false;
			}
			
			function check_teacher_exist($teacher_id){
				
				if($teacher_id_error=valid_id($teacher_id,"teacher_id")){
					return false;
				}
				
				// global var //
				$db_con = $GLOBALS['con_schedule'];
				$sql_check_if_exist="select * from teacher where id='".$teacher_id."'";
				
				if(!$result = mysql_query($sql_check_if_exist,$db_con)){
					
					die('check teacher exist errro '.mysql_error());
				}
				if($row=mysql_fetch_assoc($result)){
					$teacher_info=array('id'=>$row['id'], 'name' =>$row['name']);
					return $teacher_info;
				}
				return false;
			}	
			
			function remove_teacher ($teacher_id){
				// global var //
				$db_con = $GLOBALS['con_schedule'];
				$sql_delete_teacher="delete from teacher where id='".$teacher_id."'";
				
				if(!$result = mysql_query($sql_delete_teacher,$db_con)){
					
					die('Query Error in sql delete teacher '.mysql_error());
				}
				if(mysql_affected_rows() !=1 ){
					return false;
				}
				if(mysql_affected_rows() == -1){
					return false;
				} 
				return true;
			}
		
		// department
			function get_departments(){
				$db_con = $GLOBALS['con_schedule'];
				$sql="Select * from department ";
				
				if(!$result=mysql_query($sql,$db_con)){
					die('Mysql Query Error: '.mysql_error());
				}
				if(!$num_rows=mysql_num_rows($result)){
					return false;
				}
				while($row=mysql_fetch_assoc($result)){
					$departments[]=array(
						'id' => $row['id'],
						'code'=>$row['code'],
						'name'=>$row['name'],
					);
				}
				return $departments;
			}
			
		//Rooms
			function get_rooms(){
				$db_con = $GLOBALS['con_schedule'];
				$sql="SELECT 
				room.id, room.name, room.lab, building.name as building_name
				FROM room
				LEFT JOIN building ON room.building_id = building.id
				ORDER BY room.id ";
				
				if(!$result=mysql_query($sql,$db_con)){
					die('Mysql Query Error: '.mysql_error());
				}
				if(!$num_rows=mysql_num_rows($result)){
						return false;
				}
				while($row= mysql_fetch_assoc($result)){
					
					$rooms[]=array(
									'id'	=>$row['id'],
									'name'	=>$row['name'],
									'lab'=>$row['lab'],
									'building_name'=>$row['building_name']);
				}
				return $rooms;
			}
			
			function db_add_room($room_name,$room_building_name,$room_lab){
				
				// global var //
				$db_con = $GLOBALS['con_schedule'];
				
				if($room_lab=="true"){
					$room_lab=1;
				}
				else{
					$room_lab=0;
				}
				$sql_check_if_exist="select id from room where name='".$room_name."'";
				
				$sql_check_building_code="SELECT * FROM building WHERE name='".$room_building_name."'";
				
				if(!$result = mysql_query($sql_check_if_exist,$db_con)){
					
					die('Query Error in check room_building_code : '.mysql_error());
				}
				if($row=mysql_fetch_assoc($result)){
					
					return "the room is alredy exist !!";
				}
				if(!$result = mysql_query($sql_check_building_code,$db_con)){
					
					die('Query Error in sql_check_building_code '.mysql_error());
				}
				if(!$row=mysql_fetch_assoc($result)){
					
					return "the building is not exist !!";
				}
				$room_building_id=$row['id'];
				$sql_add_room="
					insert into room 
					(name,lab,building_id)
					values 
					('".$room_name."','".$room_lab."','".$room_building_id."')";
					
				if(!$result = mysql_query($sql_add_room,$db_con)){
					
					die('Query error in add room'.mysql_error());
				}
				return false;
			}
			
			function get_room($room_id){
				if(!$error=valid_id($room_id,"room")){
					// global var //
					$db_con = $GLOBALS['con_schedule'];
					
					$sql_get_room="SELECT room.id, room.name, room.lab, building.name as building_name
						FROM room
						LEFT JOIN building ON room.building_id = building.id
						where room.id=".$room_id;
					if(!$result=mysql_query($sql_get_room,$db_con)){
						die('Query Error'.mysql_error());
					}
					if(!$num_rows=mysql_num_rows($result)){
						die('num rows');
						
						return false;
					}
					else{
						if(!$row=mysql_fetch_assoc($result)){
							die('Error in fetch room information'.mysql_error());
						}
						if($row['lab']==1){
							$row['lab'] = "true";
						}
						elseif($row['lab']==0){
							$row['lab'] = "false";
						}
						
						$room_info=array(	
									'id'	=>$row['id'],
									'name'	=>$row['name'],
									'lab'	=>$row['lab'],
									'building_name'=>$row['building_name']);
						return $room_info;
					}
					
					
				}
				//echo "vslidate";
				return false;
			}
			
			function db_edit_room($room_id,$room_name,$room_building_name,$room_lab){
				
				// global var //
				$db_con = $GLOBALS['con_schedule'];
				
				if($room_lab=="true"){
					$room_lab=1;
				}
				else{
					$room_lab=0;
				}
				
				$sql_check_if_exist="select * from room where id='".$room_id."'";
				
				$sql_check_building_name="SELECT * FROM building WHERE name='".$room_building_name."'";
				
				if(!$result = mysql_query($sql_check_if_exist,$db_con)){
					
					die('Error Query sql_check_if_exist: '.mysql_error());
				}
				if(!$row_room=mysql_fetch_assoc($result)){
					
					return "the room is Not exist !!";
				}
				if(!$result = mysql_query($sql_check_building_name,$db_con)){
					
					die('Error sql_check_building_name '.mysql_error());
				}
				if(!$row_building=mysql_fetch_assoc($result)){
					
					return "the department is not exist !!";
				}
				$room_building_id=$row_building['id'];
				$sql_edit_room="
					UPDATE room SET 
					room.name='".$room_name."',
					room.building_id='".$room_building_id."',
					room.lab='".$room_lab."' 
					WHERE room.id=".$row_room['id']."";
					
				if(!$result = mysql_query($sql_edit_room,$db_con)){
					
					die('Error in Edit Room: '.mysql_error());
				}
				
					return false;
			
			}
			
			function check_room_exist($room_id){
				
				if($room_id_error=valid_id($room_id,"room_id")){
					return false;
				}
				
				// global var //
				$db_con = $GLOBALS['con_schedule'];
				$sql_check_if_exist="select * from room where id='".$room_id."'";
				
				if(!$result = mysql_query($sql_check_if_exist,$db_con)){
					
					die('check room exist error '.mysql_error());
				}
				if($row=mysql_fetch_assoc($result)){
					$room_info=array('id'=>$row['id'], 'name' =>$row['name']);
					return $room_info;
				}
				return false;
			}	
			
			function remove_room ($room_id){
				// global var //
				$db_con = $GLOBALS['con_schedule'];
				$sql_delete_room="delete from room where id='".$room_id."'";
				
				if(!$result = mysql_query($sql_delete_room,$db_con)){
					
					die('Query Error in sql delete room '.mysql_error());
				}
				if(mysql_affected_rows() !=1 ){
					return false;
				}
				if(mysql_affected_rows() == -1){
					return false;
				} 
				return true;
			}
			
		// building
			function get_buildings(){
				$db_con = $GLOBALS['con_schedule'];
				$sql="Select * from building ";
				
				if(!$result=mysql_query($sql,$db_con)){
					die('Mysql Query Error: '.mysql_error());
				}
				if(!$num_rows=mysql_num_rows($result)){
					return false;
				}
				while($row=mysql_fetch_assoc($result)){
					$buildings[]=array(
						'id' => $row['id'],
						'name'=>$row['name'],
						'lab'=>$row['lab'],
					);
				}
				
				return $buildings;
			}
		
		//subject
		
			function get_subjects(){
				$db_con = $GLOBALS['con_schedule'];
				$sql="
				SELECT subject.id, subject.name, subject.code, subject.lecture_hour, subject.lab_hour, level.name as level_name
				FROM subject
				LEFT JOIN level ON subject.level_id = level.id
				ORDER BY subject.id ";
				
				if(!$result=mysql_query($sql,$db_con)){
					die('Mysql Query Error: '.mysql_error());
				}
				if(!$num_rows=mysql_num_rows($result)){
						return false;
				}
				while($row= mysql_fetch_assoc($result)){
					
					$sql_get_group_num="
					SELECT COUNT( groups.id ) AS subject_number
					FROM groups
					WHERE groups.subject_id =".$row['id'];
					if(!$result2=mysql_query($sql_get_group_num,$db_con)){
						die('Mysql Query Error: '.mysql_error());
					}
					if(!$subject_group_num=mysql_fetch_assoc($result2)){
						$subjects[]=array(
									'id'	=>$row['id'],
									'name'	=>$row['name'],
									'code'	=>$row['code'],
									'lecture_hour'		=>$row['lecture_hour'],
									'lab_hour'		=>$row['lab_hour'],
									'level_name'=>$row['level_name'],
									'group_number'=>0);
					}
					else{
						$subjects[]=array(
									'id'	=>$row['id'],
									'name'	=>$row['name'],
									'code'	=>$row['code'],
									'lecture_hour'		=>$row['lecture_hour'],
									'lab_hour'		=>$row['lab_hour'],
									'level_name'=>$row['level_name'],
									'group_number'=>$subject_group_num['subject_number']);
					}
						
				}
				return $subjects;
			}
			
			function db_add_subject($subject_name,$subject_code,$subject_lecture_hour,$subject_lab_hour,$subject_level_name){
				
				// global var //
				$db_con = $GLOBALS['con_schedule'];
				
				
				$sql_check_if_exist="select id from subject where name='".$subject_name."'";
				
				$sql_check_level_name="SELECT * FROM level WHERE name='".$subject_level_name."'";
				
				if(!$result = mysql_query($sql_check_if_exist,$db_con)){
					
					die('Could not connect whith database error in check '.mysql_error());
				}
				if($row=mysql_fetch_assoc($result)){
					
					return "the subject is alredy exist !!";
				}
				if(!$result = mysql_query($sql_check_level_name,$db_con)){
					
					die('Could not connect whith database error in check '.mysql_error());
				}
				if(!$row=mysql_fetch_assoc($result)){
					
					return "the level is not exist !!";
				}
				$subject_level_id=$row['id'];
				$sql_add_subject="
					insert into subject 
					(name,code,lecture_hour,lab_hour,level_id)
					values 
					('".$subject_name."','".$subject_code."','".$subject_lecture_hour."','".$subject_lab_hour."','".$subject_level_id."')";
					
				if(!$result = mysql_query($sql_add_subject,$db_con)){
					
					die('Could not connect whith database error in add'.mysql_error());
				}
				return false;
			}
			
			function get_subject($subject_id){
				if(!$error=valid_id($subject_id,"subject")){
					// global var //
					$db_con = $GLOBALS['con_schedule'];
					
					$sql_get_subject="SELECT subject.id, subject.name, subject.code, subject.lecture_hour, subject.lab_hour,  level.name as level_name
						FROM subject
						LEFT JOIN level ON subject.level_id = level.id
						where subject.id=".$subject_id;
					if(!$result=mysql_query($sql_get_subject,$db_con)){
						die('Query Error'.mysql_error());
					}
					if(!$num_rows=mysql_num_rows($result)){
						
						return false;
					}
					else{
						if(!$row=mysql_fetch_assoc($result)){
							die('Error in fetch subject information'.mysql_error());
						}
						$subject_info=array(
									'id'	=>$row['id'],
									'name'	=>$row['name'],
									'code'	=>$row['code'],
									'lecture_hour'=>$row['lecture_hour'],
									'lab_hour'=>$row['lab_hour'],
									'level_name'=>$row['level_name']);
						return $subject_info;
					}
					
					
				}
				
				return false;
			}
			
			function db_edit_subject($subject_id,$subject_name,$subject_code,$subject_lecture_hour,$subject_lab_hour,$subject_level_name){
				
				// global var //
				$db_con = $GLOBALS['con_schedule'];
				
				
				$sql_check_if_exist="select * from subject where id='".$subject_id."'";
				
				$sql_check_level_name="SELECT * FROM level WHERE name='".$subject_level_name."'";
				
				if(!$result = mysql_query($sql_check_if_exist,$db_con)){
					
					die('Error Query sql_check_if_exist: '.mysql_error());
				}
				if(!$row_subject=mysql_fetch_assoc($result)){
					
					return "the subject is Not exist !!";
				}
				if(!$result = mysql_query($sql_check_level_name,$db_con)){
					
					die('Error sql_check_level_name '.mysql_error());
				}
				if(!$row_level=mysql_fetch_assoc($result)){
					
					return "the level is not exist !! subject_level_name=".$subject_level_name;
				}
				$subject_level_id=$row_level['id'];
				$sql_edit_subject="
					UPDATE subject SET 
					subject.name='".$subject_name."',
					subject.code='".$subject_code."',
					subject.lecture_hour='".$subject_lecture_hour."',
					subject.lab_hour='".$subject_lab_hour."',
					subject.level_id='".$subject_level_id."'
					WHERE subject.id=".$row_subject['id']."";
					
				if(!$result = mysql_query($sql_edit_subject,$db_con)){
					
					die('Error in Edit Subject: '.mysql_error());
				}
				
					return false;
			
			}
	
			function check_subject_exist($subject_id){
				// global var //
				if($subject_id_error=valid_id($subject_id,"subject_id")){
					return false;
				}
				
				$db_con = $GLOBALS['con_schedule'];
				$sql_check_if_exist="
					SELECT subject.id, subject.name, subject.code, subject.lecture_hour, subject.lab_hour,  level.name as level_name
					FROM subject
					LEFT JOIN level ON subject.level_id = level.id
					where subject.id=".$subject_id."";
				
				if(!$result = mysql_query($sql_check_if_exist,$db_con)){
					
					die('check subject exist errro '.mysql_error());
				}
				if($row=mysql_fetch_assoc($result)){
					
					$sql_get_group_num="
					SELECT COUNT( groups.id ) AS subject_number
					FROM groups
					WHERE groups.subject_id =".$row['id'];
					
					if(!$result2=mysql_query($sql_get_group_num,$db_con)){
						die('Mysql Query Error: '.mysql_error());
					}
					if(!$subject_group_num=mysql_fetch_assoc($result2)){
						
						$subject_info=array(
									'id'			=>$row['id'],
									'name'			=>$row['name'],
									'code'			=>$row['code'],
									'lecture_hour'	=>$row['lecture_hour'],
									'lab_hour'		=>$row['lab_hour'],
									'level_name'	=>$row['level_name'],
									'group_number'	=>0);
					}
					else{
						
						$subject_info=array(
									'id'			=>$row['id'],
									'name'			=>$row['name'],
									'code'			=>$row['code'],
									'lecture_hour'	=>$row['lecture_hour'],
									'lab_hour'		=>$row['lab_hour'],
									'level_name'	=>$row['level_name'],
									'group_number'	=>$subject_group_num['subject_number']);
					}
					
					
					return $subject_info;
				}
				return false;
			}	
			
			function remove_subject ($subject_id){
				// global var //
				$db_con = $GLOBALS['con_schedule'];
				$sql_delete_subject="delete from subject where id='".$subject_id."'";
				$sql_delete_groups="delete from groups where subject_id=".$subject_id;
				
				if(!$result = mysql_query($sql_delete_subject,$db_con)){
					
					die('Query Error in sql delete subject '.mysql_error());
				}
				if(mysql_affected_rows() !=1 ){
					return false;
				}
				if(mysql_affected_rows() == -1){
					return false;
				} 
				
				if(!$result = mysql_query($sql_delete_groups,$db_con)){
					
					die('Query Error in sql delete subject '.mysql_error());
				}
				
				return true;
			}
			
		//groups
			
			function get_groups($subject_id){
				if($subject_id_error=valid_id($subject_id,"subject_id"))
				{
					return false;
				}
				$db_con = $GLOBALS['con_schedule'];
				$sql="
				SELECT 
					groups.id,
					groups.name,
					groups.subject_id,
					groups.teacher_id,
					groups.class_type,
					teacher.name as teacher_name
				FROM groups
				LEFT JOIN teacher ON groups.teacher_id = teacher.id
				WHERE groups.subject_id = ".$subject_id." 
				ORDER BY groups.id ";
				
				if(!$result=mysql_query($sql,$db_con)){
					die('Mysql Query Error: '.mysql_error());
				}
				if(!$num_rows=mysql_num_rows($result)){
						return false;
				}
				while($row= mysql_fetch_assoc($result)){
					
					$groups[]=array(
									'id'	=>$row['id'],
									'name'	=>$row['name'],
									'subject_id'	=>$row['subject_id'],
									'teacher_id'		=>$row['teacher_id'],
									'class_type'		=>$row['class_type'],
									'teacher_name'		=>$row['teacher_name']);
				}
				
				return $groups;
			}
			
			function db_add_group($subject_id,$group_name,$teacher_id,$class_type){
				
				// global var //
				$db_con = $GLOBALS['con_schedule'];
				
				
				$sql_check_if_exist="select id from groups where name='".$group_name."' AND subject_id =".$subject_id." AND class_type='".$class_type."'";
				
				$sql_check_subject_id="SELECT * FROM subject WHERE id=".$subject_id;
				
				$sql_check_teacher_id="SELECT * FROM teacher WHERE id=".$teacher_id;
				
				
				if(!$result = mysql_query($sql_check_subject_id,$db_con)){
					
					die('Could not connect whith database error in check '.mysql_error());
				}
				if(!$subject_info=mysql_fetch_assoc($result)){
					
					return "the subject is not exist !!";
				}
				
				if(!$result = mysql_query($sql_check_teacher_id,$db_con)){
					
					die('Could not connect whith database error in check '.mysql_error());
				}
				if(!$teacher_info=mysql_fetch_assoc($result)){
					
					return "the teacher is not exist !!";
				}
				
				if(!$result = mysql_query($sql_check_if_exist,$db_con)){
					
					die('Error: Query sql_check_if_exist ! '.mysql_error());
				}
				if($row=mysql_fetch_assoc($result)){
					
					return "the group is alredy exist !!";
				}
				
				
				$sql_add_group="
					insert into groups 
					(name,subject_id,teacher_id,class_type)
					values 
					('".$group_name."','".$subject_id."','".$teacher_id."','".$class_type."')";
					
				if(!$result = mysql_query($sql_add_group,$db_con)){
					
					die('Could not connect whith database error in add'.mysql_error());
				}
				return false;
				
			
			}
			
			function get_group($group_id){
				if(!$error=valid_id($group_id,"group_id")){
					// global var //
					$db_con = $GLOBALS['con_schedule'];
					
					$sql_get_group="
									SELECT 
										groups.id,
										groups.name,
										groups.subject_id,
										groups.teacher_id,
										groups.class_type,
										teacher.name as teacher_name
									FROM groups
									LEFT JOIN teacher ON groups.teacher_id = teacher.id
									WHERE groups.id = ".$group_id;
					if(!$result=mysql_query($sql_get_group,$db_con)){
						die('Query Error'.mysql_error());
					}
					if(!$num_rows=mysql_num_rows($result)){
						
						
						return false;
					}
					else{
						if(!$row=mysql_fetch_assoc($result)){
							die('Error in fetch subject information'.mysql_error());
						}
						$group_info=array(
									'id'	=>$row['id'],
									'name'	=>$row['name'],
									'subject_id'	=>$row['subject_id'],
									'teacher_id'		=>$row['teacher_id'],
									'class_type'		=>$row['class_type'],
									'teacher_name'		=>$row['teacher_name']);
						return $group_info;
					}
					
					
				}
				
				return false;
			}
			
			function db_edit_group($group_id,$subject_id,$group_name,$teacher_id,$class_type){
				
				// global var //
				$db_con = $GLOBALS['con_schedule'];
				
				
				$sql_check_if_exist="select id from groups where id=".$group_id;
				
				$sql_check_subject_id="SELECT * FROM subject WHERE id=".$subject_id;
				
				$sql_check_teacher_id="SELECT * FROM teacher WHERE id=".$teacher_id;
				
				if(!$result = mysql_query($sql_check_if_exist,$db_con)){
					
					die('Error: Query sql_check_if_exist ! '.mysql_error());
				}
				if(!$row=mysql_fetch_assoc($result)){
					
					return "the group is not exist !!";
				}
				
				if(!$result = mysql_query($sql_check_subject_id,$db_con)){
					
					die('Could not connect whith database error in check '.mysql_error());
				}
				if(!$subject_info=mysql_fetch_assoc($result)){
					
					return "the subject is not exist !!";
				}
				
				if(!$result = mysql_query($sql_check_teacher_id,$db_con)){
					
					die('Could not connect whith database error in check '.mysql_error());
				}
				if(!$teacher_info=mysql_fetch_assoc($result)){
					
					return "the teacher is not exist !!";
				}
				
				$sql_edit_groups="
					UPDATE groups SET 
					groups.name='".$group_name."',
					groups.subject_id='".$subject_id."',
					groups.teacher_id='".$teacher_id."',
					groups.class_type='".$class_type."'
					WHERE groups.id=".$group_id;
					
				if(!$result = mysql_query($sql_edit_groups,$db_con)){
					
					die('Could not connect whith database error in edit'.mysql_error());
				}
				return false;
				
			
			}
			
			function check_group_exist($group_id){
				// global var //
				$db_con = $GLOBALS['con_schedule'];
				$sql_check_if_exist="
									SELECT 
										groups.id,
										groups.name,
										groups.subject_id,
										groups.teacher_id,
										groups.class_type,
										teacher.name as teacher_name
									FROM groups
									LEFT JOIN teacher ON groups.teacher_id = teacher.id
									WHERE groups.id = ".$group_id;
				
				if(!$result = mysql_query($sql_check_if_exist,$db_con)){
					
					die('check teacher exist errro '.mysql_error());
				}
				if($row=mysql_fetch_assoc($result)){
					$group_info=array(
									'id'	=>$row['id'],
									'name'	=>$row['name'],
									'subject_id'	=>$row['subject_id'],
									'teacher_id'		=>$row['teacher_id'],
									'class_type'		=>$row['class_type'],
									'teacher_name'		=>$row['teacher_name']);
					return $group_info;
				}
				return false;
			}	
			
			function remove_group ($group_id){
				// global var //
				$db_con = $GLOBALS['con_schedule'];
				$sql_delete_group="delete from groups where id=".$group_id;
				
				if(!$result = mysql_query($sql_delete_group,$db_con)){
					
					die('Query Error in sql delete group '.mysql_error());
				}
				if(mysql_affected_rows() !=1 ){
					return false;
				}
				if(mysql_affected_rows() == -1){
					return false;
				} 
				return true;
			}
			
	//////////////////////////////////////////////////////////////
	// check // 
	
		//login
			function check_admin_login(){
				$admin_username= $_POST['admin_username'];
				$admin_password= $_POST['admin_password'];
				$db_error="";
				$username_erorr= valid_login($admin_username,"username");
				$password_error= valid_login($admin_password,"password");
				if(!$username_erorr && !$password_error)
				{
					if(!$db_error=login_db_check($admin_username,$admin_password)){
						return false;
					}
				}
				
				$login_erorr =array(	'username_erorr'=>$username_erorr,
										'password_error'=>$password_error,
										'db_error'		=>$db_error);
				
				return $login_erorr;
			}
		
		//level
			function check_add_level(){
				$level_name=$_POST['level_name'];
				$level_name_erorr="";
				$db_error="";
				if(!$level_name_erorr=valid_level($level_name)){
					if(!$db_error=db_add_level($level_name)){
						return false;
					}
					else {
						return $db_error;
					}
				}
				return $level_name_erorr;
			}
	
			function check_level_valid(){
				if(!$valid_level_error=valid_id($_GET['display'],"level")){
					return false;
				}
				else{
					return "there are no level by this id plece try other one !";
				}
			}
		//teacher
		
			function check_add_teacher(){
				$add_teacher_error="";
				if((!isset($_POST['teacher_name'])) || (!isset($_POST['teacher_department'])) || (!isset($_POST['teacher_academic_disciplines']))){
					return $add_teacher_error="plese fill all field before submit..";
				}
				
				$teacher_name=$_POST['teacher_name'];
				$teacher_department_code=$_POST['teacher_department'];
				$teacher_academic_disciplines=$_POST['teacher_academic_disciplines'];
				
				$name_error="";
				$department_error="";
				$academic_error="";
				$db_error="";
				$name_error=valid_teacher($teacher_name,"name");
				$department_error=valid_teacher($teacher_department_code,"department code");
				$academic_error=valid_teacher($teacher_academic_disciplines,"academic disciplines");
				
				if(!$name_error && !$department_error && !$academic_error ){
						if(!$db_error=db_add_teacher($teacher_name,$teacher_department_code,$teacher_academic_disciplines)){
							return false;
						}
						else {
							return $db_error;
						}
					}
				$add_teacher_error=$name_error."</br>".$department_error."</br>".$academic_error;
				return $add_teacher_error;
			}
			
			function check_edit_teacher(){
				$edit_teacher_error="";
				if((!isset($_POST['teacher_id'])) || (!isset($_POST['teacher_name'])) || (!isset($_POST['teacher_department'])) || (!isset($_POST['teacher_academic_disciplines']))){
					return $edit_teacher_error="plese fill all field before submit..";
				}
				
				$teacher_id=$_POST['teacher_id'];
				$teacher_name=$_POST['teacher_name'];
				$teacher_department_code=$_POST['teacher_department'];
				$teacher_academic_disciplines=$_POST['teacher_academic_disciplines'];
				
				$teacher_id_error="";
				$name_error="";
				$department_error="";
				$academic_error="";
				$db_error="";
				
				$teacher_id_error=valid_id($teacher_id,"teacher id");
				$name_error=valid_teacher($teacher_name,"name");
				$department_error=valid_teacher($teacher_department_code,"department code");
				$academic_error=valid_teacher($teacher_academic_disciplines,"academic disciplines");
				
				if(!$teacher_id_error && !$name_error && !$department_error && !$academic_error ){
						if(!$db_error=db_edit_teacher($teacher_id,$teacher_name,$teacher_department_code,$teacher_academic_disciplines)){
							return false;
						}
						else {
							return $db_error;
						}
					}
				$edit_teacher_error=$teacher_id_error."</br>".$name_error."</br>".$department_error."</br>".$academic_error;
				return $edit_teacher_error;
			
			}
			
		//room
		
			function check_add_room(){
				$add_room_error="";
				if((!isset($_POST['room_name'])) || (!isset($_POST['room_building'])) || (!isset($_POST['lab']))){
					return $add_room_error="plese fill all field before submit..";
				}
				
				$room_name=$_POST['room_name'];
				$room_building_name=$_POST['room_building'];
				$room_lab=$_POST['lab'];
				
				$name_error="";
				$building_error="";
				$lab_error="";
				$db_error="";
				$name_error=valid_name($room_name,"name");
				$building_error=valid_id($room_building_name,"department name");
				$lab_error=valid_bolean($room_lab,"room lab");
				
				if(!$name_error && !$building_error && !$lab_error ){
						if(!$db_error=db_add_room($room_name,$room_building_name,$room_lab)){
							return false;
						}
						else {
							return $db_error;
						}
					}
				$add_room_error=$name_error."</br>".$building_error."</br>".$lab_error;
				return $add_room_error;
			}
			
			function check_edit_room(){
				$edit_room_error="";
				if((!isset($_POST['room_id'])) || (!isset($_POST['room_name'])) || (!isset($_POST['room_building'])) || (!isset($_POST['lab']))){
					return $edit_room_error="plese fill all field before submit..";
				}
				
				$room_id=$_POST['room_id'];
				$room_name=$_POST['room_name'];
				$room_building_name=$_POST['room_building'];
				$room_lab=$_POST['lab'];
				
				$room_id_error="";
				$name_error="";
				$building_error="";
				$lab_error="";
				$db_error="";
				
				$room_id_error=valid_id($room_id,"room id");
				$name_error=valid_name($room_name,"name");
				$building_error=valid_id($room_building_name,"department name");
				$lab_error=valid_bolean($room_lab,"room lab");
				
				if(!$room_id_error && !$name_error && !$building_error && !$lab_error){
						if(!$db_error=db_edit_room($room_id,$room_name,$room_building_name,$room_lab)){
							return false;
						}
						else {
							return $db_error;
						}
					}
				$edit_room_error=$room_id_error."</br>".$name_error."</br>".$building_error."</br>".$lab_error;
				return $edit_room_error;
			
			}

		//subject
		
			function check_add_subject(){
				$add_subject_error="";
				if((!isset($_POST['subject_name'])) || (!isset($_POST['subject_code'])) || (!isset($_POST['subject_level'])) 
					|| (!isset($_POST['subject_lecture_hour'])) || (!isset($_POST['subject_lab_hour']))){
					return $add_subject_error="plese fill all field before submit..";
				}
				
				$subject_name=$_POST['subject_name'];
				$subject_code=$_POST['subject_code'];
				$subject_lecture_hour=$_POST['subject_lecture_hour'];
				$subject_lab_hour=$_POST['subject_lab_hour'];
				$subject_level=$_POST['subject_level'];
				
				$name_error	="";
				$code_error	="";
				$lecture_hour_error="";
				$lab_hour_error="";
				$level_error="";
				$db_error	="";
				
				$name_error	=valid_name($subject_name,"name");
				$code_error	=valid_name($subject_code,"subject code");
				$lecture_hour_error=valid_number($subject_lecture_hour,"lecture hour");
				$lab_hour_error=valid_number($subject_lab_hour,"lab hour");;
				$level_error=valid_name($subject_level,"Level name");
				
				if(!$name_error && !$code_error && !$lecture_hour_error && !$lab_hour_error && !$level_error ){
						if(!$db_error=db_add_subject($subject_name,$subject_code,$subject_lecture_hour,$subject_lab_hour,$subject_level)){
							return false;
						}
						else {
							return $db_error;
						}
					}
				$add_subject_error=$name_error."</br>".$code_error."</br>".$lecture_hour_error."</br>".$lab_hour_error."</br>".$level_error;
				return $add_subject_error;
			}
			
			function check_edit_subject(){
				$edit_subject_error="";
				if((!isset($_POST['subject_id'])) || (!isset($_POST['subject_name'])) || (!isset($_POST['subject_code'])) || (!isset($_POST['subject_level']))
					|| (!isset($_POST['subject_lecture_hour'])) || (!isset($_POST['subject_lab_hour']))){
					return $edit_subject_error="plese fill all field before submit..";
				}
				
				$subject_id=$_POST['subject_id'];
				$subject_name=$_POST['subject_name'];
				$subject_code=$_POST['subject_code'];
				$subject_lecture_hour=$_POST['subject_lecture_hour'];
				$subject_lab_hour=$_POST['subject_lab_hour'];
				$subject_level=$_POST['subject_level'];
				
				$id_error	="";
				$name_error	="";
				$code_error	="";
				$lecture_hour_error="";
				$lab_hour_error="";
				$level_error="";
				$db_error	="";
				
				$id_error	=valid_id($subject_id,"subject");
				$name_error	=valid_name($subject_name,"name");
				$code_error	=valid_name($subject_code,"subject code");
				$lecture_hour_error=valid_number($subject_lecture_hour,"lecture hour");
				$lab_hour_error=valid_number($subject_lab_hour,"lab hour");;
				$level_error=valid_name($subject_level,"Level name");
				
				if(!$id_error && !$name_error && !$code_error && !$lecture_hour_error && !$lab_hour_error && !$level_error ){
						if(!$db_error=db_edit_subject($subject_id,$subject_name,$subject_code,$subject_lecture_hour,$subject_lab_hour,$subject_level)){
							return false;
						}
						else {
							return $db_error;
						}
					}
				$edit_subject_error=$id_error."</br>".$name_error."</br>".$code_error."</br>".$lecture_hour_error."</br>".$lab_hour_error."</br>".$level_error;
				return $edit_subject_error;
			}
			
		//group

			function check_add_group(){
				$add_group_error="";
				if((!isset($_POST['subject_id'])) || (!isset($_POST['group_name'])) || (!isset($_POST['teacher_id'])) || (!isset($_POST['class_type']))){
					return $add_group_error="plese fill all field before submit..";
				}
				
				$subject_id=$_POST['subject_id'];
				$group_name=$_POST['group_name'];
				$teacher_id=$_POST['teacher_id'];
				$class_type=$_POST['class_type'];
				
				$subject_id_error="";
				$name_error="";
				$teacher_id_error="";
				$class_type_error="";
				
				$db_error="";
				$subject_id_error=valid_id($subject_id,"subject_id");
				$name_error=valid_name($group_name,"group name");
				$teacher_id_error=valid_id($teacher_id,"teacher_id");
				$class_type_error=valid_class_type($class_type);
				
				if(!$subject_id_error && !$name_error && !$teacher_id_error && !$class_type_error){
						if(!$db_error=db_add_group($subject_id,$group_name,$teacher_id,$class_type)){
							return false;
						}
						else {
							return $db_error;
						}
					}
				$add_group_error=$subject_id_error."</br>".$name_error."</br>".$teacher_id_error."</br>".$class_type_error;
				return $add_group_error;
			}
			
			function check_edit_group(){
				$edit_group_error="";
				if((!isset($_POST['group_id'])) || (!isset($_POST['subject_id'])) || (!isset($_POST['group_name'])) || (!isset($_POST['teacher_id'])) || (!isset($_POST['class_type']))){
					return $edit_group_error="plese fill all field before submit..";
				}
				
				$group_id=$_POST['group_id'];
				$subject_id=$_POST['subject_id'];
				$group_name=$_POST['group_name'];
				$teacher_id=$_POST['teacher_id'];
				$class_type=$_POST['class_type'];
				
				$group_id_error="";
				$subject_id_error="";
				$name_error="";
				$teacher_id_error="";
				$class_type_error="";
				
				$db_error="";
				$group_id_error=valid_id($group_id,"group_id");
				$subject_id_error=valid_id($subject_id,"subject_id");
				$name_error=valid_name($group_name,"group name");
				$teacher_id_error=valid_id($teacher_id,"teacher_id");
				$class_type_error=valid_class_type($class_type);
				
				if(!$group_id_error && !$subject_id_error && !$name_error && !$teacher_id_error && !$class_type_error){
						if(!$db_error=db_edit_group($group_id,$subject_id,$group_name,$teacher_id,$class_type)){
							return false;
						}
						else {
							return $db_error;
						}
					}
				$edit_group_error=$group_id_error."</br>".$subject_id_error."</br>".$name_error."</br>".$teacher_id_error."</br>".$class_type_error;
				return $add_group_error;
			}
			
			
?>
