<?php 
	$server  = "localhost";
	$db_admin_name = "admin";
	$db_schedule_name ="schedule2";
	$db_user = "root";
	$db_pass = "";
	
		
		$con_admin = mysql_connect($server,$db_user,$db_pass);
		$con_schedule = mysql_connect($server,$db_user,$db_pass,true);
		
		if(!$con_admin){
			die('Could not connect whith database '.mysql_error());
		}
		if(!$con_schedule){
			die('Could not connect whith database '.mysql_error());
		}
		
		if(!mysql_select_db($db_admin_name, $con_admin)){
			die('Could not select database '.mysql_error());
		}
		
		if(!mysql_select_db($db_schedule_name, $con_schedule)){
			die('Could not select database '.mysql_error());
		}
	
?>