<?php
	include_once('/include/functions.php');
	session_destroy();
	header( 'Location: index.php' ) ;
?>