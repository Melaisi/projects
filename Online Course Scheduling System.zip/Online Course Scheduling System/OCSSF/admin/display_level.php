<!doctype html>
<?php
	
	include_once('/include/functions.php');
	if(!is_admin_login()){
		redirct_to("index.php");
	}
?>
<head>
	<title>Display Level</title>
	<link href="include/style.css" rel="stylesheet" />
</head>
<body>
<?php
		include_once('/include/header.html');
		include_once('/include/navbar.html');
		?>
	<div id="content">
		<div id="select_level">
		<div id="title">Display Level</div>
		<?php
			if($level_list=get_levels()){
			
					
		?>
			<form id="display_level" action="" method="GET"	 class="align_left">
				<select name="display">
		<?php
				
				foreach($level_list as $level){
		?>
				<option value="<?php echo $level['id']; ?>"><?php echo $level['name']; ?></option>
		<?php
				}
		?>
				</select>
				<input type="submit" />
			</form>
		<?php
			}
			else {
		?>
		<i>there are no levels avaliable plese add some from <a href="level.php">Level page</a></i>
		<?php
			}
		?>
		</div>
		<?php 
			if(!empty($_GET['display'])){
				if($level_info=check_level_exist($_GET['display'])){
					if(!$level_subject=get_level_subject($_GET['display'])){
						echo "there are no subject avaliable for this level";
					}
					else{
						?><table>
								<tr>
									<th>subject id</th>
									<th>subject name</th>
									<th>subject code</th>
									<th>action</th>
								</tr>
						<?php
						foreach($level_subject as $subject){
						
						?>		<tr> 
									<td><?php echo $subject['id']?></td>
									<td><?php echo $subject['name']?></td>
									<td><?php echo $subject['code']?></td>
									<td>
										<a href="display_subject.php?display=<?php echo $subject['id'];?>"><img src="include/images/display.png" title="display subject information" /></a>
										<a href="subject_edit.php?subject_id=<?php echo $subject['id'];?>"><img src="include/images/edit.png" title="edit this subject" /></a>
										<a href="subject_remove.php?subject_id=<?php echo $subject['id'];?>"><img src="include/images/remove.png" title="remove this subject" /></a>
									</td>
						<?php	
						}
					}
				}
				else {
					echo $level_info;
				}
			}
		
		?>
	</div>
</body>