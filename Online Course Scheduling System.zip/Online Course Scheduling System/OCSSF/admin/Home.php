<!doctype html>
<?php
	
	include_once('/include/functions.php');
	if(!is_admin_login()){
		redirct_to("index.php");
	}
?>
<html>
	<head>
		<title>Home Admin</title>
		<link href="include/style.css" rel="stylesheet" />
	</head>
	<body>
		<?php
		include_once('/include/header.html');
		include_once('/include/navbar.html');
		?>
		<div id="content">
			Welcom to Admin control panel .
		</div>
	</body>
</html>