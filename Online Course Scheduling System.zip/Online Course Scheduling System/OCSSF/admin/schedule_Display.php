<?php
	include_once('/include/functions.php');
	include_once('/include/schedule_fun.php');
	if(!is_admin_login()){
		redirct_to("index.php");
	}
	
	//get class table as day(table) =>room(row) => hour => group info 
		$classs = get_classs();
		$weekdays 	= get_weekdays();
		$worktime 	= get_worktime_Hour();
		$rooms 		= get_rooms();
?>
<!doctype html>
<html>
<head>
	<script>
	</script>
	
	<link rel="stylesheet" href="include/style.css" />
</head>
<body>
<?php
		include_once('/include/header.html');
		include_once('/include/navbar.html');
		?>
	<div id="content">
		<div id="title">Schedule Display</div>
				<?php
				$d=0;
				foreach($weekdays as $day_name => $day ){
					
					echo "<h3><br>".$day['day'].":</h3><br>"; ?>
					<table id="<?php echo "day:".$d; ?>" border="1">
					<tr>
						<th>room</th>
					<?php
						foreach($worktime as $hour){
						?>
							<th><?php echo $hour ?></th> 
						<?php
						}
					?>
					</tr>
					<?php
					foreach($rooms as $room_name => $room){
					?>
						<tr>
							<td><?php echo $room['name'];?></td>
							<?php
								foreach($worktime as $hour){
									$class_info="-";
									foreach($classs as $class){
										if($day['day'] == $class['day']){
											if($hour == $class['hour']){
												if($room['name'] == $class['room_name']){
													$class_info= $class['subject_code']."<br>".$class['level_name']."<br>".$class['group_name']."<br>".$class['teacher_name'];
												}
											}
										}
									}
									echo "<td>".$class_info."</td>";
						
								}		
							?>
						</tr>
					<?php
					}
					?>
					</table>
				<?php
				$d++;
				}?>
	</div>
</body>
</html>