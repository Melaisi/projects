<!doctype html>
<?php
	include_once('/include/functions.php');
	if(is_admin_login()){
		redirct_to("Home.php"); 
		
	}
	
	if(isset($_POST['admin_username']) && isset($_POST['admin_password'])){
		if(!$login_error=check_admin_login()){
			create_login_seesion();
			redirct_to("Home.php");
		}
		
	}
?>
<html>
	<head>
		<title>Admin LogIn</title>
		<link rel="stylesheet" href="include/style.css" />
	</head>
	<body>
		<div id="content">
			<div id="form_login">
				<form id="admin_login" action="" method="POST">
					Admin 	: <input id="admin_username" name="admin_username" type="text" />
					Password: <input id="admin_password" name="admin_password" type="password" />
					<input id="admin_submit" type="submit" />
				</form>
				<div id="erorr_msg">
					<?php 
						if(isset($login_error)){
								echo $login_error['username_erorr'];
								echo $login_error['password_error'];
								echo $login_error['db_error'];
								
						} 
					?>
				</div>
			</div>
		</div>
	</body>
</html>