<!doctype html>
<?php
	include_once('/include/functions.php');
	if(!is_admin_login()){
		header( 'Location: index.php' ) ;
	}
	$edit_group_error="";
	
	if(!isset($_GET['group_id'])){
			redirct_to("subject.php?error=get");
	}
	
	
		if(!$group_info=get_group($_GET['group_id'])){
			redirct_to("subject.php?error=info");
		}
	
	if(isset($_POST['group_name'])){
		if(!$edit_group_error=check_edit_group()){
			redirct_to("display_subject.php?display=".$group_info['subject_id']);
		}
	}
?>



<html>
	<head>
		<title>Edit group</title>
		<link href="include/style.css" rel="stylesheet" />
	</head>
	<body>
	<?php
		include_once('/include/header.html');
		include_once('/include/navbar.html');
		?>
		<div id="content">
			<div id="form_edit_group">
				<div id="title">Edit Group</div>
				<form id="edit_group" action="" method="POST"  class="align_left">
					<?php 
					if ($teachers=get_teachers()){ ?>
					Group Name : <input id="group_name" name="group_name" value="<?php echo $group_info['name']; ?>" type="text" /><br />
					<input type="hidden" name="subject_id" value="<?php echo $group_info['subject_id']; ?>" />
					Class type:
					<br><input type="radio" name="class_type" value="lecture" <?php if($group_info['class_type']=="lecture"){echo "checked";} ?>>lecture
					<br><input type="radio" name="class_type" value="lab" <?php if($group_info['class_type']=="lab"){echo "checked";} ?>>lab
					
					<br>Select Teacher : <select name="teacher_id">
					<?php 
							foreach($teachers as $teacher){
						?>
							<option value="<?php echo $teacher['id']; ?>" <?php if($teacher['name']==$group_info['teacher_name']){echo "selected='selected'";}?>><?php echo $teacher['name'];?></option>
					<?php 
							} ?>
					
					</select> <br />
					<input type="hidden" name="group_id" value="<?php echo $group_info['id']; ?>" />
					<input id="edit_group_submit" type="submit" />
					<?php 
					} 
					else { ?>
					<p class="error_input">	There are no teacher stored in database plese Add at least one teacher from :<a href="add_teacher.php">Add teacher page</a></p>
					<?php 
					} ?>
				</form>
			<p class="error_input"><?php echo $edit_group_error;  ?></p>
			</div>
			
		</div>
	</body>
</html>