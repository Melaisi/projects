
<?php
	
	include_once('/include/functions.php');
	if(!is_admin_login()){
		redirct_to("index.php");
	}
	if(!isset($_GET['teacher_id'])){
		redirct_to("teacher.php?error=9");
	}
	else{
		if($valid_error=valid_id($_GET['teacher_id'],"teacher id")){
			redirct_to("teacher.php?error=13");
		}
		else{
			if(!$teacher_info=check_teacher_exist($_GET['teacher_id'])){
				redirct_to("teacher.php?error=17");
			}
			else{
				if(!remove_teacher($teacher_info['id']))
				{
					echo "Error !!!!";
				}
				else{
				redirct_to("teacher.php");
				}
			}
		}
	}
?>
