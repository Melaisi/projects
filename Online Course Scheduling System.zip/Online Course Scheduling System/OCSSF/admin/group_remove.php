<?php
	
	include_once('/include/functions.php');
	if(!is_admin_login()){
		redirct_to("index.php");
	}
	if(!isset($_GET['group_id'])){
		redirct_to("subject.php?error=9");
	}
	else{
		if($valid_error=valid_id($_GET['group_id'],"group id")){
			redirct_to("subject.php?error=13");
		}
		else{
			if(!$group_info=check_group_exist($_GET['group_id'])){
				redirct_to("subject.php?error=17");
			}
			else{
				if(!remove_group($group_info['id']))
				{
					echo "Error !!!!";
				}
				else{
				redirct_to("display_subject.php?display=".$group_info['subject_id']);
				}
			}
		}
	}
?>
