<!doctype html>
<?php
	include_once('/include/functions.php');
	if(!is_admin_login()){
		header( 'Location: index.php' ) ;
	}
	$edit_subject_error="";
	
	if(!isset($_GET['subject_id'])){
			redirct_to("subject.php?error=get");
	}
	
	
		if(!$subject_info=get_subject($_GET['subject_id'])){
			redirct_to("subject.php?error=info");
		}
	
	if(isset($_POST['subject_name'])){
		if(!$edit_subject_error=check_edit_subject()){
			redirct_to("subject.php");
		}
	}
?>



<html>
	<head>
		<title>Edit subject</title>
		<link href="include/style.css" rel="stylesheet" />
	</head>
	<body>
	<?php
		include_once('/include/header.html');
		include_once('/include/navbar.html');
		?>
		<div id="content">
			<div id="form_edit_subject">
				<div id="title">Edit Subject</div>
				<form id="edit_subject" action="" method="POST"  class="align_left">
					<?php 
					if ($levels=get_levels()){ ?>
					Subject Name : <input id="subject_name" name="subject_name" value="<?php echo $subject_info['name']; ?>" type="text" /><br />
					Subject Code : <input id="subject_code" name="subject_code" value="<?php echo $subject_info['code']; ?>" type="text" /><br />
					Hour per week for lecture : <input id="subject_lecture_hour" name="subject_lecture_hour" value="<?php echo $subject_info['lecture_hour']; ?>" type="text" /> *0 for no lecture <br />
					Hour per week for lab : <input id="subject_lab_hour" name="subject_lab_hour" value="<?php echo $subject_info['lab_hour']; ?>" type="text" /> *0 for no lab<br />
					Select level : <select name="subject_level">
					<?php 
							foreach($levels as $level){
						?>
							<option value="<?php echo $level['name']; ?>" <?php if($level['name']==$subject_info['level_name']){echo "selected='selected'";}?>><?php echo $level['name'];?></option>
					<?php 
							} ?>
					
					</select> <br />
		
					<input type="hidden" name="subject_id" value="<?php echo $_GET['subject_id']; ?>" /> 
					<input id="edit_subject_submit" type="submit" />
					<?php 
					} 
					else { ?>
						<p class="error_input">There are no level stored in database plese Add at least one level from :<a href="add_level.php">Add level page</a></p>
					<?php 
					} ?>
				</form>
			<p class="error_input"><?php echo $edit_subject_error;  ?></p>
			</div>
			
		</div>
	</body>
</html>