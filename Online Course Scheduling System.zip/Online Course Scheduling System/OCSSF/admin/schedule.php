<?php
	
	include_once('/include/functions.php');
	include_once('/include/schedule_fun.php');
	if(!is_admin_login()){
		redirct_to("index.php");
	}
?><!doctype html> 
<html>
	<head>
		<title>Schedule</title>
		<link href="include/style.css" rel="stylesheet" />
	</head>
	<body>
		
		<?php
		include_once('/include/header.html');
		include_once('/include/navbar.html');
		?>
			<div id="content">
				<div id="status" class="align_left">
				
				<div id="title">Schedule Status</div>
				
				Weekday 					: <?php  $weekdays=get_weekdays(); if($weekdays){foreach($weekdays as $weekday ){echo $weekday['day']." ";}} ?><br>
				WorkTime					: <?php  $worktime=get_worktime(); if($worktime){echo "start time : ".$worktime['start'].", end time: ".$worktime['end'].", break time: ".$worktime['break'];}?><br>
				Number of room 				: <?php  echo $room=get_room_num(); ?><br>
				Number of teacher 			: <?php  get_teacher_num(); ?><br>	 
				Number of level 			: <?php  get_level_num(); ?><br>
				Number of Subject			: <?php  get_subject_num(); ?><br>
				Number of Groups			: <?php  get_groups_num(); ?><br>
				Number of lectures,lab hour	: <?php  echo $lectures_hour=get_lectures_hour(); ?><br>
				Number of avaliable class 	: <?php  echo $avaliable_class=get_avaliable_class(); ?><br>
				
				<?php 
					if($lectures_hour > $avaliable_class ){ 
					$_SESSION['status']= FALSE;
				?>
				<p class="error_input">The number of lecture hour should be equal or less than avaliable class !<br></p>
				<?php 
					}
					else{
					$_SESSION['status']= TRUE;
				?>
				</div>
				<form id="schedule_step1" action="schedule_step1.php" method="post" >
				<input type="submit" value="Next Step" /><br>
				</form>
				<?php
					}
				?>
				
				<div id="Current_Schedule" class="align_left">
					<div id="title">Current Schedule</div>
					<p> you can see the current Schedule from <a href="schedule_Display.php">DisplaySchedule Page</a></p>
				
				</div>
			</div>
	</body>
</html>