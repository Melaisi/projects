<?php
	
	include_once('/include/functions.php');
	if(!is_admin_login()){
		redirct_to("index.php");
	}
	if(!isset($_GET['subject_id'])){
		redirct_to("subject.php?error=9");
	}
	else{
		if($valid_error=valid_id($_GET['subject_id'],"subject id")){
			redirct_to("subject.php?error=13");
		}
		else{
			if(!$subject_info=check_subject_exist($_GET['subject_id'])){
				redirct_to("subject.php?error=17");
			}
			else{
				if(!remove_subject($subject_info['id']))
				{
					echo "Error !!!!";
				}
				else{
				redirct_to("subject.php");
				}
			}
		}
	}
?>
