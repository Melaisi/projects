<?php
	
	include_once('/include/functions.php');
	include_once('/include/schedule_fun.php');
	if(!is_admin_login()){
		redirct_to("index.php");
	}
	if(!is_step1_checked()){
		redirct_to("schedule_step1.php");
	}
	//Get Days , Rooms , WeekTime 
	$weekdays 	= get_weekdays();
	$worktime 	= get_worktime_Hour();
	$rooms 		= get_rooms();
	
	//get level,subjects lecture and lab info ,groups info in one array 
	
	//tester 
	$db_con = $GLOBALS['con_schedule'];
			
			
			$sql_subject="select * from subject";
			$sql_group="select 	groups.id,
								groups.name,
								groups.subject_id,
								groups.teacher_id,
								groups.class_type,
								teacher.name as teacher_name
						from groups
						LEFT JOIN teacher on groups.teacher_id = teacher.id";
			$sql_level="select * from level";
			if(!$result=mysql_query($sql_subject,$db_con)){
					die('Mysql Query Error: '.mysql_error());
			}
			while($row=mysql_fetch_assoc($result)){
				$subjects[]= $row;
			}
			
			if(!$result=mysql_query($sql_group,$db_con)){
					die('Mysql Query Error: '.mysql_error());
			}
			while($row=mysql_fetch_assoc($result)){
				$groups[]= $row;
			}
			
			if(!$result=mysql_query($sql_level,$db_con)){
					die('Mysql Query Error: '.mysql_error());
			}
			while($row=mysql_fetch_assoc($result)){
				$levels[]= $row;
			}
			
			foreach ($levels as $level){
				
				foreach ($subjects as $subject){
					if($subject['level_id']==$level['id']){
						foreach ($groups as $group){
								if($group['subject_id']==$subject['id']){
									if( ($group['class_type']=="lecture") && ($subject['lecture_hour'] >0) ){
										$all[$level['name']][$subject['name']][]=array(
											"id"=>$group['id'],
											"name"=>$group['name'],
											"level_id"=>$level['id'],
											"subject_id"=>$subject['id'],
											"subject_name"=>$subject['name'],
											"class_type"=>$group['class_type'],
											"class_time"=>$subject['lecture_hour'],
											"teacher_name"=>$group['teacher_name'],
											"teacher_id"=>$group['teacher_id']
											);
									}
									elseif(($group['class_type']=="lab") && ($subject['lab_hour'] >0) ){
										$all[$level['name']][$subject['name']][]=array(
											"id"=>$group['id'],
											"name"=>$group['name'],
											"level_id"=>$level['id'],
											"subject_id"=>$subject['id'],
											"subject_name"=>$subject['name'],
											"class_type"=>$group['class_type'],
											"class_time"=>$subject['lab_hour'],
											"teacher_name"=>$group['teacher_name'],
											"teacher_id"=>$group['teacher_id']
											);
									}
								}
						} 
					}
				}
			}
			
			// get from database : group id , group name , class type , subject_id , subject_name 
			//   subject_classtype_hour , teacher_id , teacher_name
			$sql = "SELECT 
					groups.id,
					groups.name,
					groups.class_type,
					groups.subject_id	as subject_id,
					groups.teacher_id	as teacher_id,
					subject.name		as subject_name,
					subject.code		as subject_code,
					subject.lecture_hour as subject_lecture_hour,
					subject.lab_hour	as subject_lab_hour,
					teacher.name		as teacher_name,
					teacher.id			as teacher_id,
					level.id			as level_id,
					level.name			as level_name
					FROM groups 
					LEFT JOIN subject ON groups.subject_id=subject.id
					LEFT JOIN teacher ON groups.teacher_id=teacher.id
					LEFT JOIN level   ON subject.level_id =level.id 
					ORDER BY level.id, subject.id, groups.id";
			$db_con = $GLOBALS['con_schedule'];
			if(!$result=mysql_query($sql,$db_con)){
					die('Mysql Query Error: '.mysql_error());
			}
			while($row=mysql_fetch_assoc($result)){
				$groups_details[]= $row;
			}
			
			
			
		
?>
<!doctype html>
<html>
<head>
	<script>
	<?php 
		$l=0;
				foreach($all as $level_name =>$level){
					$level_js[$l]=$level_name;
					$l++;
				}
				$l=0;
				foreach($all as $level_name =>$level){
					$s=0;
					foreach ($level as $subject_name =>$subject){
						$subject_js[$l][]=$subject_name;
						$s++;
					}	
					$l++;
				}	
				$l=0;
				foreach($all as $level_name =>$level){
					$s=0;
					foreach ($level as $subject_name =>$subject){
						
						foreach($subject as $group){	
							$group_js[$l][$s][]=$group;
							
						}
						$s++;
					}
					$l++;	
				}
				print("var level=". json_encode($level_js).";\n");
				print("var subject=". json_encode($subject_js).";\n");
				print("var group=". json_encode($group_js).";\n");
				
			//calss  
				
				
				$day_counter=0;
				
				echo "\t var classs = new Array();\n";
				
				foreach($weekdays as $day_name => $day ){
					
					echo "\t\t classs[$day_counter] = new Array();\n";
					$hour_counter=0;
					foreach($worktime as $hour){
						$room_counter=0;
						foreach($rooms as $room_name => $room){
							
							$room_counter++;
						}
						echo "\t\t\t classs[$day_counter][$hour_counter] = new Array($room_counter);\n";
						$hour_counter++;
					}
					$day_counter++;
					
				}
			//get day , hour ,room length  
				
				$day_length= count($weekdays);
				$hour_length=count($worktime);
				$room_length=count($rooms);
			//visited teacher by id
			$max_id=0;			
			$teachers=get_teachers();
			foreach ( $teachers as $teacher){
				if($max_id<$teacher['id']){
					$max_id=$teacher['id'];
				}
			} 
			echo "\t\t\t var max_id=$max_id\n";
			echo "\t\t\t var day_length=$day_length\n";
			echo "\t\t\t var hour_length=$hour_length\n";
			echo "\t\t\t var room_length=$room_length\n";	
	?>
	</script>
	<script type="text/javascript" src="include/javascript.js"></script>
	<link rel="stylesheet" href="include/style.css" />
</head>
<body>
	<?php
		include_once('/include/header.html');
		include_once('/include/navbar.html');
		?>
	<div id="content">
		<h3>Select:</h3>
	<div style="margin:10px;width:940;height:174px;">
		<div id="level" class="list">
		</div>
		<div id="subject" class="list">
		</div>
		<div id="group" class="list">
		</div>
	</div></br>
	<div id="selected_group_details">
	<h3>Selected Group Details :</h3></br>
		<div id="group_details">
			
		</div>
	</div>
		<br />
	<div id="tbl">
		<?php 
				$d=0;
				foreach($weekdays as $day_name => $day ){
					
					echo "<h3><br>".$day['day'].":</h3><br>"; ?>
					<table id="<?php echo "day:".$d; ?>" border="1">
					<tr>
						<th>room</th>
					<?php
						foreach($worktime as $hour){
						?>
							<th><?php echo $hour ?></th> 
						<?php
						}
					?>
					</tr>
					<?php
					foreach($rooms as $room_name => $room){
					?>
						<tr>
							<td><?php echo $room['name'];?></td>
							<?php
								foreach($worktime as $hour_name => $hour){
								?><td name="<?php echo "{'d':".$day_name.",'t':".$hour_name.",'r':".$room_name."};";  ?>" onclick="add(this);" onmouseover="info(this)"; onmouseout="hide(this);">-</td><?php 
						
								}		
							?>
						</tr>
					<?php
					}
					?>
					</table>
				<?php
				$d++;
				}
			?>
		

	</div>
	<div id="inf" class="info">text</div>
	<form id="classs" name="classs" action="add_schedule.php" method="POST" >
		<input type="hidden" id="classArr" name="classArr" value="" />
		<input type="submit" value="submit" />
	</form>
</body>
</html>