<!doctype html>
<?php
	include_once('/include/functions.php');
	if(!is_admin_login()){
		header( 'Location: index.php' ) ;
	}
	$add_subject_error="";
	
	if(isset($_POST['subject_name'])){
		if(!$add_subject_error=check_add_subject()){
			
			
			redirct_to("subject.php");
		}
	}
?>



<html>
	<head>
		<title>Add subject</title>
		<link href="include/style.css" rel="stylesheet" />
	</head>
	<body>
	<?php
		include_once('/include/header.html');
		include_once('/include/navbar.html');
		?>
		<div id="content">
			<div id="form_add_subject">
				<div id="title">Add Subject</div>
				<form id="add_subject" action="" method="POST" class="align_left">
					<?php 
					if ($levels=get_levels()){ ?>
					Subject Name : <input id="subject_name" name="subject_name" type="text" /><br />
					Subject Code : <input id="subject_code" name="subject_code" type="text" /><br />
					Hour per week for lecture : <input id="subject_lecture_hour" name="subject_lecture_hour" type="text" /> *0 for no lecture <br />
					Hour per week for lab : <input id="subject_lab_hour" name="subject_lab_hour" type="text" /> *0 for no lab<br />
					Select Level : <select name="subject_level">
					<?php 
							foreach($levels as $level){
						?>
							<option value="<?php echo $level['name']; ?>"><?php echo $level['name'];?></option>
					<?php 
							} ?>
					
					</select> <br />
					
					<input id="add_subject_submit" type="submit" />
					<?php 
					} 
					else { ?>
						<p class="error_input">There are no level stored in database plese Add at least one level from :<a href="add_level.php">Add level page</a></p>
					<?php 
					} ?>
				</form>
			<p class="error_input"><?php echo $add_subject_error;  ?></p>
			</div>
			
		</div>
	</body>
</html>