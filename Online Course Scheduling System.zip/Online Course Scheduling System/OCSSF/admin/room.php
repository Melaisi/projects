<!doctype html>
<?php
	
	include_once('/include/functions.php');
	if(!is_admin_login()){
		redirct_to("index.php");
	}
?>
<html>
	<head>
		<title>room</title>
		<link href="include/style.css" rel="stylesheet" />
	</head>
	<body>
	<?php
		include_once('/include/header.html');
		include_once('/include/navbar.html');
		?>
		<div id="content">
			<div id="room_list">
				<div id="title">Room List</div>
				<table id="room_list_table">
					<tr id="header">
						<th>Room Name</th>
						<th>Bulding Name</th>
					</tr>
					
						<?php 
							if($rooms=get_rooms()){
								foreach($rooms as $room){
									if($room['lab']==0){
						?>	<tr id="">
							<td><?php echo $room['name']; ?></td>
							<td><?php echo $room['building_name']; ?></td>
							<td>
								
								<a href="room_edit.php?room_id=<?php echo $room['id'];?>"><img src="include/images/edit.png" title="edit this room" /></a>
								<a href="room_remove.php?room_id=<?php echo $room['id'];?>"><img src="include/images/remove.png" title="remove this room" /></a>
							</td>
							</tr>
						<?php
									}
								}
							}
							else {
						?>
							<tr>
								<td><p class="error_input">there are no room stored in db, plese add a new room!</p></td>
							</tr>
						<?php
							}
							
						?>
					</tr>
					<tr id="footer">
						<td><a href="add_room.php"><img src="include/images/add.png" title="Add new room" /></a></td>
					</tr>
				</table>
				<hr />
				<div id="title">Lab List</div>
				<table id="lab_list_table">
					<tr id="header">
						<th>Lab Name</th>
						<th>Bulding Name</th>
					</tr>
					
						<?php 
							if($rooms){
								foreach($rooms as $room){
									if($room['lab']==1){
						?>	<tr id="">
							<td><?php echo $room['name']; ?></td>
							<td><?php echo $room['building_name']; ?></td>
							<td>
								
								<a href="room_edit.php?room_id=<?php echo $room['id'];?>"><img src="include/images/edit.png" title="edit this room" /></a>
								<a href="room_remove.php?room_id=<?php echo $room['id'];?>"><img src="include/images/remove.png" title="remove this room" /></a>
							</td>
							</tr>
						<?php
									}
								}
							}
							else {
						?>
							<tr>
								<td><p class="error_input">there are no lab stored in db, plese add a new room!</p></td>
							</tr>
						<?php
							}
							
						?>
					</tr>
					<tr id="footer">
						<td><a href="add_lab.php"><img src="include/images/add.png" title="Add new lab" /></a></td>
					</tr>
				</table>
			</div>
			
		</div>
	</body>
</html>