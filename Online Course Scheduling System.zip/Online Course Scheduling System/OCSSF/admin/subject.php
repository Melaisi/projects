<!doctype html>
<?php
	
	include_once('/include/functions.php');
	if(!is_admin_login()){
		redirct_to("index.php");
	}
?>
<html>
	<head>
		<title>Subject</title>
		<link rel="stylesheet" href="include/style.css" />
	</head>
	<body>
	<?php
		include_once('/include/header.html');
		include_once('/include/navbar.html');
		?>
		<div id="content">
			<div id="subject_list">
				<div id="title">Subjects List</div>
				<table id="subject_list_table">
					<tr id="header">
						<th>Subject Name</th>
						<th>Code</th>
						<th>Lecture hour</th>
						<th>Lab hour</th>
						<th>Number of Groups</th>
						<th>Level</th>
					</tr>
					
						<?php 
							if($subjects=get_subjects()){
							
								foreach($subjects as $subject){
						?>	<tr id="">
							<td><?php echo $subject['name']; ?></td>
							<td><?php echo $subject['code']; ?></td>
							<td><?php echo $subject['lecture_hour']; ?></td>
							<td><?php echo $subject['lab_hour']; ?></td>
							<td><?php echo $subject['group_number']; ?></td>
							<td><?php echo $subject['level_name']; ?></td>
							<td>
								<a href="display_subject.php?display=<?php echo $subject['id'];?>"><img src="include/images/display.png" title="display subject information" /></a>
								<a href="subject_edit.php?subject_id=<?php echo $subject['id'];?>"><img src="include/images/edit.png" title="edit this subject" /></a>
								<a href="subject_remove.php?subject_id=<?php echo $subject['id'];?>"><img src="include/images/remove.png" title="remove this subject" /></a>
							</td>
							</tr>
						<?php
								}
							}
							else {
						?>
							<tr>
								<td><p class="error_input">there are no subject stored in db, plese add a new subject!</p></td>
							</tr>
						<?php
							}
							
						?>
					</tr>
					<tr id="footer">
						<td><a href="add_subject.php"><img src="include/images/add.png" title="Add new subject" /></a></td>
					</tr>
				</table>
			</div>
			
		</div>
	</body>
</html>