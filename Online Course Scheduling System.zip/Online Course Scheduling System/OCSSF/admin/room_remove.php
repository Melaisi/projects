<?php
	
	include_once('/include/functions.php');
	if(!is_admin_login()){
		redirct_to("index.php");
	}
	if(!isset($_GET['room_id'])){
		redirct_to("room.php?error=9");
	}
	else{
		if($valid_error=valid_id($_GET['room_id'],"room id")){
			redirct_to("room.php?error=13");
		}
		else{
			if(!$room_info=check_room_exist($_GET['room_id'])){
				redirct_to("room.php?error=17");
			}
			else{
				if(!remove_room($room_info['id']))
				{
					echo "Error !!!!";
				}
				else{
				redirct_to("room.php");
				}
			}
		}
	}
?>
