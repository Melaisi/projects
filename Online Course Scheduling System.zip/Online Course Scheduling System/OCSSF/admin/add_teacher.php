<!doctype html>
<?php
	include_once('/include/functions.php');
	if(!is_admin_login()){
		header( 'Location: index.php' ) ;
	}
	$add_teacher_error="";
	
	if(isset($_POST['teacher_name'])){
		if(!$add_teacher_error=check_add_teacher()){
			
			
			redirct_to("teacher.php");
		}
	}
?>



<html>
	<head>
		<title>Add teacher</title>
		<link rel="stylesheet" href="include/style.css" />
	</head>
	<body>
	<?php
		include_once('/include/header.html');
		include_once('/include/navbar.html');
		?>
		<div id="content">
		
			<div id="form_add_teacher" class="align_left">
				<div id="title">
					Add Teacher 
				</div>
				<form id="add_teacher" action="" method="POST">
					<?php 
					if ($departments=get_departments()){ ?>
					Teacher Name : <input id="teacher_name" name="teacher_name" type="text" /><br />
					Select department : <select name="teacher_department">
					<?php 
							foreach($departments as $department){
						?>
							<option value="<?php echo $department['code']; ?>"><?php echo $department['code'];?></option>
					<?php 
							} ?>
					
					</select> <br />
					
					Teacher academic disciplines : <input id="teacher_academic_disciplines" name="teacher_academic_disciplines" type="text" /><br />
					
					<input id="add_teacher_submit" type="submit" />
					<?php 
					} 
					else { ?>
						There are no dpartment stored in database plese Add at least one department from :<a href="add_department.php">Add department page</a>
					<?php 
					} ?>
				</form>
				<p class="error_input"><?php echo $add_teacher_error;  ?></p>
			</div>
			
		</div>
	</body>
</html>