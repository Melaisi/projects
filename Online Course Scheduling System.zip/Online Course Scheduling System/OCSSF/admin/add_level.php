<!doctype html>
<?php
	include_once('/include/functions.php');
	if(!is_admin_login()){
		header( 'Location: index.php' ) ;
	}
	$add_level_error="";
	if(isset($_POST['level_name'])){
		if(!$add_level_error=check_add_level()){
			
			redirct_to("level.php");
		}
	}
?>



<html>
	<head>
		<title>Add Level</title>
		<link href="include/style.css" rel="stylesheet" />
	</head>
	<body>
	<?php
		include_once('/include/header.html');
		include_once('/include/navbar.html');
		?>
		<div id="content">
			<div id="form_add_level" class="align_left">
				<div id="title">Add Level</div>
				<form id="add_level" action="" method="POST">
					
					Level Name <input id="level_name" name="level_name" type="text" />
					<input id="add_level_submit" type="submit" />
					
				</form>
			<p class="error_input"><?php echo $add_level_error; ?></p>
			</div>
			
		</div>
	</body>
</html>