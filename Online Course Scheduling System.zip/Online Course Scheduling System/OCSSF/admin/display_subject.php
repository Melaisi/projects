<!doctype html>
<?php
	
	include_once('/include/functions.php');
	if(!is_admin_login()){
		redirct_to("index.php");
	}
?>
<head>
	<title>Display Subject</title>
	<link href="include/style.css" rel="stylesheet" />
</head>
<body>
<?php
		include_once('/include/header.html');
		include_once('/include/navbar.html');
		?>
	<div id="content">
		<div id="select_subject">
		<div id="title">Subject Info</div>
		<?php
			if($subject_list=get_subjects()){
			
					
		?>
			<form id="display_subject" action="" method="GET" class="align_left">
				<select name="display">
		<?php
				
				foreach($subject_list as $subject){
		?>
				<option value="<?php echo $subject['id']; ?>"><?php echo $subject['name']; ?></option>
		<?php
				}
		?>
				</select>
				<input type="submit" />
			</form>
		<?php
			}
			else {
		?>
		<p class="error_input">there are no subjects avaliable plese add some from <a href="subject.php">Subject page</a></p>
		<?php
			}
		?>
		</div>
		<?php 
			if(!empty($_GET['display'])){
				if($subject_info=check_subject_exist($_GET['display'])){
				
						?><table>
								<tr>
									<th>subject id</th>
									<th>Subject Name</th>
									<th>Code</th>
									<th>Lecture hour</th>
									<th>Lab hour</th>
									<th>Number of Groups</th>
									<th>Level</th>
								</tr>
						<?php
						?>		<tr id="">
									<td><?php echo $subject_info['id']; ?></td>
									<td><?php echo $subject_info['name']; ?></td>
									<td><?php echo $subject_info['code']; ?></td>
									<td><?php echo $subject_info['lecture_hour']; ?></td>
									<td><?php echo $subject_info['lab_hour']; ?></td>
									<td><?php echo $subject_info['group_number']; ?></td>
									<td><?php echo $subject_info['level_name']; ?></td>
									<td>
										<a href="subject_edit.php?subject_id=<?php echo $subject_info['id'];?>"><img src="include/images/edit.png" title="edit this subject" /></a>
										<a href="subject_remove.php?subject_id=<?php echo $subject_info['id'];?>"><img src="include/images/remove.png" title="remove this subject" /></a>
									</td>
								</tr>
							</table>
							<div id="title">Lecture Group List:</div>
							<table id="lecture_group_info">
								<tr>
									<th>Group name</th>
									<th>teacher name</th>
									<th>Action</th>
								</tr>
								<?php 
									if($groups=get_groups($subject_info['id'])){
										
										foreach($groups as $group){
											
											if($group['class_type']=="lecture"){
								?>
								<tr>
									<td><?php echo $group['name']; ?></td>
									<td><?php echo $group['teacher_name']; ?></td>
									<td>
										<a href="group_edit.php?group_id=<?php echo $group['id'];?>"><img src="include/images/edit.png" title="edit this group" /></a>
										<a href="group_remove.php?group_id=<?php echo $group['id'];?>"><img src="include/images/remove.png" title="remove this group" /></a>
									</td>
								</tr>
								<?php
											}
										}
									}
									else {
								?>
								<tr>
									<td><p class="error_input">there are no group stored in db, plese add a new Group!</p></td>
								</tr>
								<?php
									}
								?>
								<tr id="footer">
									<td><a href="add_group.php?subject_id=<?php  echo $subject_info['id']; ?>&class_type=lecture"><img src="include/images/add.png" title="Add new lecture group " /></a></td>
								</tr>
							</table>
							<div id="title">lab Group List:</div>
							<table id="lecture_group_info">
								<tr>
									<th>Group name</th>
									<th>teacher name</th>
									<th>Action</th>
								</tr>
								<?php 
									if($groups){
										foreach($groups as $group){
											
											if($group['class_type']=="lab"){
								?>
								<tr>
									<td><?php echo $group['name']; ?></td>
									<td><?php echo $group['teacher_name']; ?></td>
									<td>
										<a href="group_edit.php?group_id=<?php echo $group['id'];?>"><img src="include/images/edit.png" title="edit this group" /></a>
										<a href="group_remove.php?group_id=<?php echo $group['id'];?>"><img src="include/images/remove.png" title="remove this group" /></a>
									</td>
								</tr>
								<?php
											}
										}
									}
									else {
								?>
								<tr>
									<td><p class="error_input">there are no group stored in db, plese add a new Group!</p></td>
								</tr>
								<?php
									}
								?>
								<tr id="footer">
									<td><a href="add_group.php?subject_id=<?php  echo $subject_info['id']; ?>&class_type=lab"><img src="include/images/add.png" title="Add new lab group " /></a></td>
								</tr>
							</table>
						<?php
						
				}
				else {
					echo "<p class='error_input'>Error:".$subject_info."</p>";
				}
			}
		
		?>
	</div>
</body>