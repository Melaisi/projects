<!doctype html>
<?php
	
	include_once('/include/functions.php');
	if(!is_admin_login()){
		redirct_to("index.php");
	}
?>
<html>
	<head>
		<title>Teacher</title>
	<link href="include/style.css" rel="stylesheet" />
	</head>
	<body>
	<?php
		include_once('/include/header.html');
		include_once('/include/navbar.html');
		?>
		<div id="content">
			<div id="level_list">
				<div id="title">
					Teacher List
				</div>
				<table id="teacher_list_table">
					<tr id="header">
						<th>Teacher Name</th>
						<th>Department</th>
						<th>academic disciplines</th>
						<th>Number of subjects</th>
						<th>Actions</th>
					</tr>
					
						<?php 
							if($teachers=get_teachers()){
								foreach($teachers as $teacher){
						?>	<tr id="">
							<td><?php echo $teacher['name']; ?></td>
							<td><?php echo $teacher['department']; ?></td>
							<td><?php echo $teacher['academic_disciplines']; ?></td>
							<td><?php echo $teacher['subject_number']; ?></td>
							<td>
								
								<a href="teacher_edit.php?teacher_id=<?php echo $teacher['id'];?>"><img src="include/images/edit.png" title="edit this teacher" /></a>
								<a href="teacher_remove.php?teacher_id=<?php echo $teacher['id'];?>"><img src="include/images/remove.png" title="remove this teacher" /></a>
							</td>
							</tr>
						<?php
								}
							}
							else {
						?>
							<tr>
								<td><p class="error_input">there are no teacher stored in db, plese add a new teacher!</p></td>
							</tr>
						<?php
							}
							
						?>
					</tr>
					<tr id="footer">
						<td><a href="add_teacher.php"><img src="include/images/add.png" title="Add new teacher" /></a></td>
					</tr>
				</table>
			</div>
			
		</div>
	</body>
</html>