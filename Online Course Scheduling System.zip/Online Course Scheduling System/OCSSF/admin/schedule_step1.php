<!doctype html>
<?php
	
	include_once('/include/functions.php');
	include_once('/include/schedule_fun.php');
	if(!is_admin_login()){
		redirct_to("index.php");
	}
	if(!is_status_checked()){
		redirct_to("schedule.php");
	}
?><!doctype html> 
<html>
	<head>
		<title>Schedule :: Step1</title>
		<link href="include/style.css" rel="stylesheet" />
	</head>
	<body>
	<?php
		include_once('/include/header.html');
		include_once('/include/navbar.html');
		?>
		<div id="content">
			<div id="check_db" class="align_left">
			<div id="title">Step1 Check Data</div>
			<?php 
				$group_subject_error=check_group_subjects_id();
				$group_teacher_error=check_group_teacher_id();
				$subject_level_error=check_subject_level_id();
				
			?>
			check if messing data  :<br>
			group 	: <br>
				check subjects id : <?php if ($group_subject_error) { echo $group_subject_error;} else {echo "OK."; } ?><br>
				check teacher id  :	<?php if ($group_teacher_error) { echo $group_teacher_error;} else {echo "OK."; } ?><br>
			<br>
			subject	: <br>
				check level id :	<?php if ($subject_level_error) { echo $check_level_id_exist;} else {echo "OK."; } ?><br>
			<br>
			<br>
			--------------------------------------------------------------<br>
			<br>
			<?php if (!$group_subject_error && !$group_teacher_error && !$subject_level_error){ 
					$_SESSION['step1']= True;
			?>
			<form id="schedule_create" action="schedule_create.php" method="post" >
			<input type="submit" value="Next Step" /><br>
			</form>
			<?php
				}
				else{
				$_SESSION['step1']= FALSE;
			?>	
				there are some missing data, Plese check the database ...
			<?php	
				}
				
			?>
		</div>
	</body>
</html>