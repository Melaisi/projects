<?php
	include_once('/include/functions.php');
	include_once('/include/schedule_fun.php');
	
?>
<!doctype html>
<html>
	<head>
		<title>Level</title>
		<link href="include/style.css" rel="stylesheet" />
	</head>
	<body>
		<?php
		include_once('/include/header.html');
		include_once('/include/navbar.html');
		?>
		<div id="content">
			<div id="select_level">
			<?php
				if($level_list=get_levels()){
			?>
				<form id="display_level" action="" method="GET" class="align_left">
				<select name="display">
			<?php
				
					foreach($level_list as $level){
			?>
				<option value="<?php echo $level['id']; ?>"><?php echo $level['name']; ?></option>
			<?php
					}
			?>
				</select>
				<input type="submit" />
			</form>
			<?php
			}
			else {
			?>
		<p class="error_input">there are no level avaliable.</p>
			<?php
			}
			?>
		</div>
		<?php
			if(isset($_GET['display'])){
				if(!empty($_GET['display'])){
					if($level_info=check_level_exist($_GET['display'])){
						$classs 	= get_classs();
						$weekdays 	= get_weekdays();
						$worktime 	= get_worktime_Hour();
						$rooms 		= get_rooms();
		?>
			<div id="title">Level Schedule</div>
			<div id="title"><?php echo $level_info['name'] ?></div>
			
		<?php
						$d=0;
						foreach($weekdays as $day_name => $day ){
							echo "<h3><br>".$day['day'].":</h3><br>"; 
		?>
				<table id="<?php echo "day:".$d; ?>" border="1">
				<tr>
					<th>room</th>
		<?php
							foreach($worktime as $hour){
		?>
					<th><?php echo $hour ?></th> 
		<?php
							}
		?>
				</tr>
		<?php
							foreach($rooms as $room_name => $room){
		?>
				<tr>
					<td><?php echo $room['name'];?></td>
		<?php
								foreach($worktime as $hour){
									$class_info="-";
									foreach($classs as $class){
										if($class['level_id']==$_GET['display']){
											if($day['day'] == $class['day']){
												if($hour == $class['hour']){
													if($room['name'] == $class['room_name']){
														$class_info= $class['subject_code']."<br>".$class['level_name']."<br>".$class['group_name']."<br>".$class['teacher_name'];
													}
												}
											}
										}
									}
									echo "<td>".$class_info."</td>";
						
								}		
		?>
						</tr>
		<?php
							}
		?>
					</table>
		<?php
						$d++;
						}
					}
				}
			}
		?>
		</div>
			</div>
		</div>
	</body>
</html>