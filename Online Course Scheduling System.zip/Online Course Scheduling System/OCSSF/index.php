<!doctype html>
<html>
	<head>
		<title>Home</title>
		<link href="include/style.css" rel="stylesheet" />
	</head>
	<body>
		<?php
		include_once('/include/header.html');
		include_once('/include/navbar.html');
		?>
		<div id="content">
			<h3>Welcom to Online Course Scheduling System</h3>
			Plese select one of the links above on the navbar to exploer the schedule.
		</div>
	</body>
</html>