<html >
<head></head>
<body>
<?php

$result=array();
$i=0;
$point=0;
foreach ($_GET as $k=>$v) 
{
	$reault[$i]=$v;
	$i++;
}


$con = mysql_connect("localhost","mimcom_cinma","365214");
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }

mysql_select_db("mimcom_cinma", $con);

/* select * from user 
   foreach (user as uid ){
	for (i = 1;i<=15;i++)
		{
			if (ch[i] = result[i-1])
		point ++;
		}
		update where id = uid point = point 
	}
	
*/
$rqlselect ="select * from user";
$Rselect = mysql_query($rqlselect);

while ($row[]= mysql_fetch_array ($Rselect,MYSQL_NUM))
	{}
	$r=0;
	foreach ($row as $k)
	{
	$point=0;
	$ri=0;
	for ($i=3;$i<=17;$i++)
	{	
		
		if ($row[$r][$i] == $reault[$ri])
			$point++;
		$ri++;
		}
		$insert_sql="UPDATE user SET point = '".$point."' WHERE ID ='".$row[$r][0]."' ";
		mysql_query($insert_sql);
	echo "<br />------------------------<br />";
	$r++;
	}

mysql_close($con);

?>
</body>
</html>