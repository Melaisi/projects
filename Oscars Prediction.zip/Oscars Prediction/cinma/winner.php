<html dir="rtl">
<head></head>
<body>
<?

$result=array();
$i=0;
foreach ($_GET as $k=>$v) 
{
	$reault[$i]=$v;
	$i++;
}

$con = mysql_connect("localhost","mimcom_cinma","365214");
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }

mysql_select_db("mimcom_cinma", $con);

 $sql = "SELECT * FROM `user` ORDER BY `ID` ";
 $q_ch = mysql_query($sql);
 
mysql_close($con);









?>
</body></html>