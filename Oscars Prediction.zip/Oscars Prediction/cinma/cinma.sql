-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- المزود: localhost
-- أنشئ في: 09 يناير 2012 الساعة 17:01
-- إصدارة المزود: 5.5.8
--  PHP إصدارة: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- قاعدة البيانات: `cinma`
--
CREATE DATABASE `cinma` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `cinma`;

-- --------------------------------------------------------

--
-- بنية الجدول `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `ID` int(5) NOT NULL AUTO_INCREMENT,
  `user` varchar(20) DEFAULT NULL,
  `point` int(3) DEFAULT '0',
  `ch1` int(1) DEFAULT NULL,
  `ch2` int(1) DEFAULT NULL,
  `ch3` int(1) DEFAULT NULL,
  `ch4` int(1) DEFAULT NULL,
  `ch5` int(1) DEFAULT NULL,
  `ch6` int(1) DEFAULT NULL,
  `ch7` int(1) DEFAULT NULL,
  `ch8` int(1) DEFAULT NULL,
  `ch9` int(1) DEFAULT NULL,
  `ch10` int(1) DEFAULT NULL,
  `ch11` int(1) DEFAULT NULL,
  `ch12` int(1) DEFAULT NULL,
  `ch13` int(1) DEFAULT NULL,
  `ch14` int(1) DEFAULT NULL,
  `ch15` int(1) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `user` (`user`),
  UNIQUE KEY `user_2` (`user`),
  UNIQUE KEY `user_3` (`user`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- إرجاع أو استيراد بيانات الجدول `user`
--

INSERT INTO `user` (`ID`, `user`, `point`, `ch1`, `ch2`, `ch3`, `ch4`, `ch5`, `ch6`, `ch7`, `ch8`, `ch9`, `ch10`, `ch11`, `ch12`, `ch13`, `ch14`, `ch15`) VALUES
(1, 'MrDoor', 0, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5),
(6, NULL, 0, 4, 2, 3, 1, 2, 5, 4, 6, 8, 4, 9, 2, 1, 3, 1),
(7, NULL, 0, 4, 3, 5, 3, 1, 4, 1, 4, 1, 3, 2, 1, 4, 1, 5),
(8, NULL, 0, 4, 3, 5, 3, 1, 4, 1, 4, 1, 3, 2, 1, 4, 1, 5),
(9, NULL, 0, 4, 3, 5, 3, 1, 4, 1, 4, 1, 3, 2, 1, 4, 1, 1),
(10, NULL, 0, 3, 3, 1, 5, 1, 5, 1, 3, 3, 1, 5, 2, 4, 5, 1),
(11, NULL, 0, 3, 3, 1, 5, 1, 5, 1, 3, 3, 1, 5, 2, 4, 3, 1),
(12, NULL, 0, 3, 3, 1, 5, 1, 5, 1, 3, 3, 1, 5, 2, 4, 3, 5);
