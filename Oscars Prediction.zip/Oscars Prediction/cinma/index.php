﻿<html dir="rtl">
<head></head>
<body>
<br />
<form action="result.php" method="get">
افضل فيلم عن فئة الدراما :<br />
<input type="radio" name="ch1" value="1" />The Descendants<br />
<input type="radio" name="ch1" value="2" />The Help<br />
<input type="radio" name="ch1" value="3" />Hugo<br />
<input type="radio" name="ch1" value="4" />The Ides of March<br />
<input type="radio" name="ch1" value="5" />Moneyball<br />
<input type="radio" name="ch1" value="6" />War Horse<br />
<br />
افضل فيلم عن فئة كوميدي أو موسيقي :<br />
<input type="radio" name="ch2" value="1" />The Artist<br />
<input type="radio" name="ch2" value="2" />Bridesmaids<br />
<input type="radio" name="ch2" value="3" />50/50 <br />
<input type="radio" name="ch2" value="4" />Midnight in Paris<br />
<input type="radio" name="ch2" value="5" />My Week with Marilyn<br />
<br />
افضل ممثل رئيسي عن فئة دراما :<br />
<input type="radio" name="ch3" value="1" />George Clooney for The Descendants 
<br />
<input type="radio" name="ch3" value="2" />Leonardo DiCaprio for J. Edgar <br />
<input type="radio" name="ch3" value="3" />Michael Fassbender for Shame <br />
<input type="radio" name="ch3" value="4" />Ryan Gosling for The Ides of March <br />
<input type="radio" name="ch3" value="5" />Brad Pitt for Moneyball<br />
<br />
افضل ممثلة رئيسية عن فئة دراما :<br />
<input type="radio" name="ch4" value="1" />Glenn Close for Albert Nobbs <br />
<input type="radio" name="ch4" value="2" />Viola Davis for The Help<br />
<input type="radio" name="ch4" value="3" />Rooney Mara for The Girl with the Dragon Tattoo<br />
<input type="radio" name="ch4" value="4" />Meryl Streep for The Iron Lady <br />
<input type="radio" name="ch4" value="5" />Tilda Swinton for We Need to Talk About Kevin<br />
<br />
افضل ممثل رئيسي عن فئة كوميدي او موسيقي :<br />
<input type="radio" name="ch5" value="1" />Jean Dujardin for The Artist <br />
<input type="radio" name="ch5" value="2" />Brendan Gleeson for The Guard <br />
<input type="radio" name="ch5" value="3" />Joseph Gordon-Levitt for 50/50 <br />
<input type="radio" name="ch5" value="4" />Ryan Gosling for Crazy, Stupid, Love.<br />
<input type="radio" name="ch5" value="5" />Owen Wilson for Midnight in Paris<br />
<br />
افضل ممثلة رئيسية عن فئة كوميدي او موسيقي . :<br />
<input type="radio" name="ch6" value="1" />Jodie Foster for Carnage<br />
<input type="radio" name="ch6" value="2" />Charlize Theron for Young Adult <br />
<input type="radio" name="ch6" value="3" />Kristen Wiig for Bridesmaids <br />
<input type="radio" name="ch6" value="4" />Michelle Williams for My Week with Marilyn <br />
<input type="radio" name="ch6" value="5" />Kate Winslet for Carnage<br />
<br />
افضل ممثل مساعد :<br />
<input type="radio" name="ch7" value="1" />Kenneth Branagh for My Week with Marilyn<br />
<input type="radio" name="ch7" value="2" />Albert Brooks for Drive<br />
<input type="radio" name="ch7" value="3" />Jonah Hill for Moneyball<br />
<input type="radio" name="ch7" value="4" />Viggo Mortensen for A Dangerous Method<br />
<input type="radio" name="ch7" value="5" />Christopher Plummer for Beginners<br />
<br />
افضل ممثلة مساعدة  :<br />
<input type="radio" name="ch8" value="1" />Bérénice Bejo for The Artist <br />
<input type="radio" name="ch8" value="2" />Jessica Chastain for The Help<br />
<input type="radio" name="ch8" value="3" />Janet McTeer for Albert Nobbs <br />
<input type="radio" name="ch8" value="4" />Octavia Spencer for The Help<br />
<input type="radio" name="ch8" value="5" />Shailene Woodley for The Descendants<br />
<br />
افضل مخرج :<br />
<input type="radio" name="ch9" value="1" />Woody Allen for Midnight in Paris <br />
<input type="radio" name="ch9" value="2" />George Clooney for The Ides of March <br />
<input type="radio" name="ch9" value="3" />Michel Hazanavicius for The Artist<br />
<input type="radio" name="ch9" value="4" />Alexander Payne for The Descendants <br />
<input type="radio" name="ch9" value="5" />Martin Scorsese for Hugo<br />
<br />
افضل مسلسل عن فئة الدراما :<br />
<input type="radio" name="ch10" value="1" />American Horror Story<br />
<input type="radio" name="ch10" value="2" />Boardwalk Empire<br />
<input type="radio" name="ch10" value="3" />Boss<br />
<input type="radio" name="ch10" value="4" />Game of Thrones<br />
<input type="radio" name="ch10" value="5" />Homeland<br />
<br />
افضل مسلسل عن فئة كوميدي أو موسيقي :<br />
<input type="radio" name="ch11" value="1" />Enlightened<br />
<input type="radio" name="ch11" value="2" />Episodes<br />
<input type="radio" name="ch11" value="3" />Glee<br />
<input type="radio" name="ch11" value="4" />Modern Family<br />
<input type="radio" name="ch11" value="5" />New Girl<br />
<br />
أفضل ممثل رئيسي لمسلسل عن فئة الدراما :<br />
<input type="radio" name="ch12" value="1" />Steve Buscemi for Boardwalk Empire<br />
<input type="radio" name="ch12" value="2" />Bryan Cranston for Breaking Bad <br />
<input type="radio" name="ch12" value="3" />Kelsey Grammer for Boss <br />
<input type="radio" name="ch12" value="4" />Jeremy Irons for The Borgias <br />
<input type="radio" name="ch12" value="5" />Damian Lewis for Homeland<br />
<br />
أفضل ممثلة رئيسية لمسلسل عن فئة الدراما:<br />
<input type="radio" name="ch13" value="1" />Claire Danes for Homeland<br />
<input type="radio" name="ch13" value="2" />Mireille Enos for The Killing<br />
<input type="radio" name="ch13" value="3" />Julianna Margulies for The Good Wife<br />
<input type="radio" name="ch13" value="4" />Madeleine Stowe for Revenge<br />
<input type="radio" name="ch13" value="5" />Callie Thorne for Necessary Roughness<br />
<br />
أفضل ممثل رئيسي لمسلسل عن فئة كوميدي او موسيقى :<br />
<input type="radio" name="ch14" value="1" />Alec Baldwin for 30 Rock<br />
<input type="radio" name="ch14" value="2" />David Duchovny for Californication<br />
<input type="radio" name="ch14" value="3" />Johnny Galecki for The Big Bang Theory <br />
<input type="radio" name="ch14" value="4" />Thomas Jane for Hung<br />
<input type="radio" name="ch14" value="5" />Matt LeBlanc for Episodes<br />
<br />
أفضل ممثلة رئيسية لمسلسل عن فئة كوميدي أو موسيقي :<br />
<input type="radio" name="ch15" value="1" />Laura Dern for Enlightened<br />
<input type="radio" name="ch15" value="2" />Zooey Deschanel for New Girl<br />
<input type="radio" name="ch15" value="3" />Tina Fey for 30 Rock<br />
<input type="radio" name="ch15" value="4" />Laura Linney for The Big C<br />
<input type="radio" name="ch15" value="5" />Amy Poehler for Parks and Recreation<br />
<br />
<input type="submit" value="اعتمد" />
</form>

</body>
</html>