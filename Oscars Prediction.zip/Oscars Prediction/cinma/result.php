﻿<html dir="rtl">
<head></head>
<body>
<?php

$result=array();
$i=0;
foreach ($_GET as $k=>$v) 
{
	$reault[$i]=$v;
	$i++;
}
$con = mysql_connect("localhost","mimcom_cinma","365214");
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }

mysql_select_db("mimcom_cinma", $con);


$sql="INSERT INTO user (ch1, ch2, ch3, ch4, ch5, ch6, ch7, ch8, ch9, ch10, ch11, ch12, ch13, ch14, ch15)
VALUES
(".$reault[0].",".$reault[1].",".$reault[2].",".$reault[3].",".$reault[4].",".$reault[5].",".$reault[6].",".$reault[7].",".$reault[8].",".$reault[9].",".$reault[10].",".$reault[11].",".$reault[12].",".$reault[13].",".$reault[14].")";
	
	if (!mysql_query($sql,$con))
  {
  die('Error: ' . mysql_error());
  }
  $sql = "SELECT * FROM `user` ORDER BY `ID` DESC ";
$q_ID = mysql_query($sql);
$ID = mysql_fetch_array( $q_ID );
mysql_close($con);

echo "تمت اضافة توقعاتك لقاعدة البيانات رقمك الخاص بالموقع هو : ".$ID[0];
//BB code
//////////
/////////
////////////////////////////////////////////////////////////

require_once('bbcode.php');

print ' 
		<br />
		قم بنسخ محتويات الصندوق بالاسفل ولصقها في خانة الرد بالمنتدى 
		<br />
		<textarea dir="ltr" rows="50" cols="50" disabled="disabled">
		'.$txtarea.'My Id in [URL="http://mr-mim.com/Msa6el/cinma/"]Msa6el cinma vote[/URL] is:'.$ID[0].'.
		</textarea>
		';

////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////
/////////////////////////////

?>
</body>
</html>