﻿<?php 
$cat=array ("Best Motion Picture - Drama","Best Motion Picture - Musical or Comedy","Best Performance by an Actor in a Motion Picture - Drama","Best Performance by an Actress in a Motion Picture - Drama","Best Performance by an Actor in a Motion Picture - Musical or Comedy","Best Performance by an Actress in a Motion Picture - Musical or Comedy","Best Performance by an Actor in a Supporting Role in a Motion Picture","Best Performance by an Actress in a Supporting Role in a Motion Picture","Best Director - Motion Picture","Best Television Series - Drama","Best Television Series - Musical or Comedy","Best Performance by an Actor in a Television Series - Drama","Best Performance by an Actress in a Television Series - Drama","Best Performance by an Actor in a Television Series - Musical or Comedy","Best Performance by an Actress in a Television Series - Musical or Comedy");

$cat1=array("","The Descendants ","The Help","Hugo","The Ides of March","Moneyball ","War Horse");
$cat2=array("","The Artist ","Bridesmaids","50/50","Midnight in Paris ","My Week with Marilyn");
$cat3=array("","George Clooney [COLOR=#4b0082]for[/COLOR] The Descendants ","Leonardo DiCaprio [COLOR=#4b0082]for[/COLOR] J. Edgar ","Michael Fassbender [COLOR=#4b0082]for[/COLOR] Shame ","Ryan Gosling [COLOR=#4b0082]for[/COLOR] The Ides of March ","Brad Pitt [COLOR=#4b0082]for[/COLOR] Moneyball");
$cat4=array("","Glenn Close [COLOR=#4b0082]for[/COLOR] Albert Nobbs","Viola Davis [COLOR=#4b0082]for[/COLOR] The Help","Rooney Mara [COLOR=#4b0082]for[/COLOR] The Girl with the Dragon Tattoo","Meryl Streep [COLOR=#4b0082]for[/COLOR] The Iron Lady ","Tilda Swinton [COLOR=#4b0082]for[/COLOR] We Need to Talk About Kevin");
$cat5=array("","Jean Dujardin [COLOR=#4b0082]for[/COLOR] The Artist ","Brendan Gleeson [COLOR=#4b0082]for[/COLOR] The Guard ","Joseph Gordon-Levitt [COLOR=#4b0082]for[/COLOR] 50/50 ","Ryan Gosling [COLOR=#4b0082]for[/COLOR] Crazy, Stupid, Love. ","Owen Wilson [COLOR=#4b0082]for[/COLOR] Midnight in Paris");
$cat6=array("","Jodie Foster [COLOR=#4b0082]for[/COLOR] Carnage","Charlize Theron [COLOR=#4b0082]for[/COLOR] Young Adult ","Kristen Wiig [COLOR=#4b0082]for[/COLOR] Bridesmaids ","Michelle Williams [COLOR=#4b0082]for[/COLOR] My Week with Marilyn ","Kate Winslet [COLOR=#4b0082]for[/COLOR] Carnage");
$cat7=array("","Kenneth Branagh [COLOR=#4b0082]for[/COLOR] My Week with Marilyn","Albert Brooks [COLOR=#4b0082]for[/COLOR] Drive ","Jonah Hill [COLOR=#4b0082]for[/COLOR] Moneyball","Viggo Mortensen [COLOR=#4b0082]for[/COLOR] A Dangerous Method ","Christopher Plummer [COLOR=#4b0082]for[/COLOR] Beginners");
$cat8=array("","Bérénice Bejo [COLOR=#4b0082]for[/COLOR] The Artist ","Jessica Chastain [COLOR=#4b0082]for[/COLOR] The Help","Janet McTeer [COLOR=#4b0082]for[/COLOR] Albert Nobbs ","Octavia Spencer [COLOR=#4b0082]for[/COLOR] The Help","Shailene Woodley [COLOR=#4b0082]for[/COLOR] The Descendants");
$cat9=array("","Woody Allen [COLOR=#4b0082]for[/COLOR] Midnight in Paris ","George Clooney [COLOR=#4b0082]for[/COLOR] The Ides of March","Michel Hazanavicius [COLOR=#4b0082]for[/COLOR] The Artist ","Alexander Payne [COLOR=#4b0082]for[/COLOR] The Descendants ","Martin Scorsese [COLOR=#4b0082]for[/COLOR] Hugo");
$cat10=array("","American Horror Story","Boardwalk Empire","Boss","Game of Thrones","Homeland");
$cat11=array("","Enlightened","Episodes","Glee","Modern Family","New Girl");
$cat12=array("","Steve Buscemi [COLOR=#4b0082]for[/COLOR] Boardwalk Empire","Bryan Cranston [COLOR=#4b0082]for[/COLOR] Breaking Bad ","Kelsey Grammer [COLOR=#4b0082]for[/COLOR] Boss ","Jeremy Irons [COLOR=#4b0082]for[/COLOR] The Borgias ","Damian Lewis [COLOR=#4b0082]for[/COLOR] Homeland");
$cat13=array("","Claire Danes [COLOR=#4b0082]for[/COLOR] Homeland","Mireille Enos [COLOR=#4b0082]for[/COLOR] The Killing","Julianna Margulies [COLOR=#4b0082]for[/COLOR] The Good Wife","Madeleine Stowe [COLOR=#4b0082]for[/COLOR] Revenge","Callie Thorne [COLOR=#4b0082]for[/COLOR] Necessary Roughness");
$cat14=array("","Alec Baldwin [COLOR=#4b0082]for[/COLOR] 30 Rock","David Duchovny [COLOR=#4b0082]for[/COLOR] Californication","Johnny Galecki [COLOR=#4b0082]for[/COLOR] The Big Bang Theory","Thomas Jane [COLOR=#4b0082]for[/COLOR] Hung","Matt LeBlanc [COLOR=#4b0082]for[/COLOR] Episodes");
$cat15=array("","Laura Dern [COLOR=#4b0082]for[/COLOR] Enlightened","Zooey Deschanel [COLOR=#4b0082]for[/COLOR] New Girl","Tina Fey [COLOR=#4b0082]for[/COLOR] 30 Rock","Laura Linney [COLOR=#4b0082]for[/COLOR] The Big C","Amy Poehler [COLOR=#4b0082]for[/COLOR] Parks and Recreation");

	$txtarea=	"[CENTER][FONT=Palatino Linotype][SIZE=5][COLOR=#4b0082]".$cat[0]."[/COLOR][/SIZE][/FONT]
FONT=Palatino Linotype][COLOR=#2f4f4f]".$cat1[$result[0]]."[/COLOR][/FONT]
[FONT=Palatino Linotype][SIZE=5][COLOR=#4b0082]".$cat[1]."[/COLOR][/SIZE][/FONT]
[FONT=Palatino Linotype][COLOR=#2f4f4f]".$cat2[$result[1]]."[/COLOR][/FONT]
[FONT=Palatino Linotype][SIZE=5][COLOR=#4b0082]".$cat[2]."[/COLOR][/SIZE][/FONT]
[FONT=Palatino Linotype][COLOR=#2f4f4f]".$cat3[$result[2]]."[/COLOR][/FONT]
[FONT=Palatino Linotype][SIZE=5][COLOR=#4b0082]".$cat[3]."[/COLOR][/SIZE][/FONT]
[FONT=Palatino Linotype][COLOR=#2f4f4f]".$cat4[$result[3]]."[/COLOR][/FONT]
[FONT=Palatino Linotype][SIZE=5][COLOR=#4b0082]".$cat[4]."[/COLOR][/SIZE][/FONT]
[FONT=Palatino Linotype][COLOR=#2f4f4f]".$cat5[$result[4]]."[/COLOR][/FONT]
[FONT=Palatino Linotype][SIZE=5][COLOR=#4b0082]".$cat[5]."[/COLOR][/SIZE][/FONT]
[FONT=Palatino Linotype][COLOR=#2f4f4f]".$cat6[$result[5]]."[/COLOR][/FONT]
[FONT=Palatino Linotype][SIZE=5][COLOR=#4b0082]".$cat[6]."[/COLOR][/SIZE][/FONT]
[FONT=Palatino Linotype][COLOR=#2f4f4f]".$cat7[$result[6]]."[/COLOR][/FONT]
[FONT=Palatino Linotype][SIZE=5][COLOR=#4b0082]".$cat[7]."[/COLOR][/SIZE][/FONT]
[FONT=Palatino Linotype][COLOR=#2f4f4f]".$cat8[$result[7]]."[/COLOR][/FONT]
[FONT=Palatino Linotype][SIZE=5][COLOR=#4b0082]".$cat[8]."[/COLOR][/SIZE][/FONT]
[FONT=Palatino Linotype][COLOR=#2f4f4f]".$cat9[$result[8]]."[/COLOR][/FONT]
[FONT=Palatino Linotype][SIZE=5][COLOR=#4b0082]".$cat[9]."[/COLOR][/SIZE][/FONT]
[FONT=Palatino Linotype][COLOR=#2f4f4f]".$cat10[$result[9]]."[/COLOR][/FONT]
[FONT=Palatino Linotype][SIZE=5][COLOR=#4b0082]".$cat[10]."[/COLOR][/SIZE][/FONT]
[FONT=Palatino Linotype][COLOR=#2f4f4f]".$cat11[$result[10]]."[/COLOR][/FONT]
[FONT=Palatino Linotype][SIZE=5][COLOR=#4b0082]".$cat[11]."[/COLOR][/SIZE][/FONT]
[FONT=Palatino Linotype][COLOR=#2f4f4f]".$cat12[$result[11]]."[/COLOR][/FONT]
[FONT=Palatino Linotype][SIZE=5][COLOR=#4b0082]".$cat[12]."[/COLOR][/SIZE][/FONT]
[FONT=Palatino Linotype][COLOR=#2f4f4f]".$cat13[$result[12]]."[/COLOR][/FONT]
[FONT=Palatino Linotype][SIZE=5][COLOR=#4b0082]".$cat[13]."[/COLOR][/SIZE][/FONT]
[FONT=Palatino Linotype][COLOR=#2f4f4f]".$cat14[$result[13]]."[/COLOR][/FONT]
[FONT=Palatino Linotype][SIZE=5][COLOR=#4b0082]".$cat[14]."[/COLOR][/SIZE][/FONT]
[FONT=Palatino Linotype][COLOR=#2f4f4f]".$cat15[$result[14]]."[/COLOR][/FONT]
[/CENTER]";

?>