<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Msa6el Cinema - The Golden Globe Award </title>
<link rel="stylesheet" type="text/css" href="styles.css" />
<script src="javascript.js" type="text/javascript"></script>

</head>

<body onload="showttls();">
<div id="topbar"><center><p id="mtitle">مسابقة التوقعات - حارة المساطيل</p></center></div>
<br />
<div id="body" unselectable="on">
<center>
<!=======1=======>
<div style="width:950px;position:absolute;top:108px;">
<center>
<img id="01_1" ondblclick="openimdb1(this);" onclick="selectthis1(this);" title="The Descendants" src="img/a1.jpg" width="150" class="movies1" />
<img id="01_2" ondblclick="openimdb1(this);" onclick="selectthis1(this);" title="The Help" src="img/a2.jpg" width="150" class="movies1" style="left:25px;" />
<img id="01_3" ondblclick="openimdb1(this);" onclick="selectthis1(this);" title="Hugo" src="img/a3.jpg" width="150" class="movies1" style="left:40px;" />
<img id="01_4" ondblclick="openimdb1(this);" onclick="selectthis1(this);" title="The Ides of March" src="img/a4.jpg" width="150" class="movies1" style="left:55px;" />
<img id="01_5" ondblclick="openimdb1(this);" onclick="selectthis1(this);" title="Moneyball" src="img/a5.jpg" width="150" class="movies1" style="left:70px;" />
<img id="01_6" ondblclick="openimdb1(this);" onclick="selectthis1(this);" title="War Horse" src="img/a6.jpg" width="150" class="movies1" style="left:85px;" />
</center>
</div>

<!=======2=======>
<div style="width:950px;position:absolute;top:413px;">
<center>
<img id="02_1" ondblclick="openimdb(this);" onclick="selectthis(this);" title="The Artist" src="img/b1.jpg" width="150" class="movies" />
<img id="02_2" ondblclick="openimdb(this);" onclick="selectthis(this);" title="Bridesmaids" src="img/b2.jpg" width="150" class="movies" style="left:25px;" />
<img id="02_3" ondblclick="openimdb(this);" onclick="selectthis(this);" title="50/50" src="img/b3.jpg" width="150" class="movies" style="left:40px;" />
<img id="02_4" ondblclick="openimdb(this);" onclick="selectthis(this);" title="Midnight in Paris" src="img/b4.jpg" width="150" class="movies" style="left:55px;" />
<img id="02_5" ondblclick="openimdb(this);" onclick="selectthis(this);" title="My Week with Marilyn" src="img/b5.jpg" width="150" class="movies" style="left:70px;" />
</center>
</div>

<!=======3=======>
<div style="width:950px;position:absolute;top:705px;">
<center>
<img id="03_1b" onclick="selectthisactb(this);" title="The Descendants" src="img/a1.jpg" width="150" class="movies2" />
<img id="03_2b" onclick="selectthisactb(this);" title="J. Edgar" src="img/c2.jpg" width="150" class="movies2" style="left:25px;" />
<img id="03_3b" onclick="selectthisactb(this);" title="Shame" src="img/c3.jpg" width="150" class="movies2" style="left:40px;" />
<img id="03_4b" onclick="selectthisactb(this);" title="The Ides of March" src="img/a4.jpg" width="150" class="movies2" style="left:55px;" />
<img id="03_5b" onclick="selectthisactb(this);" title="Moneyball" src="img/a5.jpg" width="150" class="movies2" style="left:70px;" />

<div style="position:relative;top:-200px;">
<img id="03_1" ondblclick="openimdb(this);" onclick="selectthisact(this);" title="George Clooney" src="img/c1.jpg" width="150" class="movies2" />
<img id="03_2" ondblclick="openimdb(this);" onclick="selectthisact(this);" title="Leonardo DiCaprio" src="img/c22.jpg" width="150" class="movies2" style="left:25px;" />
<img id="03_3" ondblclick="openimdb(this);" onclick="selectthisact(this);" title="Michael Fassbender" src="img/c33.jpg" width="150" class="movies2" style="left:40px;" />
<img id="03_4" ondblclick="openimdb(this);" onclick="selectthisact(this);" title="Ryan Gosling" src="img/c44.jpg" width="150" class="movies2" style="left:55px;" />
<img id="03_5" ondblclick="openimdb(this);" onclick="selectthisact(this);" title="Brad Pitt" src="img/c55.jpg" width="150" class="movies2" style="left:70px;" />
</div>
</center>
</div>

<!=======4=======>
<div style="width:950px;position:absolute;top:1010px;">
<center>
<img id="04_1b" onclick="selectthisactb(this);" title="Albert Nobbs" src="img/d1.jpg" width="150" class="movies2" />
<img id="04_2b" onclick="selectthisactb(this);" title="The Help" src="img/a2.jpg" width="150" class="movies2" style="left:25px;" />
<img id="04_3b" onclick="selectthisactb(this);" title="The Girl with the Dragon Tattoo" src="img/d3.jpg" width="150" class="movies2" style="left:40px;" />
<img id="04_4b" onclick="selectthisactb(this);" title="The Iron Lady" src="img/d4.jpg" width="150" class="movies2" style="left:55px;" />
<img id="04_5b" onclick="selectthisactb(this);" title="We Need to Talk About Kevin" src="img/d5.jpg" width="150" class="movies2" style="left:70px;" />

<div style="position:relative;top:-200px;">
<img id="04_1" ondblclick="openimdb(this);" onclick="selectthisact(this);" title="Glenn Close" src="img/d11.jpg" width="150" class="movies2" />
<img id="04_2" ondblclick="openimdb(this);" onclick="selectthisact(this);" title="Viola Davis" src="img/d2.jpg" width="150" class="movies2" style="left:25px;" />
<img id="04_3" ondblclick="openimdb(this);" onclick="selectthisact(this);" title="Rooney Mara" src="img/d33.jpg" width="150" class="movies2" style="left:40px;" />
<img id="04_4" ondblclick="openimdb(this);" onclick="selectthisact(this);" title="Meryl Streep" src="img/d44.jpg" width="150" class="movies2" style="left:55px;" />
<img id="04_5" ondblclick="openimdb(this);" onclick="selectthisact(this);" title="Tilda Swinton" src="img/d55.jpg" width="150" class="movies2" style="left:70px;" />
</div>
</center>
</div>

<!=======5=======>
<div style="width:950px;position:absolute;top:1315px;">
<center>
<img id="05_1b" onclick="selectthisactb(this);" title="The Artist" src="img/b1.jpg" width="150" class="movies2" />
<img id="05_2b" onclick="selectthisactb(this);" title="The Guard" src="img/e2.jpg" width="150" class="movies2" style="left:25px;" />
<img id="05_3b" onclick="selectthisactb(this);" title="50/50" src="img/b3.jpg" width="150" class="movies2" style="left:40px;" />
<img id="05_4b" onclick="selectthisactb(this);" title="Crazy, Stupid, Love" src="img/e4.jpg" width="150" class="movies2" style="left:55px;" />
<img id="05_5b" onclick="selectthisactb(this);" title="Midnight in Paris" src="img/b4.jpg" width="150" class="movies2" style="left:70px;" />

<div style="position:relative;top:-200px;">
<img id="05_1" ondblclick="openimdb(this);" onclick="selectthisact(this);" title="Jean Dujardin" src="img/e1.jpg" width="150" class="movies2" />
<img id="05_2" ondblclick="openimdb(this);" onclick="selectthisact(this);" title="Brendan Gleeson" src="img/e22.jpg" width="150" class="movies2" style="left:25px;" />
<img id="05_3" ondblclick="openimdb(this);" onclick="selectthisact(this);" title="Joseph Gordon-Levitt" src="img/e3.jpg" width="150" class="movies2" style="left:40px;" />
<img id="05_4" ondblclick="openimdb(this);" onclick="selectthisact(this);" title="Ryan Gosling" src="img/c44.jpg" width="150" class="movies2" style="left:55px;" />
<img id="05_5" ondblclick="openimdb(this);" onclick="selectthisact(this);" title="Owen Wilson" src="img/e5.jpg" width="150" class="movies2" style="left:70px;" />
</div>
</center>
</div>

<!=======6=======>
<div style="width:950px;position:absolute;top:1620px;">
<center>
<img id="06_1b" onclick="selectthisactb(this);" title="Carnage" src="img/f1.jpg" width="150" class="movies2" />
<img id="06_2b" onclick="selectthisactb(this);" title="Young Adult" src="img/f2.jpg" width="150" class="movies2" style="left:25px;" />
<img id="06_3b" onclick="selectthisactb(this);" title="Bridesmaids" src="img/b2.jpg" width="150" class="movies2" style="left:40px;" />
<img id="06_4b" onclick="selectthisactb(this);" title="My Week with Marilyn" src="img/b5.jpg" width="150" class="movies2" style="left:55px;" />
<img id="06_5b" onclick="selectthisactb(this);" title="Carnage" src="img/f1.jpg" width="150" class="movies2" style="left:70px;" />

<div style="position:relative;top:-200px;">
<img id="06_1" ondblclick="openimdb(this);" onclick="selectthisact(this);" title="Jodie Foster" src="img/f11.jpg" width="150" class="movies2" />
<img id="06_2" ondblclick="openimdb(this);" onclick="selectthisact(this);" title="Charlize Theron" src="img/f22.jpg" width="150" class="movies2" style="left:25px;" />
<img id="06_3" ondblclick="openimdb(this);" onclick="selectthisact(this);" title="Kristen Wiig" src="img/f3.jpg" width="150" class="movies2" style="left:40px;" />
<img id="06_4" ondblclick="openimdb(this);" onclick="selectthisact(this);" title="Michelle Williams" src="img/f4.jpg" width="150" class="movies2" style="left:55px;" />
<img id="06_5" ondblclick="openimdb(this);" onclick="selectthisact(this);" title="Kate Winslet" src="img/f5.jpg" width="150" class="movies2" style="left:70px;" />
</div>
</center>
</div>

<!=======7=======>
<div style="width:950px;position:absolute;top:1925px;">
<center>
<img id="07_1b" onclick="selectthisactb(this);" title="My Week with Marilyn" src="img/b5.jpg" width="150" class="movies2" />
<img id="07_2b" onclick="selectthisactb(this);" title="Drive" src="img/g2.jpg" width="150" class="movies2" style="left:25px;" />
<img id="07_3b" onclick="selectthisactb(this);" title="Moneyball" src="img/a5.jpg" width="150" class="movies2" style="left:40px;" />
<img id="07_4b" onclick="selectthisactb(this);" title="A Dangerous Method" src="img/g4.jpg" width="150" class="movies2" style="left:55px;" />
<img id="07_5b" onclick="selectthisactb(this);" title="Beginners" src="img/g5.jpg" width="150" class="movies2" style="left:70px;" />

<div style="position:relative;top:-200px;">
<img id="07_1" ondblclick="openimdb(this);" onclick="selectthisact(this);" title="Kenneth Branagh" src="img/g11.jpg" width="150" class="movies2" />
<img id="07_2" ondblclick="openimdb(this);" onclick="selectthisact(this);" title="Albert Brooks" src="img/g22.jpg" width="150" class="movies2" style="left:25px;" />
<img id="07_3" ondblclick="openimdb(this);" onclick="selectthisact(this);" title="Jonah Hill" src="img/g33.jpg" width="150" class="movies2" style="left:40px;" />
<img id="07_4" ondblclick="openimdb(this);" onclick="selectthisact(this);" title="Viggo Mortensen" src="img/g44.jpg" width="150" class="movies2" style="left:55px;" />
<img id="07_5" ondblclick="openimdb(this);" onclick="selectthisact(this);" title="Christopher Plummer" src="img/g55.jpg" width="150" class="movies2" style="left:70px;" />
</div>
</center>
</div>

<!=======8=======>
<div style="width:950px;position:absolute;top:2230px;">
<center>
<img id="08_1b" onclick="selectthisactb(this);" title="The Artist" src="img/b1.jpg" width="150" class="movies2" />
<img id="08_2b" onclick="selectthisactb(this);" title="The Help" src="img/a2.jpg" width="150" class="movies2" style="left:25px;" />
<img id="08_3b" onclick="selectthisactb(this);" title="Albert Nobbs" src="img/d1.jpg" width="150" class="movies2" style="left:40px;" />
<img id="08_4b" onclick="selectthisactb(this);" title="The Help" src="img/a2.jpg" width="150" class="movies2" style="left:55px;" />
<img id="08_5b" onclick="selectthisactb(this);" title="The Descendants" src="img/a1.jpg" width="150" class="movies2" style="left:70px;" />

<div style="position:relative;top:-200px;">
<img id="08_1" ondblclick="openimdb(this);" onclick="selectthisact(this);" title="Bérénice Bejo" src="img/h11.jpg" width="150" class="movies2" />
<img id="08_2" ondblclick="openimdb(this);" onclick="selectthisact(this);" title="Jessica Chastain" src="img/h22.jpg" width="150" class="movies2" style="left:25px;" />
<img id="08_3" ondblclick="openimdb(this);" onclick="selectthisact(this);" title="Janet McTeer" src="img/h33.jpg" width="150" class="movies2" style="left:40px;" />
<img id="08_4" ondblclick="openimdb(this);" onclick="selectthisact(this);" title="Octavia Spencer" src="img/h44.jpg" width="150" class="movies2" style="left:55px;" />
<img id="08_5" ondblclick="openimdb(this);" onclick="selectthisact(this);" title="Shailene Woodley" src="img/h55.jpg" width="150" class="movies2" style="left:70px;" />
</div>
</center>
</div>

<!=======9=======>
<div style="width:950px;position:absolute;top:2535px;">
<center>
<img id="09_1b" onclick="selectthisactb(this);" title="Midnight in Paris" src="img/b4.jpg" width="150" class="movies2" />
<img id="09_2b" onclick="selectthisactb(this);" title="The Ides of March" src="img/a4.jpg" width="150" class="movies2" style="left:25px;" />
<img id="09_3b" onclick="selectthisactb(this);" title="The Artist" src="img/b1.jpg" width="150" class="movies2" style="left:40px;" />
<img id="09_4b" onclick="selectthisactb(this);" title="The Descendants" src="img/a1.jpg" width="150" class="movies2" style="left:55px;" />
<img id="09_5b" onclick="selectthisactb(this);" title="Hugo" src="img/a3.jpg" width="150" class="movies2" style="left:70px;" />

<div style="position:relative;top:-200px;">
<img id="09_1" ondblclick="openimdb(this);" onclick="selectthisact(this);" title="Woody Allen" src="img/i1.jpg" width="150" class="movies2" />
<img id="09_2" ondblclick="openimdb(this);" onclick="selectthisact(this);" title="George Clooney" src="img/c1.jpg" width="150" class="movies2" style="left:25px;" />
<img id="09_3" ondblclick="openimdb(this);" onclick="selectthisact(this);" title="Michel Hazanavicius" src="img/i3.jpg" width="150" class="movies2" style="left:40px;" />
<img id="09_4" ondblclick="openimdb(this);" onclick="selectthisact(this);" title="Alexander Payne" src="img/i4.jpg" width="150" class="movies2" style="left:55px;" />
<img id="09_5" ondblclick="openimdb(this);" onclick="selectthisact(this);" title="Martin Scorsese" src="img/i5.jpg" width="150" class="movies2" style="left:70px;" />
</div>
</center>
</div>

<!=======10=======>
<div style="width:950px;position:absolute;top:2855px;">
<center>
<img id="10_1" ondblclick="openimdb(this);" onclick="selectthis(this);" title="American Horror Story" src="img/j1.jpg" width="150" class="movies" />
<img id="10_2" ondblclick="openimdb(this);" onclick="selectthis(this);" title="Boardwalk Empire" src="img/j2.jpg" width="150" class="movies" style="left:25px;" />
<img id="10_3" ondblclick="openimdb(this);" onclick="selectthis(this);" title="Boss" src="img/j3.jpg" width="150" class="movies" style="left:40px;" />
<img id="10_4" ondblclick="openimdb(this);" onclick="selectthis(this);" title="Game of Thrones" src="img/j4.jpg" width="150" class="movies" style="left:55px;" />
<img id="10_5" ondblclick="openimdb(this);" onclick="selectthis(this);" title="Homeland" src="img/j5.jpg" width="150" class="movies" style="left:70px;" />
</center>
</div>

<!=======11=======>
<div style="width:950px;position:absolute;top:3160px;">
<center>
<img id="11_1" ondblclick="openimdb(this);" onclick="selectthis(this);" title="Enlightened" src="img/k1.jpg" width="150" class="movies" />
<img id="11_2" ondblclick="openimdb(this);" onclick="selectthis(this);" title="Episodes" src="img/k2.jpg" width="150" class="movies" style="left:25px;" />
<img id="11_3" ondblclick="openimdb(this);" onclick="selectthis(this);" title="Glee" src="img/k3.jpg" width="150" class="movies" style="left:40px;" />
<img id="11_4" ondblclick="openimdb(this);" onclick="selectthis(this);" title="Modern Family" src="img/k4.jpg" width="150" class="movies" style="left:55px;" />
<img id="11_5" ondblclick="openimdb(this);" onclick="selectthis(this);" title="New Girl" src="img/k5.jpg" width="150" class="movies" style="left:70px;" />
</center>
</div>

<!=======12=======>
<div style="width:950px;position:absolute;top:3450px;">
<center>
<img id="12_1b" onclick="selectthisactb(this);" title="Boardwalk Empire" src="img/j2.jpg" width="150" class="movies2" />
<img id="12_2b" onclick="selectthisactb(this);" title="Breaking Bad" src="img/l2.jpg" width="150" class="movies2" style="left:25px;" />
<img id="12_3b" onclick="selectthisactb(this);" title="Boss" src="img/j3.jpg" width="150" class="movies2" style="left:40px;" />
<img id="12_4b" onclick="selectthisactb(this);" title="The Borgias" src="img/l4.jpg" width="150" class="movies2" style="left:55px;" />
<img id="12_5b" onclick="selectthisactb(this);" title="Homeland" src="img/j5.jpg" width="150" class="movies2" style="left:70px;" />

<div style="position:relative;top:-200px;">
<img id="12_1" ondblclick="openimdb(this);" onclick="selectthisact(this);" title="Steve Buscemi" src="img/l11.jpg" width="150" class="movies2" />
<img id="12_2" ondblclick="openimdb(this);" onclick="selectthisact(this);" title="Bryan Cranston" src="img/l22.jpg" width="150" class="movies2" style="left:25px;" />
<img id="12_3" ondblclick="openimdb(this);" onclick="selectthisact(this);" title="Kelsey Grammer" src="img/l33.jpg" width="150" class="movies2" style="left:40px;" />
<img id="12_4" ondblclick="openimdb(this);" onclick="selectthisact(this);" title="Jeremy Irons" src="img/l44.jpg" width="150" class="movies2" style="left:55px;" />
<img id="12_5" ondblclick="openimdb(this);" onclick="selectthisact(this);" title="Damian Lewis" src="img/l55.jpg" width="150" class="movies2" style="left:70px;" />
</div>
</center>
</div>

<!=======13=======>
<div style="width:950px;position:absolute;top:3755px;">
<center>
<img id="13_1b" onclick="selectthisactb(this);" title="Homeland" src="img/j5.jpg" width="150" class="movies2" />
<img id="13_2b" onclick="selectthisactb(this);" title="The Killing" src="img/m2.jpg" width="150" class="movies2" style="left:25px;" />
<img id="13_3b" onclick="selectthisactb(this);" title="The Good Wife" src="img/m3.jpg" width="150" class="movies2" style="left:40px;" />
<img id="13_4b" onclick="selectthisactb(this);" title="Revenge" src="img/m4.jpg" width="150" class="movies2" style="left:55px;" />
<img id="13_5b" onclick="selectthisactb(this);" title="Necessary Roughness" src="img/m5.jpg" width="150" class="movies2" style="left:70px;" />

<div style="position:relative;top:-200px;">
<img id="13_1" ondblclick="openimdb(this);" onclick="selectthisact(this);" title="Claire Danes" src="img/m11.jpg" width="150" class="movies2" />
<img id="13_2" ondblclick="openimdb(this);" onclick="selectthisact(this);" title="Mireille Enos" src="img/m22.jpg" width="150" class="movies2" style="left:25px;" />
<img id="13_3" ondblclick="openimdb(this);" onclick="selectthisact(this);" title="Julianna Margulies" src="img/m33.jpg" width="150" class="movies2" style="left:40px;" />
<img id="13_4" ondblclick="openimdb(this);" onclick="selectthisact(this);" title="Madeleine Stowe" src="img/m44.jpg" width="150" class="movies2" style="left:55px;" />
<img id="13_5" ondblclick="openimdb(this);" onclick="selectthisact(this);" title="Callie Thorne" src="img/m55.jpg" width="150" class="movies2" style="left:70px;" />
</div>
</center>
</div>

<!=======14=======>
<div style="width:950px;position:absolute;top:4060px;">
<center>
<img id="14_1b" onclick="selectthisactb(this);" title="30 Rock" src="img/n1.jpg" width="150" class="movies2" />
<img id="14_2b" onclick="selectthisactb(this);" title="Californication" src="img/n2.jpg" width="150" class="movies2" style="left:25px;" />
<img id="14_3b" onclick="selectthisactb(this);" title="The Big Bang Theory" src="img/n3.jpg" width="150" class="movies2" style="left:40px;" />
<img id="14_4b" onclick="selectthisactb(this);" title="Hung" src="img/n4.jpg" width="150" class="movies2" style="left:55px;" />
<img id="14_5b" onclick="selectthisactb(this);" title="Episodes" src="img/k2.jpg" width="150" class="movies2" style="left:70px;" />

<div style="position:relative;top:-200px;">
<img id="14_1" ondblclick="openimdb(this);" onclick="selectthisact(this);" title="Alec Baldwin" src="img/n11.jpg" width="150" class="movies2" />
<img id="14_2" ondblclick="openimdb(this);" onclick="selectthisact(this);" title="David Duchovny" src="img/n22.jpg" width="150" class="movies2" style="left:25px;" />
<img id="14_3" ondblclick="openimdb(this);" onclick="selectthisact(this);" title="Johnny Galecki" src="img/n33.jpg" width="150" class="movies2" style="left:40px;" />
<img id="14_4" ondblclick="openimdb(this);" onclick="selectthisact(this);" title="Thomas Jane" src="img/n44.jpg" width="150" class="movies2" style="left:55px;" />
<img id="14_5" ondblclick="openimdb(this);" onclick="selectthisact(this);" title="Matt LeBlanc" src="img/n55.jpg" width="150" class="movies2" style="left:70px;" />
</div>
</center>
</div>

<!=======15=======>
<div style="width:950px;position:absolute;top:4365px;">
<center>
<img id="15_1b" onclick="selectthisactb(this);" title="Enlightened" src="img/k1.jpg" width="150" class="movies2" />
<img id="15_2b" onclick="selectthisactb(this);" title="New Girl" src="img/k5.jpg" width="150" class="movies2" style="left:25px;" />
<img id="15_3b" onclick="selectthisactb(this);" title="30 Rock" src="img/n1.jpg" width="150" class="movies2" style="left:40px;" />
<img id="15_4b" onclick="selectthisactb(this);" title="The Big C" src="img/o4.jpg" width="150" class="movies2" style="left:55px;" />
<img id="15_5b" onclick="selectthisactb(this);" title="Parks and Recreation" src="img/o5.jpg" width="150" class="movies2" style="left:70px;" />

<div style="width:950px;position:absolute;top:28px;">
<center>
<img id="15_1" ondblclick="openimdb(this);" onclick="selectthisact(this);" title="Laura Dern" src="img/o11.jpg" width="150" class="movies2" />
<img id="15_2" ondblclick="openimdb(this);" onclick="selectthisact(this);" title="Zooey Deschanel" src="img/o22.jpg" width="150" class="movies2" style="left:25px;" />
<img id="15_3" ondblclick="openimdb(this);" onclick="selectthisact(this);" title="Tina Fey" src="img/o33.jpg" width="150" class="movies2" style="left:40px;" />
<img id="15_4" ondblclick="openimdb(this);" onclick="selectthisact(this);" title="Laura Linney" src="img/o44.jpg" width="150" class="movies2" style="left:55px;" />
<img id="15_5" ondblclick="openimdb(this);" onclick="selectthisact(this);" title="Amy Poehler" src="img/o55.jpg" width="150" class="movies2" style="left:70px;" />
</center>
</div>
</center>
</div>

<!============Titles===============>
<div id="ttldiv" style="width:950px;position:absolute;top:34px;"></div>

<!============post===============>
<div style="background-image:url(img/post.jpg);width:950px;height:92px;position:absolute;top:4661px;">
<form name="postt" method="post" action="calwinner.php">
<input name="c" type="hidden" id="ch0" value="">
</form>
<div onclick="checkpost();" style="cursor:pointer;position:relative;width:99px;height:42px;left:-1px;top:23px;"></div>
</div>
</center>
</div>
</body>
</html>