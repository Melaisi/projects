<?php
$ans1=$_POST["ans1"];
$ans2=$_POST["ans2"];
$ans3=$_POST["ans3"];
$ans4=$_POST["ans4"];
$ans5=$_POST["ans5"];
$ans6=$_POST["ans6"];
$ans7=$_POST["ans7"];
$ans8=$_POST["ans8"];
$ans9=$_POST["ans9"];
$ans10=$_POST["ans10"];
$total=0;

if($ans1 == 1)
{	$total++;	}
if($ans2==1)
{	$total++;	}
if($ans3==1)
{	$total++;	}
if($ans4==1)
{	$total++;	}
if($ans5==1)
{	$total++;	}
if($ans6==1)
{	$total++;	}
if($ans7==1)
{	$total++;	}
if($ans8==1)
{	$total++;	}
if($ans9==1)
{	$total++;	}
if($ans10==1)
{	$total++;	}

$wrong = 10 - $total;
$perc = $total*100/10;

echo "Correct Ans :".$total."</br>";
echo "Wrong Ans :".$wrong."</br>";
echo "Percentage :".$perc."% </br>";

?> 