// JavaScript Document

function copyToClipboard() {
    if (window.clipboardData && clipboardData.setData) {
        clipboardData.setData('text',document.getElementById('cdtxt').innerHTML);
    }
}


var postorn;
var results="";
function checkpost()
{
	postorn=0;
for (var i=0;i<15;i++)
{
	if (!ch[i]>0)
	{
		document.getElementById('num'+(i+1)).scrollIntoView();
		i=14;
		postorn=1;
	}
}
	if (postorn==0)
	{
		results="";
		for (var i=0;i<14;i++)
		{
			results+=ch[i]+"r";
					}
		results+=ch[14];
		document.getElementById('ch0').value=results;
		document.postt.submit()
	}
}

var entttls = new Array("Best Motion Picture - Drama","Best Motion Picture - Musical or Comedy","Best Performance by an Actor in a Motion Picture - Drama","Best Performance by an Actress in a Motion Picture - Drama","Best Performance by an Actor in a Motion Picture - Musical or Comedy","Best Performance by an Actress in a Motion Picture - Musical or Comedy","Best Performance by an Actor in a Supporting Role in a Motion Picture","Best Performance by an Actress in a Supporting Role in a Motion Picture","Best Director - Motion Picture","Best Television Series - Drama","Best Television Series - Musical or Comedy","Best Performance by an Actor in a Television Series - Drama","Best Performance by an Actress in a Television Series - Drama","Best Performance by an Actor in a Television Series - Musical or Comedy","Best Performance by an Actress in a Television Series - Musical or Comedy");

var artttls = new Array;
artttls[0]="أفضل فيلم عن فئة الدراما";
artttls[1]="أفضل فيلم عن فئة الكوميديا أو الموسيقى";
artttls[2]="أفضل ممثل رئيسي عن فئة الدراما";
artttls[3]="أفضل ممثلة رئيسية عن فئة الدراما";
artttls[4]="أفضل ممثل رئيسي عن فئة الكوميديا أو الموسيقى";
artttls[5]="أفضل ممثلة رئيسية عن فئة الكوميديا أو الموسيقى";
artttls[6]="أفضل ممثل مساعد";
artttls[7]="أفضل ممثلة مساعدة";
artttls[8]="أفضل مخرج";
artttls[9]="أفضل مسلسل عن فئة الدراما";
artttls[10]="أفضل مسلسل عن فئة الكوميديا أو الموسيقى";
artttls[11]="أفضل ممثل رئيسي لمسلسل عن فئة الدراما";
artttls[12]="أفضل ممثلة رئيسية لمسلسل عن فئة الدراما";
artttls[13]="أفضل ممثل رئيسي لمسلسل عن فئة الكوميديا او الموسيقى";
artttls[14]="أفضل ممثلة رئيسية لمسلسل عن فئة الكوميديا أو الموسيقى";

function showttls()
{
var allttl="";
for (var i=1;i<=15;i++)
{
	allttl += "<p id='num" + i + "' class='titleea teng' style='top:" + (i-1)*305 + "px;'>" + entttls[i-1] + "</p>"
	+ "<p class='titleea tar' style='top:" + (1+(i-1)*305) + "px;'>" + artttls[i-1] + "</p>";
}
document.getElementById('ttldiv').innerHTML=allttl;
}

var imdb1 = new Array();
imdb1[0]="http://www.imdb.com/title/tt1033575/";
imdb1[1]="http://www.imdb.com/title/tt1454029/";
imdb1[2]="http://www.imdb.com/title/tt0970179/";
imdb1[3]="http://www.imdb.com/title/tt1124035/";
imdb1[4]="http://www.imdb.com/title/tt1210166/";
imdb1[5]="http://www.imdb.com/title/tt1568911/";

var imdb2 = new Array();
imdb2[0]="http://www.imdb.com/title/tt1655442/";
imdb2[1]="http://www.imdb.com/title/tt1478338/";
imdb2[2]="http://www.imdb.com/title/tt1306980/";
imdb2[3]="http://www.imdb.com/title/tt1605783/";
imdb2[4]="http://www.imdb.com/title/tt1655420/";
imdb2[5]="http://www.imdb.com/title/tt1033575/";
imdb2[6]="http://www.imdb.com/title/tt1616195/";
imdb2[7]="http://www.imdb.com/title/tt1723811/";
imdb2[8]="http://www.imdb.com/title/tt1124035/";
imdb2[9]="http://www.imdb.com/title/tt1210166/";
imdb2[10]="http://www.imdb.com/title/tt1602098/";
imdb2[11]="http://www.imdb.com/title/tt1454029/";
imdb2[12]="http://www.imdb.com/title/tt1568346/";
imdb2[13]="http://www.imdb.com/title/tt1007029/";
imdb2[14]="http://www.imdb.com/title/tt1242460/";
imdb2[15]="http://www.imdb.com/title/tt1655442/";
imdb2[16]="http://www.imdb.com/title/tt1540133/";
imdb2[17]="http://www.imdb.com/title/tt1306980/";
imdb2[18]="http://www.imdb.com/title/tt1570728/";
imdb2[19]="http://www.imdb.com/title/tt1605783/";
imdb2[20]="http://www.imdb.com/title/tt1692486/";
imdb2[21]="http://www.imdb.com/title/tt1625346/";
imdb2[22]="http://www.imdb.com/title/tt1478338/";
imdb2[23]="http://www.imdb.com/title/tt1655420/";
imdb2[24]="http://www.imdb.com/title/tt1692486/";
imdb2[25]="http://www.imdb.com/title/tt1655420/";
imdb2[26]="http://www.imdb.com/title/tt0780504/";
imdb2[27]="http://www.imdb.com/title/tt1210166/";
imdb2[28]="http://www.imdb.com/title/tt1571222/";
imdb2[29]="http://www.imdb.com/title/tt1532503/";
imdb2[30]="http://www.imdb.com/title/tt1655442/";
imdb2[31]="http://www.imdb.com/title/tt1454029/";
imdb2[32]="http://www.imdb.com/title/tt1602098/";
imdb2[33]="http://www.imdb.com/title/tt1454029/";
imdb2[34]="http://www.imdb.com/title/tt1033575/";
imdb2[35]="http://www.imdb.com/title/tt1605783/";
imdb2[36]="http://www.imdb.com/title/tt1124035/";
imdb2[37]="http://www.imdb.com/title/tt1655442/";
imdb2[38]="http://www.imdb.com/title/tt1033575/";
imdb2[39]="http://www.imdb.com/title/tt0970179/";
imdb2[40]="http://www.imdb.com/title/tt1844624/";
imdb2[41]="http://www.imdb.com/title/tt0979432/";
imdb2[42]="http://www.imdb.com/title/tt1833285/";
imdb2[43]="http://www.imdb.com/title/tt0944947/";
imdb2[44]="http://www.imdb.com/title/tt1796960/";
imdb2[45]="http://www.imdb.com/title/tt1509004/";
imdb2[46]="http://www.imdb.com/title/tt1582350/";
imdb2[47]="http://www.imdb.com/title/tt1327801/";
imdb2[48]="http://www.imdb.com/title/tt1442437/";
imdb2[49]="http://www.imdb.com/title/tt1826940/";
imdb2[50]="http://www.imdb.com/title/tt0979432/";
imdb2[51]="http://www.imdb.com/title/tt0903747/";
imdb2[52]="http://www.imdb.com/title/tt1833285/";
imdb2[53]="http://www.imdb.com/title/tt1582457/";
imdb2[54]="http://www.imdb.com/title/tt1796960/";
imdb2[55]="http://www.imdb.com/title/tt1796960/";
imdb2[56]="http://www.imdb.com/title/tt1637727/";
imdb2[57]="http://www.imdb.com/title/tt1442462/";
imdb2[58]="http://www.imdb.com/title/tt1837642/";
imdb2[59]="http://www.imdb.com/title/tt1657505/";
imdb2[60]="http://www.imdb.com/title/tt0496424/";
imdb2[61]="http://www.imdb.com/title/tt0904208/";
imdb2[62]="http://www.imdb.com/title/tt0898266/";
imdb2[63]="http://www.imdb.com/title/tt1229413/";
imdb2[64]="http://www.imdb.com/title/tt1582350/";
imdb2[65]="http://www.imdb.com/title/tt1509004/";
imdb2[66]="http://www.imdb.com/title/tt1826940/";
imdb2[67]="http://www.imdb.com/title/tt0496424/";
imdb2[68]="http://www.imdb.com/title/tt1515193/";
imdb2[69]="http://www.imdb.com/title/tt1266020/";


var ch = new Array();
function selectthis1(sender)
{
	var qnum = (sender.id).slice(0,3);
	for (var i=1;i<=6;i++)
	{
		document.getElementById(qnum + i).className="movies1_not";
	}
	sender.className="movies1";
	ch[(sender.id).slice(0,2)-1]=(sender.id).charAt(3);
}

function selectthis(sender)
{
	var qnum = (sender.id).slice(0,3);
	for (var i=1;i<=5;i++)
	{
		document.getElementById(qnum + i).className="movies_not";
	}
	sender.className="movies";
	ch[(sender.id).slice(0,2)-1]=(sender.id).charAt(3);
}

function openimdb1(sender)
{
	window.open(imdb1[(sender.id).charAt(3)-1],'_blank',
 'menubar, toolbar, location, directories, status, scrollbars, resizable, dependent, width=720, height=480, fullscreen=1, center=1')
}

function openimdb(sender)
{
	window.open(imdb2[((sender.id).charAt(3)-1)+5*((sender.id).slice(0,2)-2)],'_blank',
 'menubar, toolbar, location, directories, status, scrollbars, resizable, dependent, width=720, height=480, fullscreen=1, center=1')
}

function selectthisact(sender)
{
	var qnum = (sender.id).slice(0,3);
	for (var i=1;i<=5;i++)
	{
		document.getElementById(qnum + i).className="movies2_not";
		document.getElementById(qnum + i + "b").className="movies2_not";
	}
	document.getElementById(qnum + (sender.id).charAt(3)).className="movies2";
	document.getElementById(qnum + (sender.id).charAt(3) + "b").className="movies2";
	ch[(sender.id).slice(0,2)-1]=(sender.id).charAt(3);
	for (var i=1;i<=5;i++)
	{
	document.getElementById((sender.id).slice(0,3)+i+"b").style.opacity=0.3;
	}
	document.getElementById((sender.id).slice(0,4)+"b").style.opacity=1;
}

function selectthisactb(sender)
{
	var backsrc = sender.src;
	var frontsrc = document.getElementById((sender.id).slice(0,4)).src;
	sender.src=frontsrc;
	document.getElementById((sender.id).slice(0,4)).src=backsrc;
	var backttl = sender.title;
	var frontttl = document.getElementById((sender.id).slice(0,4)).title;
	sender.title=frontttl;
	document.getElementById((sender.id).slice(0,4)).title=backttl;
}


/*var list = new array();
list[0]="افضل فيلم عن فئة الدراما" + "@" + "The Descendants" + "#" + "aimg" + "#" + "http://www.imdb.com/title/tt1033575/" + "#" + "http://youtu.be/CWHNXJ1K4yA"*/