-- phpMyAdmin SQL Dump
-- version 3.4.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 15, 2012 at 09:56 PM
-- Server version: 5.1.60
-- PHP Version: 5.2.17

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `mimcom_cinma`
--

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `ID` int(5) NOT NULL AUTO_INCREMENT,
  `user` varchar(20) DEFAULT NULL,
  `point` int(3) DEFAULT '0',
  `ch1` int(1) DEFAULT NULL,
  `ch2` int(1) DEFAULT NULL,
  `ch3` int(1) DEFAULT NULL,
  `ch4` int(1) DEFAULT NULL,
  `ch5` int(1) DEFAULT NULL,
  `ch6` int(1) DEFAULT NULL,
  `ch7` int(1) DEFAULT NULL,
  `ch8` int(1) DEFAULT NULL,
  `ch9` int(1) DEFAULT NULL,
  `ch10` int(1) DEFAULT NULL,
  `ch11` int(1) DEFAULT NULL,
  `ch12` int(1) DEFAULT NULL,
  `ch13` int(1) DEFAULT NULL,
  `ch14` int(1) DEFAULT NULL,
  `ch15` int(1) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `user` (`user`),
  UNIQUE KEY `user_2` (`user`),
  UNIQUE KEY `user_3` (`user`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=50 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`ID`, `user`, `point`, `ch1`, `ch2`, `ch3`, `ch4`, `ch5`, `ch6`, `ch7`, `ch8`, `ch9`, `ch10`, `ch11`, `ch12`, `ch13`, `ch14`, `ch15`) VALUES
(1, 'اول تجربة', 0, 1, 3, 3, 1, 5, 3, 1, 5, 4, 5, 2, 1, 5, 2, 1),
(2, 'R - HSN', 0, 3, 4, 2, 2, 4, 2, 2, 4, 4, 2, 4, 2, 5, 1, 2),
(3, 'العنيد12', 0, 5, 4, 3, 3, 5, 4, 4, 5, 4, 4, 4, 5, 3, 4, 4),
(4, 'بقعة ضوء', 0, 3, 1, 3, 5, 5, 2, 3, 5, 5, 5, 4, 2, 1, 1, 5),
(5, NULL, 0, 3, 3, 5, 5, 3, 2, 3, 4, 5, 5, 4, 2, 1, 1, 2),
(6, 'طرطيعة', 0, 2, 5, 5, 4, 3, 3, 3, 4, 3, 4, 4, 2, 4, 3, 3),
(7, 'سماء !', 0, 4, 3, 1, 4, 4, 3, 4, 5, 2, 5, 3, 2, 3, 3, 2),
(8, 'معقم ديتول', 0, 2, 3, 5, 1, 3, 2, 3, 1, 4, 3, 5, 1, 3, 1, 2),
(9, NULL, 0, 4, 3, 5, 1, 5, 2, 3, 3, 1, 3, 3, 2, 2, 5, 2),
(10, 'عربجي', 0, 2, 3, 3, 3, 3, 1, 3, 1, 2, 4, 4, 2, 3, 3, 3),
(11, NULL, 0, 2, 1, 3, 1, 1, 5, 4, 1, 5, 2, 4, 2, 1, 1, 4),
(12, NULL, 0, 2, 3, 5, 1, 3, 2, 4, 3, 1, 4, 2, 5, 3, 5, 2),
(13, 'zezoom22', 0, 4, 3, 1, 4, 5, 2, 2, 5, 2, 4, 4, 1, 4, 2, 2),
(14, 'تحت المطر', 0, 4, 2, 3, 2, 5, 3, 1, 4, 3, 4, 4, 2, 3, 3, 2),
(15, 'محطة غرآم', 0, 2, 4, 1, 4, 1, 4, 1, 1, 2, 2, 4, 2, 1, 3, 4),
(16, NULL, 0, 3, 1, 5, 5, 3, 2, 4, 4, 5, 2, 3, 3, 1, 1, 4),
(17, 'Mr.Keiton', 0, 5, 1, 5, 5, 3, 2, 4, 4, 5, 2, 3, 5, 1, 1, 4),
(18, 'داعس بشويش', 0, 5, 3, 2, 4, 5, 4, 1, 2, 4, 4, 2, 2, 1, 5, 1),
(19, 'βđώỉ', 0, 6, 3, 4, 3, 4, 3, 3, 4, 3, 2, 4, 2, 1, 3, 5),
(20, 'Wonderment', 0, 2, 3, 4, 2, 3, 3, 2, 1, 5, 4, 4, 1, 3, 1, 2),
(21, NULL, 0, 5, 3, 5, 2, 1, 3, 3, 4, 5, 5, 4, 2, 1, 1, 2),
(22, NULL, 0, 3, 3, 2, 3, 5, 1, 3, 5, 5, 4, 4, 3, 1, 3, 2),
(23, NULL, 0, 3, 3, 2, 3, 5, 1, 3, 5, 5, 4, 4, 3, 1, 3, 23),
(24, NULL, 0, 3, 3, 2, 3, 5, 1, 3, 5, 5, 4, 4, 3, 1, 3, 2),
(25, NULL, 0, 1, 1, 3, 2, 5, 5, 3, 4, 1, 5, 4, 2, 1, 4, 2),
(26, 'تجربة', 0, 6, 4, 5, 2, 3, 2, 2, 3, 3, 3, 4, 3, 3, 3, 2),
(27, 'رتيــــل', 0, 2, 5, 1, 5, 5, 2, 1, 3, 3, 1, 1, 3, 3, 3, 1),
(28, NULL, 0, 3, 3, 2, 3, 5, 1, 3, 1, 5, 4, 4, 3, 1, 3, 2),
(29, NULL, 0, 6, 3, 2, 4, 2, 3, 4, 3, 3, 2, 2, 3, 3, 2, 3),
(30, NULL, 0, 1, 2, 3, 2, 3, 3, 2, 4, 3, 3, 2, 4, 3, 2, 3),
(31, NULL, 0, 4, 3, 4, 4, 5, 3, 4, 5, 3, 5, 4, 2, 1, 3, 2),
(32, NULL, 0, 4, 3, 4, 4, 5, 3, 4, 5, 3, 5, 4, 2, 1, 3, 2),
(33, NULL, 0, 2, 4, 3, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4),
(34, '[ Abo - sdz ]', 0, 5, 3, 5, 2, 1, 3, 3, 4, 5, 5, 4, 2, 1, 1, 2),
(35, 'تمـَرٍدْ ~', 0, 4, 4, 5, 2, 3, 2, 2, 1, 5, 3, 4, 2, 1, 4, 5),
(36, 'مآعآد بدري', 0, 3, 1, 3, 5, 1, 4, 2, 1, 3, 4, 2, 1, 3, 5, 2),
(37, 'لمت نفسي', 0, 4, 1, 1, 2, 1, 3, 2, 1, 5, 3, 4, 2, 1, 4, 5),
(38, NULL, 0, 4, 2, 3, 2, 5, 3, 1, 4, 3, 4, 4, 2, 3, 3, 2),
(39, 'W i ή T e r', 0, 5, 1, 4, 1, 1, 4, 3, 4, 5, 4, 3, 2, 3, 1, 5),
(40, 'Prince of Seas', 0, 1, 1, 2, 3, 1, 4, 3, 1, 3, 4, 2, 1, 3, 5, 2),
(41, 'AL RЄЄM', 0, 2, 3, 5, 2, 3, 2, 2, 2, 3, 4, 2, 5, 2, 4, 2),
(42, '°·.¸.•°مطفشهم°·.¸.•°', 0, 2, 3, 5, 2, 3, 2, 2, 2, 3, 4, 2, 5, 2, 4, 2),
(43, NULL, 0, 4, 4, 1, 4, 5, 3, 1, 2, 2, 3, 3, 2, 3, 3, 2),
(44, 'دب بس نحيف', 0, 3, 1, 3, 5, 5, 2, 4, 3, 5, 5, 4, 2, 1, 3, 4),
(45, 'KEIRA', 0, 2, 1, 1, 5, 5, 3, 1, 3, 3, 1, 1, 3, 3, 3, 1),
(46, NULL, 0, 1, 3, 2, 3, 5, 4, 1, 5, 4, 4, 2, 4, 4, 5, 2),
(47, NULL, 0, 1, 3, 2, 3, 5, 4, 1, 5, 4, 4, 2, 4, 4, 5, 2),
(48, NULL, 0, 1, 3, 2, 3, 5, 4, 1, 5, 4, 4, 2, 4, 4, 5, 2),
(49, '● someone ●', 0, 1, 3, 2, 3, 5, 4, 1, 1, 4, 4, 2, 4, 4, 5, 2);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
