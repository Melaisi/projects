﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Msa6el Cinema - Winner</title>
<link rel="stylesheet" type="text/css" href="styles.css" />
<script src="javascript.js" type="text/javascript"></script>
</head>
<body>
<div id="topbar"><center><p id="mtitle">مسابقة التوقعات - حارة المساطيل</p></center></div>
<br />

<?php

$con = mysql_connect("localhost","root","");
if (!$con)
  {
  die('Could not connect: DataBase erorr ');
  }
mysql_select_db("cinma", $con);

$q_win = "select ID, user, point from user where user <> '' order by point DESC ";
	$db_win = mysql_query($q_win);
	
	
	echo '<div align="center" id="body1" style="background-image:none;background-color:#ebf2e0;padding:0px;
margin:0 auto;
width:950px;
background-position:center top;
border:solid 1px #3b615f;
border-radius:0px 0px 0px 0px;
-moz-box-shadow: 0px 0px 5px #446e6c;
-webkit-box-shadow: 0px 0px 5px #446e6c;
box-shadow: 0px 0px 5px #446e6c;
//
webkit-user-select: none;
-khtml-user-select: none;
-moz-user-select: none;
-o-user-select: none;
-ms-user-select: none;
user-select: none;" unselectable="on">
<p align="center" style="color:#163f3e;font:\'Comic Sans MS\', cursive;font-size:19px;font-weight:600;;padding-right:25px;padding-left:15px;">';

	echo "<table >
		<caption>ترتيب الاعضاء حسب النقاط المحتسبة</caption>
		<tr>
			<th class='win_th'>ID </th>
			<th class='win_th'>Username</th>
			<th class='win_th'>Points</th>
		</tr>";
	while($win_row = mysql_fetch_array($db_win))
	  {
		  echo "<tr class='win_tr'>";
		  echo "<td class='win_td'>" . $win_row['ID'] . "</td>";
		  echo "<td class='win_td'>" . $win_row['user'] . "</td>";
		  echo "<td class='win_td'>" . $win_row['point'] . "</td>";
		  echo "</tr>";
	  }
	echo "</table></p></div>";
	
mysql_close($con);


?>
</body>
</html>