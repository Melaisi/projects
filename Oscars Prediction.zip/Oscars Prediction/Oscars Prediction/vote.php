﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Msa6el Cinema - My Vote</title>
<link rel="stylesheet" type="text/css" href="styles.css" />
<script src="javascript.js" type="text/javascript"></script>
</head>
<body>
<div id="topbar"><center><p id="mtitle">مسابقة التوقعات - حارة المساطيل</p></center></div>
<br />

<?php
$result = explode("r",$_POST["c"]);
$con = mysql_connect("localhost","mimcom_cinma","365214");
if (!$con)
  {
  die('Could not connect: DataBase erorr ');
  }
mysql_select_db("mimcom_cinma", $con);
$sql="INSERT INTO user (ch1, ch2, ch3, ch4, ch5, ch6, ch7, ch8, ch9, ch10, ch11, ch12, ch13, ch14, ch15)
VALUES
(".$result[0].",".$result[1].",".$result[2].",".$result[3].",".$result[4].",".$result[5].",".$result[6].",".$result[7].",".$result[8].",".$result[9].",".$result[10].",".$result[11].",".$result[12].",".$result[13].",".$result[14].")";
	
	if (!mysql_query($sql,$con))
  {
  die('Error: DataBase erorr ') ;
  }
  $sql = "SELECT * FROM `user` ORDER BY `ID` DESC ";
$q_ID = mysql_query($sql);
$ID = mysql_fetch_array( $q_ID );
mysql_close($con);
require_once('bbcode.php');
//echo "تمت اضافة توقعاتك لقاعدة البيانات رقمك الخاص بالموقع هو : ".$ID[0];
//Body code :: 

print '<div dir="rtl" id="body" style="background-image:none;background-color:#ebf2e0;padding:0px;
height:435px;" unselectable="on">
<p style="color:#163f3e;font:\'Comic Sans MS\', cursive;font-size:19px;font-weight:600;;padding-right:25px;padding-left:15px;">
نشكرك لاستخدام هذا الموقع، رقم ID الخاص بك هو: '.$ID[0].'
</p>
<p style="color:#163f3e;font:\'Comic Sans MS\', cursive;font-size:20px;font-weight:530;;padding-right:25px;padding-left:15px;">
بإمكانك نسخ اختياراتك بتنسيق مناسب لاستخدامه في المنتديات من الصندوق أدناه،
ويسعدنا أن تشارك معنا في مسابقة التوقعات الخاصة بمنتديات حارة المساطيل على هذا الرابط: 
<a href="http://msa6el.mbc.net/vb/tt93699.html" style="color:#123332;font-weight:bold;text-decoration:none;font-size:18px;">مسابقة توقعات || The Golden Globe Award</a></p>
<center><textarea dir="ltr" id="cdtxt" class="txtarea" wrap="hard" readonly="yes" onclick="this.focus();this.select();">
'.$txtarea.'[CENTER][COLOR="DarkRed"]My Id in [URL="http://www.mr-mim.com/msa6el/cinema/"]Msa6el cinema vote[/URL] is:'.$ID[0].'[/COLOR][/CENTER]
</textarea>

</div>';

?>
</body>
</html>