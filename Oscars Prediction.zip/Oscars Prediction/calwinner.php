﻿<!--
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Msa6el Cinema - Winner</title>
<link rel="stylesheet" type="text/css" href="styles.css" />
<script src="javascript.js" type="text/javascript"></script>
</head>
<body>
<div id="topbar"><center><p id="mtitle">مسابقة التوقعات - حارة المساطيل</p></center></div>
<br />
-->
<?php

		$result = explode("r",$_POST["c"]);
		$con = mysql_connect("localhost","mimcom_cinma","365214");
		if (!$con)
		  {
		  die('Could not connect: DataBase erorr ');
		  }
		mysql_select_db("cinma", $con);
		$rqlselect ="select * from user";
		$Rselect = mysql_query($rqlselect);
		
		while ($row= mysql_fetch_array ($Rselect));
			print_r($result);
			print_r($row);
			$r=0;
			foreach ($row as $k)
			{
				$point=0;
				$ri=0;
				
				for ($i=3;$i<=17;$i++)
				{	
					if ($row[$r][$i] == $result[$ri])
						{$point++;}
					
					$ri++;
				}
					$insert_sql="UPDATE user SET point = '".$point."' WHERE ID ='".$row[$r][0]."' ";
					mysql_query($insert_sql);
					
					$r++;
			}
			mysql_close($con);
			
			/*print '
			
			<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>Msa6el Cinema - Winner</title>
<link rel="stylesheet" type="text/css" href="styles.css" />
<script src="javascript.js" type="text/javascript"></script>
</head>
<body>
<div id="topbar"><center><p id="mtitle">مسابقة التوقعات - حارة المساطيل</p></center></div>
<br />

			
			<div dir="rtl" id="body" style="background-image:none;background-color:#ebf2e0;padding:0px;
height:435px;" unselectable="on">
<p style="color:#163f3e;font:\'Comic Sans MS\', cursive;font-size:19px;font-weight:600;;padding-right:25px;padding-left:15px;">
تمت عملية احتساب النقاط بنجاح سيتم تحويلك الياَ لصفحة النتائج بعد خمس ثواني 
</p>';*/

?>
</body>
</html>