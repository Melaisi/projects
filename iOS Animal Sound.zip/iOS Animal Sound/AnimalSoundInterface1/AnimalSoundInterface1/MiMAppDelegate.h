//
//  MiMAppDelegate.h
//  AnimalSoundInterface1
//
//  Created by MiM on 3/25/14.
//  Copyright (c) 2014 MiM. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MiMAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
