//
//  MiMViewController.m
//  AnimalSoundInterface1
//
//  Created by MiM on 3/25/14.
//  Copyright (c) 2014 MiM. All rights reserved.
//

#import "MiMViewController.h"

@interface MiMViewController ()

@end

@implementation MiMViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
	
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
	NSLog(@"%@",self);
}
@end
