//
//  mainViewController.h
//  FunnyAnimalSound
//
//  Created by MiM on 3/23/14.
//  Copyright (c) 2014 MiM. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface mainViewController : UIViewController

@end
