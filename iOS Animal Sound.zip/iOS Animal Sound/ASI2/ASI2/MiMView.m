//
//  MiMView.m
//  ASI2
//
//  Created by MiM on 3/25/14.
//  Copyright (c) 2014 MiM. All rights reserved.
//

#import "MiMView.h"

@implementation MiMView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
