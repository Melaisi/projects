//
//  MiMAnimal.m
//  ASI2
//
//  Created by MiM on 3/25/14.
//  Copyright (c) 2014 MiM. All rights reserved.
//

#import "MiMAnimal.h"

@implementation MiMAnimal

- (instancetype) initWithName:(NSString *)name image:(UIImage *)image audioPath:(NSString *)audioPath{
	self = [super init];
	if (self) {
		_name = name;
		_image=image;
		_audioPath = audioPath;
		_imageView.image=image;
		}

	return self;
}

@end
