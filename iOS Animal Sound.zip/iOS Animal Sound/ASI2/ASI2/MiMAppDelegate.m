//
//  MiMAppDelegate.m
//  ASI2
//
//  Created by MiM on 3/25/14.
//  Copyright (c) 2014 MiM. All rights reserved.
//

#import "MiMAppDelegate.h"
#import "MiMViewController.h"
#import "MiMView.h"
#import "MiMAnimal.h"

@implementation MiMAppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    // Override point for customization after application launch.
    self.window.backgroundColor = [UIColor whiteColor];
	MiMViewController *vc =[[MiMViewController alloc] init];
	
	// Array of animal { name , Image , sound }
	NSMutableArray *animalArray;
	[animalArray addObject:[
					    [MiMAnimal alloc]
					    initWithName:@"01"
					    image:[UIImage imageNamed:@"01.png"]
					    audioPath:[[NSBundle mainBundle] pathForResource:@"cat" ofType:@"mp3"]
					    ]
	 ];
	[animalArray addObject:[
					    [MiMAnimal alloc]
					    initWithName:@"02"
					    image:[UIImage imageNamed:@"02.png"]
					    audioPath:[[NSBundle mainBundle] pathForResource:@"cat" ofType:@"mp3"]
					    ]
	 ];
	
	// get number of animal in the array to calculate ther full rect size for view frame
	CGRect rect = self.window.bounds;
	//rect.size.height = rect.size.height * ( [animalArray count] / 6 );
	//rect.size.height *=4;
	// creat scrollview with the size of rect
		UIScrollView *scrollView = [[UIScrollView alloc] initWithFrame:rect];
		scrollView.backgroundColor = [UIColor redColor];
		scrollView.pagingEnabled = YES;
	// Creat view with bigrect
	CGRect bigRect = rect;
	bigRect.origin.y=20;
	if ([animalArray count] >6) {
		bigRect.size.height *= ( [animalArray count] / 6 ) +1;
	}
	
	MiMView *mainView = [[MiMView alloc]initWithFrame:bigRect];
	mainView.backgroundColor =[UIColor whiteColor];
	
	// for each animal in array creat UIamgeView on position as 3 in line
	CGRect animalRect;
	animalRect.origin = bigRect.origin;
	
	//add the animal to the scrollview

	// add the scroll view to viewControl as view
	//vc.view = scrollView;
	
	//self.window.rootViewController =vc;
	 [scrollView addSubview:mainView];
	scrollView.contentSize=bigRect.size;
	[self.window addSubview:scrollView];
	
	[self.window makeKeyAndVisible];
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application
{
	// Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
	// Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
	// Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
	// If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
	// Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
	// Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
	// Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
