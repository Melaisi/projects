//
//  MiMAnimal.h
//  ASI2
//
//  Created by MiM on 3/25/14.
//  Copyright (c) 2014 MiM. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>
@interface MiMAnimal : NSObject

@property (nonatomic , weak) NSString *name;
@property (nonatomic , weak) UIImage *image;
@property (nonatomic , weak) NSString *audioPath;
@property (nonatomic , strong) UIImageView *imageView;

-(instancetype) initWithName:(NSString *)name
				   image:(UIImage *)image
			    audioPath:(NSString *)audioPath;

@end
