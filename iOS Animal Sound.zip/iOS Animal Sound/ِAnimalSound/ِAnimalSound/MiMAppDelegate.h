//
//  MiMAppDelegate.h
//  ِAnimalSound
//
//  Created by MiM on 3/24/14.
//  Copyright (c) 2014 MiM. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MiMAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
