//
//  MiMAnimal.m
//  AS3
//
//  Created by MiM on 3/27/14.
//  Copyright (c) 2014 MiM. All rights reserved.
//

#import "MiMAnimal.h"

@implementation MiMAnimal

-(instancetype) initWithName:(NSString *)name
				   image:(UIImage *)image{
	_name = name;
	_image = image;
	
	return self;
}

-(void) playSound{
	
	
}

- (NSString *)description {
	return _name;
}

@end
