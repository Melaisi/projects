//
//  MiMAudioPlayer.h
//  AS3
//
//  Created by MiM on 4/3/14.
//  Copyright (c) 2014 MiM. All rights reserved.
//
//
//#import <AVFoundation/AVFoundation.h>
//#import <UIKit/UIKit.h>
//
//@interface MiMAudioPlayer : NSObject
//
//+ ( NSString *) name;
//@property (nonatomic , strong) AVAudioPlayer *soundPlayer;
//
//+(void)playSound;
//@end
