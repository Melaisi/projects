//
//  MiMView.h
//  AS3
//
//  Created by MiM on 3/27/14.
//  Copyright (c) 2014 MiM. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>

@interface MiMView : UIView
@property (nonatomic , strong) AVAudioPlayer *soundPlayer;
-(void) playSoundWithname:(NSString *) name ;

@end
