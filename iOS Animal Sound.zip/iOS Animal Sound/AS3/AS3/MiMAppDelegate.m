//
//  MiMAppDelegate.m
//  AS3
//
//  Created by MiM on 3/27/14.
//  Copyright (c) 2014 MiM. All rights reserved.
//

#import "MiMAppDelegate.h"
#import "MiMScrollView.h"
#import "MiMView.h"
#import "MiMAnimalImage.h"
#import "MiMAnimal.h"

@implementation MiMAppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    // Override point for customization after application launch.
	self.window.backgroundColor = [UIColor whiteColor];
	NSMutableArray *animalArray = [[NSMutableArray alloc]init];
	NSString *name;
	UIImage *image;
	for (int i=1; i<=20; i++) {
		if (i<10) {
			name =[[NSString alloc] initWithFormat:@"00%d",i ];
			
			image = [UIImage imageNamed:[[NSString alloc]initWithFormat:@"00%d.png",i]];
		}
		else{
			name =[[NSString alloc] initWithFormat:@"0%d",i ];
			image = [UIImage imageNamed:[[NSString alloc]initWithFormat:@"0%d.png",i]];
		}
		
		[animalArray addObject:[[MiMAnimal alloc] initWithName:name image:image ]];
	}
	

	NSLog(@"%@",animalArray);
	
	MiMScrollView *scrollView = [[MiMScrollView alloc] initWithFrame:self.window.bounds];
		//View Rect
		CGRect viewRect = self.window.bounds;
		//View origin X=0 , Y=20
		viewRect.origin.y = 20;
		// calculate view Height !
		unsigned long int numberOfRow = [animalArray count]/2;
		if ( (numberOfRow)%2 != 0) {
			numberOfRow++;
		}
		int imageRectHeight = 100;
		int imageRectWidth = 100;
		int increaseInRow = 50;
		int increaseInColumon = 50;
		
		float viewRectHeight = (imageRectHeight * numberOfRow) + (increaseInRow * numberOfRow);
		viewRect.size.height=viewRectHeight;
		
		//imageRect initalize
		CGRect imageRect = CGRectMake(0, 0, imageRectWidth, imageRectHeight);
	
		MiMView *view = [[MiMView alloc] initWithFrame:viewRect];
			int i=1;
			for (MiMAnimal *animal in animalArray) {
				imageRect.origin.x =0;
				if (i>1 && i%2 == 1) {
					imageRect.origin.y +=increaseInRow+imageRectHeight;
				}
				if (i%2 == 0) {
					imageRect.origin.x += increaseInColumon + imageRectWidth;
				}
				MiMAnimalImage *animalImage=[[MiMAnimalImage alloc]initWithFrame:imageRect animal:animal];
				[view addSubview:animalImage];
				i++;
			}

		[scrollView addSubview:view];
		scrollView.contentSize=viewRect.size;
	
	[self.window addSubview:scrollView];
	[self.window makeKeyAndVisible];
	return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application
{
	// Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
	// Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
	// Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
	// If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
	// Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
	// Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
	// Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
	NSLog(@"window!");
}

@end
