//
//  MiMAudioPlayer.m
//  AS3
//
//  Created by MiM on 4/3/14.
//  Copyright (c) 2014 MiM. All rights reserved.
////
//
//#import "MiMAudioPlayer.h"
//
//@implementation MiMAudioPlayer
//-(void)playSound{
////	NSURL *url = [NSURL fileURLWithPath:[NSString stringWithFormat:@"%@/%@.mp3",[[NSBundle mainBundle] resourcePath],_name]];
////	NSError *error;
////	_soundPlayer =[[AVAudioPlayer alloc] initWithContentsOfURL:url error:&error];
////	_soundPlayer.numberOfLoops = 1;
////	if (_soundPlayer == nil) {
////		NSLog(@"%@",error );
////	}
////	else
////	{
////		
////		[_soundPlayer play];
////		_soundPlayer.volume = 0.5; // 0.0 - no volume; 1.0 full volume
////		NSLog(@"%f seconds played so far", _soundPlayer.currentTime);
////		
////	}
//}
//@end
