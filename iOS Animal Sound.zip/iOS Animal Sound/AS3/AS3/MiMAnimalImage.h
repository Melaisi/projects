//
//  MiMAnimalImage.h
//  AS3
//
//  Created by MiM on 3/27/14.
//  Copyright (c) 2014 MiM. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MiMAnimal.h"
#import <AVFoundation/AVFoundation.h>
#import "MiMAudioPlayer.h"

@interface MiMAnimalImage : UIImageView
@property (nonatomic,strong) MiMAnimal *animal;

- (id)initWithFrame:(CGRect)frame
		   animal:(MiMAnimal *)animal;
@property (nonatomic , strong) AVAudioPlayer *soundPlayer;
@end
