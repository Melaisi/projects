//
//  MiMAnimalImage.m
//  AS3
//
//  Created by MiM on 3/27/14.
//  Copyright (c) 2014 MiM. All rights reserved.
//

#import "MiMAnimalImage.h"

@implementation MiMAnimalImage

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
	    self.userInteractionEnabled = YES;
    }
    return self;
}

-(id)initWithFrame:(CGRect)frame animal:(MiMAnimal *)animal{
	self =[super initWithFrame:frame];
	if(self){
		_animal=animal;
		self.image=_animal.image;
		NSLog(@"MiMAnimalImage for name:%@ ",_animal.name);
	}
	 self.userInteractionEnabled = YES;
	return self;
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
	NSLog(@"Image View");
	
	NSURL *url = [NSURL fileURLWithPath:[NSString stringWithFormat:@"%@/%@.mp3",[[NSBundle mainBundle] resourcePath],_animal.name]];
	NSError *error;
	_soundPlayer =[[AVAudioPlayer alloc] initWithContentsOfURL:url error:&error];
	_soundPlayer.numberOfLoops = 1;
	if (_soundPlayer == nil) {
		NSLog(@"%@",error );
	}
	else
	{
		
		[_soundPlayer play];
		_soundPlayer.volume = 0.5; // 0.0 - no volume; 1.0 full volume
		NSLog(@"%f seconds played so far", _soundPlayer.currentTime);
		
	}

}

@end
