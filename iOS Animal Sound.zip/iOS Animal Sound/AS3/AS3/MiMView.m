//
//  MiMView.m
//  AS3
//
//  Created by MiM on 3/27/14.
//  Copyright (c) 2014 MiM. All rights reserved.
//

#import "MiMView.h"

@implementation MiMView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
	    
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
	NSLog(@"View !");
}

-(void)playSoundWithname:(NSString *)name{
	NSURL *url = [NSURL fileURLWithPath:[NSString stringWithFormat:@"%@/%@.mp3",[[NSBundle mainBundle] resourcePath],name]];
	NSError *error;
	_soundPlayer =[[AVAudioPlayer alloc] initWithContentsOfURL:url error:&error];
	_soundPlayer.numberOfLoops = 1;
	if (_soundPlayer == nil) {
		NSLog(@"%@",error );
	}
	else
	{
		
		[_soundPlayer play];
		_soundPlayer.volume = 0.5; // 0.0 - no volume; 1.0 full volume
		NSLog(@"%f seconds played so far", _soundPlayer.currentTime);
		
	}

}
@end
