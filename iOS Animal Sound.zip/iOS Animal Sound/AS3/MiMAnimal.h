//
//  MiMAnimal.h
//  AS3
//
//  Created by MiM on 3/27/14.
//  Copyright (c) 2014 MiM. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>

@interface MiMAnimal : NSObject

@property (nonatomic , strong) NSString *name;
@property (nonatomic , strong) UIImage *image;
//@property (nonatomic , strong) AVAudioPlayer *soundPlayer;


-(instancetype) initWithName:(NSString *)name
				   image:(UIImage *)image;
-(void) playSound;

@end
