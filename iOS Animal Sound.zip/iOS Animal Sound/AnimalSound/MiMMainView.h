//
//  MiMMainView.h
//  AnimalSound
//
//  Created by MiM on 3/23/14.
//  Copyright (c) 2014 MiM. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MiMAnimal.h"

@interface MiMMainView : UIView
@property (nonatomic , weak) NSMutableArray *animalArray;

@end
