//
//  MiMmainViewController.h
//  AnimalSound
//
//  Created by MiM on 3/23/14.
//  Copyright (c) 2014 MiM. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MiMmainViewController : UIViewController

//Animal Object Array
//@property (nonatomic, weak) NSMutableArray *animalsArray;

//- (void)addAnimal:(MiMAnimal *)animal;
//- (id) initWithViewRect:(CGRect)rect;

@end
