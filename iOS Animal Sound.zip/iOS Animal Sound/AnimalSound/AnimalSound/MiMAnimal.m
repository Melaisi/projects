//
//  MiMAnimal.m
//  AnimalSound
//
//  Created by MiM on 3/23/14.
//  Copyright (c) 2014 MiM. All rights reserved.
//

#import "MiMAnimal.h"

@implementation MiMAnimal

- (instancetype) initWithName: (NSString *)animalName
				    image: (UIImage *)animalImage{
	self = [super init];
	if (self) {
		_name=animalName;
		_image=animalImage;
	}
	return self;
	
}

-(NSString *) description {
	return [NSString stringWithFormat:@"My name is %@ ", self.name];

}

@end
