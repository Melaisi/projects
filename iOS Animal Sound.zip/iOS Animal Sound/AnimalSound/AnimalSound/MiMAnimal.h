//
//  MiMAnimal.h
//  AnimalSound
//
//  Created by MiM on 3/23/14.
//  Copyright (c) 2014 MiM. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MiMAnimal : NSObject
@property (nonatomic , weak) NSString *name;
@property (nonatomic , weak) UIImage *image;
- (instancetype) initWithName: (NSString *)animalName
				    image: (UIImage *)animalImage;
@end
