//
//  MiMmainViewController.m
//  AnimalSound
//
//  Created by MiM on 3/23/14.
//  Copyright (c) 2014 MiM. All rights reserved.
//

#import "MiMmainViewController.h"
#import "MiMMainView.h"

@interface MiMmainViewController ()

@end

@implementation MiMmainViewController

- (id)initWithNibName:(NSString *)nibNameOrNil
			bundle:(NSBundle *)nibBundleOrNil{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
    }
    return self;
}

//- (id)initWithViewRect:(CGRect)rect{
//	NSString *nibNameOrNil ;
//	NSBundle *nibBundleOrNil;
//	self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
//	if (self) {
//		// Custom initialization
//		self.view = [[MiMMainView alloc] initWithFrame:rect];
//	}
//	return self;
//}
//

//- (void)addAnimal:( MiMAnimal *)animal{
//	[self.animalsArray addObject:animal];
//}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    //Display first animal
//	CGContextRef context = UIGraphicsGetCurrentContext();
//	CGContextSaveGState(context);
//	CGRect rect = self.view.bounds;
//	
//	[[_animalsArray objectAtIndex:0] drawInRect:rect];
	
	//creat View !
	MiMMainView *mainView = [[MiMMainView alloc] init];
	UIImage *catImage = [UIImage imageNamed:@"cat.png"];
	
	UIImageView *catView = [[UIImageView alloc] initWithImage:catImage];
	
	[mainView addSubview:catView];
	
	self.view=mainView;
}



- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
