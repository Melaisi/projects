//
//  MiMMainView.m
//  AnimalSound
//
//  Created by MiM on 3/23/14.
//  Copyright (c) 2014 MiM. All rights reserved.
//

#import "MiMMainView.h"
#import "MiMAnimal.h"

@implementation MiMMainView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
	    // Initialization code
	    self.backgroundColor = [UIColor whiteColor];
    }
    return self;
}

// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
//- (void)drawRect:(CGRect)rect
//{
//    // Drawing code
//    //set the rect
//     CGRect bounds = self.bounds;
//    CGRect newRect = bounds;
//    newRect.size.height = 50;
//	newRect.size.width = 50;
//	newRect.origin.x = 100;
//	newRect.origin.y = 100;
//	MiMAnimal *animal = [[MiMAnimal alloc] initWithName:@"cat" image:[UIImage imageNamed:@"cat"] ];
//	NSLog(@"I am In the main view drawrect My name is : %@ ",animal);
//	UIImage *animalImage =animal.image;
//	CGContextRef context = UIGraphicsGetCurrentContext();
//	CGContextSaveGState(context);
//	[animalImage drawInRect:newRect];
//	
//	
//}
//
//- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
//	UITouch *touched = [[event allTouches] anyObject];
//	CGPoint location = [touched locationInView:touched.view];
//	
//}


@end
