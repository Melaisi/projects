//
//  MiMImageView.m
//  AnimalSounds2
//
//  Created by MiM on 3/24/14.
//  Copyright (c) 2014 MiM. All rights reserved.
//

#import "MiMImageView.h"

@implementation MiMImageView

- (id)initWithFrame:(CGRect)frame
		   animal:(MiMAnimal *)animal
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
	    self.userInteractionEnabled = YES;
	    if (animal) {
		    _animal =animal;
		    self.image = _animal.image;
	    }
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

-(void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
	//NSLog(@"Touch! : %@",self);
	//NSLog(@"Animal : %@",_animal);
	//play Sound !
	NSLog(@"ImageView");
		
//	
//	NSString *path= [[NSBundle mainBundle] pathForResource:@"cato" ofType:@"mp3"];
//	NSFileManager *fileManger = [NSFileManager defaultManager];
//	if ([fileManger fileExistsAtPath:path ]) {
//		NSURL *catSoundURL = [NSURL fileURLWithPath:path];
//		SystemSoundID catSound;
//		AudioServicesCreateSystemSoundID((__bridge CFURLRef)catSoundURL, &catSound);
//		
//		AudioServicesPlaySystemSound(catSound);
//	}
	
	
}

@end
