//
//  MiMImageView.h
//  AnimalSounds2
//
//  Created by MiM on 3/24/14.
//  Copyright (c) 2014 MiM. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>

#import "MiMAnimal.h"

@interface MiMImageView : UIImageView 

@property (nonatomic,strong) MiMAnimal * animal;
-(instancetype)initWithFrame:(CGRect)frame animal:(MiMAnimal *)animal;
@end
