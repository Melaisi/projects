//
//  MiMViewController.m
//  AnimalSounds2
//
//  Created by MiM on 3/24/14.
//  Copyright (c) 2014 MiM. All rights reserved.
//

#import "MiMViewController.h"
#import "MiMImageView.h"

@interface MiMViewController ()

@end


@implementation MiMViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
	self.view.backgroundColor = [UIColor redColor];
	
//	UIImage *animalImage =[UIImage imageNamed:@"cat.png"];
//	MiMImageView *imageView =[[MiMImageView alloc] initWithImage:animalImage];
//	[self.view addSubview:imageView];
//	Add subview
	CGRect rect = self.view.bounds;
	rect.origin.x = rect.size.width/2;
	rect.origin.y = rect.size.height/2;
	rect.size.height = 50;
	rect.size.width = 50;
	MiMAnimal *cat=[[MiMAnimal alloc] initWithName:@"cat" image:[UIImage imageNamed:@"cat.png"]];
	MiMImageView *tView = [[MiMImageView alloc] initWithFrame:rect animal:cat];
	//tView.image = [UIImage imageNamed:@"cat.png"];
	tView.backgroundColor =[UIColor whiteColor];
	
	CGRect labelRect = rect;
	labelRect.origin.y += rect.size.height + 10;
	
	[self.view addSubview:tView];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
	NSLog(@"Touch! : %@",self);
}
@end
