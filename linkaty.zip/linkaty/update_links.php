<?

/// This page to update links 

/// recive necessary  : 

///   1- LID 

///   2- UID

///   3- :/

/// recive at least one of :

///   1- Title, To change the Title. 

///   2- Link, To change it.

///   3- Rateing, To change it.

///   4- Comment, To change it.

/// return :

///   1- echo 0; for errors. 

///   2- echo 1; for successed.

if ( !$_GET['LID'] || !$_GET['UID'] )

{

	//echo "No LID or UID";

	}

else if ( !$_GET['Title'] && !$_GET['Link'] && !$_GET['Rating'] && !$_GET['Comment'] )

{



	//echo "No Title, Link, Rating, Comment ";



	}

else 
{
	//check login
	session_start();
	if (isset($_SESSION['UID']))
	{
		if ((int)$_GET['UID'] != $_SESSION['UID'])
		{
			echo "Access Denied";
			exit;
		}
		else
		{
			/// check if there are any change or not !
			/// varabiles and sql query to update the row.:	
			include('db_con.php');
			$LID = (int)$_GET['LID'] ;
			$UID = (int)$_GET['UID'] ;
			$sql= "UPDATE links SET ";
			if($_GET['Title'])
			{
				//echo $_GET['Title']."<br>";
				//	$Title= iconv('cp1256','utf-8',$_GET['Title']);
				//	echo $Title."<br>";
				//	$sql .=" Title =(_utf8'".$Title."')";
				$sql .=" Title ='".htmlspecialchars($_GET['Title'])."'";
				if ( $_GET['Link'] || $_GET['Rating'] || $_GET['Comment'] )
				{
					$sql .=", ";
				}
			}
			if($_GET['Link'])
			{
				$sql .=" Link ='".htmlspecialchars($_GET['Link'])."'";
				if ( $_GET['Rating'] || $_GET['Comment'] )
				{
					$sql .=", ";
				}
			}
			if((float)$_GET['Rating'])
			{
				$sql .=" Rating ='".$_GET['Rating']."'";
				if ( $_GET['Comment'] )
				{
					$sql .=", ";
				}
			}
			if($_GET['Comment'])
			{
				//$Comment = iconv('cp1256','utf-8',$_GET['Comment']);
				//$sql .=" Comment =(_utf8'".$Comment."')";
				$sql .=" Comment ='".htmlspecialchars($_GET['Comment'])."'";
			}
			$sql .= " WHERE LID ='".$LID."' AND UID='".$UID."'";
			/// echo $sql;
			/// Update :
			/// Connect to DB :
			if (!mysql_query($sql))
			{
				echo '0';
				mysql_close($con);
			}
			else
			{
				//echo '1';
				mysql_close($con);
				header("Content-Type: text/xml");
				$xml = new SimpleXMLElement('<xml/>');
				if (isset($_GET['LID']))
				{
					$LID = (int)$_GET['LID'];
					$sql ="select  LID, Title, Link, Rating, Comment, Ldate FROM links WHERE LID =".$LID." AND Status =0";
					include('db_con.php');
					if (!$result = mysql_query($sql))
					{
						die('Could not connect: ' . mysql_error());
					}
					else
					{
						//echo "connect sucssed to table</br>";
					}
					$row = mysql_fetch_assoc($result);
					$Link = $xml->addChild('Link');
					$Link->addChild('LID',$row['LID']);
					$Link->addChild('Titles',$row['Title']);
					$Link->addChild('URL',$row['Link']);
					$Link->addChild('Comment',$row['Comment']);
					$Link->addChild('Rating',$row['Rating']);
					$Link->addChild('Ldate',$row['Ldate']);
					echo $xml->asXML();
					mysql_free_result($result);
					mysql_close($con);
				}
			}
		}
	}
	else
	{
		echo "Access Denied";
		exit;
	}
}
?>