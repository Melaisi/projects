-- phpMyAdmin SQL Dump
-- version 3.4.3.1
-- http://www.phpmyadmin.net
--
-- المزود: sql301.byethost2.com
-- أنشئ في: 30 مارس 2012 الساعة 22:49
-- إصدارة المزود: 5.5.16
--  PHP إصدارة: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- قاعدة البيانات: `b2_9967847_db1`
--

-- --------------------------------------------------------

--
-- بنية الجدول `links`
--

CREATE TABLE IF NOT EXISTS `links` (
  `LID` int(255) NOT NULL AUTO_INCREMENT,
  `UID` int(10) NOT NULL COMMENT 'User ID',
  `Link` varchar(900) NOT NULL,
  `Title` varchar(100) DEFAULT NULL,
  `Comment` varchar(500) DEFAULT ' ',
  `Rating` float NOT NULL DEFAULT '0.5',
  `Ldate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`LID`),
  KEY `UID` (`UID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=110 ;

--
-- إرجاع أو استيراد بيانات الجدول `links`
--

INSERT INTO `links` (`LID`, `UID`, `Link`, `Title`, `Comment`, `Rating`, `Ldate`, `Status`) VALUES
(57, 4, 'http://www.mrspeaker.net/dev/parcycle/', 'Particles - HTML5', 'Particles بالمتصفح بدون فلاش أو فيديو! وبالصفحة خيارات للتحكم بالشكل والحجم والسرعة وكل شيء', 5, '2012-02-15 06:47:34', 0),
(58, 4, 'http://mrdoob.com/projects/chromeexperiments/google_gravity/', 'Google Gravity', 'تطبيق الجاذبية في جوجل', 3, '2012-02-15 06:53:58', 0),
(59, 4, 'http://raphaeljs.com/polar-clock.html', 'Polar Clock', 'ساعة...', 2, '2012-02-15 06:56:47', 0),
(60, 4, 'http://hakim.se/experiments/html5/core/01/', 'Core', 'لعبة جميلة وبدون فلاش، امنع دخول الدوائر الحمر باستخدام نصف الدائرة', 5, '2012-02-15 07:01:09', 0),
(61, 4, 'http://www.cuttherope.ie/', 'Cut The Rope', 'لعبة Cut The Rope المعروفة، الآن بدون فلاش!', 5, '2012-02-15 07:02:46', 0),
(62, 4, 'http://agent8ball.com/', 'Agent 008 Ball', 'لعبة بلياردو عبيطة، لكن لأنها بدون فلاش ليست عبيطة', 2.5, '2012-02-15 07:04:40', 0),
(63, 4, 'https://www.mugeda.com/', 'Mugeda', 'موقع لتصميم أنيميش صوت وصورة أونلاين، نتائجه تغني عن الgif والفلاش وممكن استخدامه بالبنرات والإعلانات المتحركة في المواقع! شاهد بعض الأعمال بالصفحة الرئيسية', 5, '2012-02-15 07:18:11', 0),
(64, 4, 'http://www.sinuousgame.com/', 'Sinuous', 'لعبة فازت بمسابقة أفضل تطبيق بالـHTML5 بحجم أقل من 10 كيلوبايت. تجنب الدوائر الحمر، والدوائر الملونة تساعدك', 5, '2012-02-15 07:25:07', 0),
(65, 4, 'http://raphaeljs.com/', 'Raphaël', 'مكتبة JavaScript جميلة، تطبيقات باستخدامها أسفل الصفحة', 5, '2012-02-15 07:30:32', 0),
(69, 4, 'http://www.xe.com/ucc/', 'XE - Universal Currency Converter', 'موقع تحويل عملات من إلى ما شئت', 5, '2012-02-16 11:18:09', 0),
(104, 4, 'http://code.msdn.microsoft.com/windowsapps/Windows-8-Modern-Style-App-Samples', 'Windows 8 Metro Style App Samples', 'أمثلة وملفات مفتوحة لتطبيقات ويندوز 8 بأكثر من لغة', 5, '2012-03-10 19:17:23', 0),
(73, 4, 'http://www.html5canvastutorials.com/tutorials/html5-canvas-tutorials-introduction/', 'HTML5 Canvas Tutorials', 'موقع دروس HTML5 Canvas', 5, '2012-02-17 07:30:58', 0),
(74, 2, 'http://vi.sualize.us/', 'visualize', 'موقع لمشاركة الصور اللي تلاقيها بالنت مع امكانية بحث !', 3.5, '2012-02-17 15:05:53', 0),
(75, 4, 'http://iconverticons.com/', 'iConvert Icons', 'موقع لتحويل الصور إلى أيقونات بصيغ مختلفة حسب النظام', 5, '2012-02-17 17:21:20', 0),
(76, 2, 'http://gskinner.com/RegExr/', 'Regular Expression', 'اداة لتطبيق عمليات Regular Expression ليسهل استخدامها في بعض الاكواد البرمجية الاداة بواجهة بسيطة وسهلة.', 5, '2012-02-19 16:20:01', 0),
(78, 4, 'http://jsfiddle.net/', 'jsFiddle', 'موقع لمشاركة كود ويب، وللتجارب، مع عدة مكاتب مضمنة', 5, '2012-02-19 16:58:52', 0),
(79, 4, 'http://ideone.com/', 'Ideone', 'أونلاين كومبايلر لأكثر من 40 لغة برمجة، تكتب الكود ويعطيك الناتج والأخطاء', 5, '2012-02-19 17:06:40', 0),
(83, 6, 'http://a4.sphotos.ak.fbcdn.net/hphotos-ak-ash4/418473_335873903121644_100000971104957_942057_1052061234_n.jpg', 'قمة الحيرة', 'في كل الحلقات تلقاهم عريانين و يوم يروحوا للبحر يلبسو *_*', 3.5, '2012-02-20 10:26:53', 0),
(87, 2, 'http://140dev.com/twitter-api-programming-tutorials/hello-twitter-oauth-php/', 'Twitter API Tutorial', 'شرح بسيط لخطوات استخدام API تويتر عن طريق php وبعض المكتبات الخارجية . ', 3.5, '2012-02-22 19:14:27', 0),
(88, 2, 'http://hakim.se/experiments/html5/sketch/', 'sketch - موقع رسم اونلاين', 'موقع رسم بسيط باستخدام HTML5 ميزته تسجيل فيديو للرسم نفسه مع امكانية مشاركة الرسمه والمقطع جداً ممتع ', 3, '2012-02-24 19:43:54', 0),
(89, 2, 'http://scripts.filehungry.com/', 'scripts filehungry', 'موقع يحتوي على مكتبة كبيرة من المشاريع والبرامج المجانية وغير المجانية بكل اللغات البرمجية ', 1.5, '2012-02-24 21:50:39', 0),
(109, 2, 'http://www.behance.net', 'behance', 'موقع لنشر اعمالك ومشاهدة اعمال الغير الابداعية , كله ابداع ', 5, '2012-03-29 22:12:09', 0),
(108, 4, 'dsfghmgf', 'ertghj', 'fdghj', 5, '2012-03-29 19:54:31', 1),
(107, 4, 'abc', 'abc', 'abc', 3.5, '2012-03-28 18:53:05', 1),
(106, 4, 'abc', 'abc', 'abcgfhjm', 3.5, '2012-03-28 18:52:35', 1),
(105, 4, 'abc', 'abc', 'abc', 3.5, '2012-03-28 18:52:14', 1),
(100, 22, 'https://twitter.com/', 'تويتر', 'موقع اجتماعي ', 0.5, '2012-03-05 10:34:31', 0),
(101, 23, 'http://mazn.ws/', 'مايكرو مازن ', 'مدونة رائعة ...\nتهتم بالتدوين بإيجاز بشكل بسيط ورائع ..\nأسلوب الطرح رائع بالنسبة لي ..\n', 0.5, '2012-03-06 13:12:35', 0);

-- --------------------------------------------------------

--
-- بنية الجدول `share`
--

CREATE TABLE IF NOT EXISTS `share` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `url` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

--
-- إرجاع أو استيراد بيانات الجدول `share`
--

INSERT INTO `share` (`id`, `title`, `url`) VALUES
(1, 'HTML5 - Particles', 'http://www.mrspeaker.net/dev/parcycle/'),
(2, 'HTML5 Visualization', 'http://www.nihilogic.dk/labs/pocket_full_of_html5/#presets/mario.js'),
(3, 'Sinuous', 'http://hakim.se/experiments/html5/sinuous/01/'),
(4, 'Core', 'http://hakim.se/experiments/html5/core/01/'),
(5, 'Agent 008 Ball', 'http://agent8ball.com/'),
(6, 'Cut The Rope', 'http://www.cuttherope.ie/'),
(7, 'Google Gravity', 'http://mrdoob.com/projects/chromeexperiments/google_gravity/'),
(8, 'Sinuous - New!', 'http://www.sinuousgame.com/'),
(9, 'Convas Rider', 'http://canvasrider.com/tracks/48247'),
(10, 'Polar Clock', 'http://raphaeljs.com/polar-clock.html'),
(11, 'Raphaël - JavaScript Library', 'http://raphaeljs.com/'),
(14, 'Mugeda', 'https://www.mugeda.com');

-- --------------------------------------------------------

--
-- بنية الجدول `tests`
--

CREATE TABLE IF NOT EXISTS `tests` (
  `text` varchar(250) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- إرجاع أو استيراد بيانات الجدول `tests`
--

INSERT INTO `tests` (`text`) VALUES
('BMW-HSN-R-R says: ألف باء تاء');

-- --------------------------------------------------------

--
-- بنية الجدول `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `UID` int(5) unsigned NOT NULL AUTO_INCREMENT,
  `Username` varchar(15) NOT NULL,
  `Password` varchar(32) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Pic` varchar(100) DEFAULT '/img/av/d.jpg',
  `Bio` varchar(100) NOT NULL DEFAULT '...............',
  `UserRegisterDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `UserDelete` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`UID`),
  UNIQUE KEY `Username` (`Username`,`Email`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=26 ;

--
-- إرجاع أو استيراد بيانات الجدول `users`
--

INSERT INTO `users` (`UID`, `Username`, `Password`, `Email`, `Pic`, `Bio`, `UserRegisterDate`, `UserDelete`) VALUES
(1, 'admin', 'df2fc9fcb28abcd9beb6d8606319e6e4', 'admin@admin.com', 'http://d24w6bsrhbeh9d.cloudfront.net/photo/2298742_460s.jpg', 'بيو حساب admin', '2012-02-01 20:02:52', 1),
(2, 'MiM', 'df2fc9fcb28abcd9beb6d8606319e6e4', 'doorbook@gmail.com', '/img/av/u2.jpg', '.....', '2012-02-01 20:58:17', 0),
(4, 'BMWHSNRR', 'ea28c6c53cb525912fe692f3cdeb8519', 'BMW-HSN-R-R-M-W@HOTMAIL.COM', '/img/av/u4.jpg', 'مشاركة روابط بمجالات مختلفة...', '2012-02-15 06:36:29', 0),
(6, 'akmalkady', '7a25ebfb9e5bc6ab172577d100b48243', 'akmalkady@gmail.com', '/img/av/d.jpg', '.................', '2012-02-20 06:31:17', 0),
(24, '3zeez1', 'e10adc3949ba59abbe56e057f20f883e', '3zeez1@gmail.com', '/img/av/d.jpg', '...............', '2012-03-06 22:23:24', 0),
(25, 'zero', '96e79218965eb72c92a549dd5a330112', 'sul2005tan@gmail.com', '/img/av/d.jpg', '...............', '2012-03-24 18:45:25', 0),
(23, 'SalehAlDhobaie', '65584c741df1b76ab99eadbc7fef5df9', 'Saleh.Dhobaie@gmail.com', '/img/av/d.jpg', '...............', '2012-03-06 13:09:47', 0),
(21, 'faisal', '44ada318c019b573851308ef3e5e586e', 'kemos@live.com', '/img/av/d.jpg', '...............', '2012-03-04 20:36:18', 0),
(22, 'ahmedpho', 'fcea920f7412b5da7be0cf42b8c93759', 'a.a.o.1411@gmail.com', '/img/av/d.jpg', '...............', '2012-03-05 10:33:02', 0);

-- --------------------------------------------------------

--
-- بنية الجدول `Views`
--

CREATE TABLE IF NOT EXISTS `Views` (
  `Views` int(250) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- إرجاع أو استيراد بيانات الجدول `Views`
--

INSERT INTO `Views` (`Views`) VALUES
(199);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
