<?php 

function check_login(){
	
		session_start();
		if (isset($_SESSION['UID'])){
			return TRUE;
			}
		else {
			return FALSE;
			}
	}

//check page 
if (isset($_GET['username'])){
		//check DB 
		$username = htmlspecialchars($_GET['username']);
		$sql ="select UID from users WHERE Username='".$username."' AND UserDelete =0";
		include('db_con.php');
		
		if (!$result = mysql_query($sql))
		{
			die('Could not connect: ' . mysql_error());
		}
		else
		{
			//echo "connect sucssed to table</br>";
		}
		if (mysql_num_rows($result) ==1){
			$row = mysql_fetch_assoc($result);
			$PUID = $row['UID'];
		}
		mysql_free_result($result);
		mysql_close($con);
	}
else {
	//check login 
	if (check_login()){
		//True go to index.php?username=Username
			//get user name from DB;
			$UID = $_SESSION['UID'];
			$sql ="select  Username FROM users WHERE UID =".$UID." AND UserDelete =0";
			include('db_con.php');
			if (!$result = mysql_query($sql))
			{
				die('Could not connect: ' . mysql_error());
			}
			else
			{
				//echo "connect sucssed to table</br>";
			}
			if (mysql_num_rows($result) ==1){
				$row = mysql_fetch_assoc($result);
				$Username=$row['Username'];
				
				header("Location: index_login_test.php?username=".$Username);
			}
			mysql_free_result($result);
				mysql_close($con);
				
	}
	else { //False set stts=1
		
		$status=1;
		
		}
	
	}
?>
<script type="text/javascript">
<?php
if (isset($PUID)){
	echo "uid=".$PUID.";\n";
	if (check_login())//check login 
	{ 	//True check puid = uid 
		if($PUID == $_SESSION['UID'])
			{//True set stts=2
				$status=2;
			}
		else{//false set stts=3
				$status=3;
			}
	}
	else {//false set stts=3
			$status=3;
		}
		
}
else {
	if (check_login())//check login 
		{//True go to index.php?username=Username
			$UID = $_SESSION['UID'];
			$sql ="select  Username FROM users WHERE UID =".$UID." AND UserDelete =0";
			include('db_con.php');
			if (!$result = mysql_query($sql))
			{
				die('Could not connect: ' . mysql_error());
			}
			else
			{
				//echo "connect sucssed to table</br>";
			}
			if (mysql_num_rows($result) ==1){
				$row = mysql_fetch_assoc($result);
				$Username=$row['Username'];
				
				header("Location: index_login_test.php?username=".$Username);
			}
			mysql_free_result($result);
			mysql_close($con);
			$status=4;
		}
		else {//False set stts=1
				$status=3;
			}
	}
if (isset($status))
	{
		echo "stts=".$status."\n";
	}
?>
</script>