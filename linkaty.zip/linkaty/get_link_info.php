<?php 
header("Content-Type: text/xml");
$xml = new SimpleXMLElement('<xml/>');

if ((int)$_GET['LID'])

{
	$LID = (int)$_GET['LID'];
	$sql ="select  LID, Title, Link, Rating, Comment, Ldate FROM links WHERE LID =".$LID." AND Status =0";
	require_once ('db_con.php');
	if (!$result = mysql_query($sql))
	{
		die('Could not connect: ' . mysql_error());
	}
	else
	{
		//echo "connect sucssed to table</br>";
	}
	$row = mysql_fetch_assoc($result);
	$Link = $xml->addChild('Link');		
	$Link->addChild('LID',$row['LID']);
	$Link->addChild('Titles',htmlspecialchars($row['Title']));
	$Link->addChild('URL',htmlspecialchars($row['Link']));
	$Link->addChild('Comment',htmlspecialchars($row['Comment']));
	$Link->addChild('Rating',$row['Rating']);
	$Link->addChild('Ldate',$row['Ldate']);
	echo $xml->asXML();
	
	mysql_free_result($result);
	mysql_close($con);
}
?>