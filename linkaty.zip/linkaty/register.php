<?php
//function of close DB :

/* function close_DB(){
		
		echo "Close_DB !<br />";
		mysql_free_result($result);
		mysql_close($con);
	}
*/
//function level 0 : return True or false

function check_get($geto){
		
	//	if(isset($_GET[$geto]) && $_GET[$geto] != NULL){
		if(!empty($_GET[$geto])){	
			//echo "inside check GET isset TRUE<br />check get = {$_GET[$geto]}<br />";////////////////////////////////////////////////////////////////////
			return TRUE;
			
			}
		else{
			//echo "inside check GET isset False<br />";////////////////////////////////////////////////////////////////////
			return FALSE;}
	}

function check_correct_user(){
	
		//echo "inside check correct user <br />"; /////////////////////////////////////////////////////////////////
		
		if (!preg_match("/[^\w]/",$_GET['Username']))
		{
			
			if (strlen($_GET['Username']) > 15)
			{
				//echo "User name > 15 <br />";//////////////////////////////////////////////
				return FALSE;
				}
			else{
				//echo "correct username <br />";//////////////////////////////////////////////////////
				return TRUE;
			}
			}
		else
		{
			//echo "username not correct <br />";/////////////////////////////////////////////////////
			return FALSE;
			}
	
	}

/*function check_avaliable(){
		
		$user = htmlspecialchars($_GET['Username']);
		$sql ="Select Username from users WHERE Username like '{$user}'";
		include ('db_con.php');
		if (!$result = mysql_query($sql))
			{
				die('Could not connect: ' . mysql_error());
			}
		else
			{	
				if (mysql_num_rows($result) == 1) {
					
					return FALSE;
					}
				else{
					return TRUE;
					}
			}
}*/

function check_avaliable($geto){
		
		$var = htmlspecialchars($_GET[$geto]);
		$sql ="Select {$geto} from users WHERE {$geto} like '{$var}'";
		include_once ('db_con.php');
		if (!$result = mysql_query($sql))
			{
				//die('Could not connect: ' . mysql_error());
			}
		else
			{	
				if (mysql_num_rows($result) == 1) {
					
					mysql_free_result($result);
					
					return FALSE;
					}
				else{
					mysql_free_result($result);
					
					return TRUE;
					}
			}
}

function check_correct_pass(){
	
		
		
			if (strlen($_GET['Password']) >= 6)
			{
				return TRUE;
				}
			else{
				return FALSE;
			}
}

function check_correct_repass(){
	
		
		
			if (strlen($_GET['Password']) >= 6)
			{
				if ($_GET['Password'] == $_GET['RePassword'])
				{	
					return TRUE;
				}
				else
				{
					return FALSE;	
				}
			}
			else{
				return FALSE;
			}
}		
	
function check_correct_email(){
	
		
		//if (preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/",$_GET['Email']))
		if (preg_match("/^[_\w-]+(\.[_\w-]+)*@[\w-]+(\.[\w-]+)*(\.[a-z]{2,3})$/",$_GET['Email']))
		{
				return TRUE;
		}
		else
		{
			return FALSE;
		}
	
}

//function level 1 : return 0 if correct or msg in case of error

function check_Username(){
		
		//echo "Inside check_Username<br /> ";///////////////////////////////////////////////////////////////////////////////////////
		if(check_get("Username"))
		{	
			//echo "Back to check User if check get TRUE:<br /> ";/////////////////////////////////////////////////////////////////////////////////
			if(check_correct_user())
				{
				//	echo "Back to checkuser if user correct <br />";/////////////////////////////////////////////////////////////////////////////////
					if(check_avaliable("Username"))
						{
							return " ";	 //لا يوجد خطأ
						}
					else
						{
							return "الإسم مستخدم";	
						}
				}
			else
				{
					
					
					return "[A-z]، [0-9]، [_]"; //استخدم رموز
				}
		}
		else
		{
			//echo "Back to check User if check get FALSE:<br /> ";/////////////////////////////////////////////////////////////////////////////////
			return ""; //الخانة فارغة
		}
	}
function check_Password(){
		
		if(check_get("Password"))
		{	
			if(check_correct_pass())
				{
					return " ";	//لا يوجد خطأ
				}
			else
				{
					return "< 6 رموز";
				}
		}
		else
		{
			return "  "; //الخانة فارغة
		}
	
	}
function check_RePassword(){
		
		if(check_get("RePassword"))
		{	
			if(check_correct_repass())
				{
					return " ";	 //لا يوجد خطأ
				}
			else
				{
					return "كلمة المرور غير مطابقة";
				}
		}
		else
		{
			return "  "; //الخانة فارغة
		}
		
	}
function check_Email(){
		
		if(check_get("Email"))
		{	
			if(check_correct_email())
				{
					if(check_avaliable("Email"))
						{
							return " ";	 //لا يوجد خطأ
						}
					else
						{
							return "البريد مستخدم";	
						}
				}
			else
				{
					return "مدخل غير صحيح";
				}
		}
		else
		{
			return "  ";//خانة فارغة
		}
	
	}
/*function check_Bio(){
	
		if(check_get("Bio"))
		{	
			if(check_correct_bio())
				{
					return "0";	
				}
			else
				{
					return "not correct";
				}
		}
		else
		{
			echo "Bio is empty";
		}
	
	}
*/

//isert into DB :
function insert_to_DB(){
	//echo "<br />Hello into Db :<br />";//////////////////////////////////////////////////
	$username = htmlspecialchars($_GET["Username"]);
	//echo "<br />";
	$password = md5($_GET["Password"]);
	//echo "<br />";
	$email = htmlspecialchars($_GET["Email"]);
	//echo "<br />";
	//include_once("db_con.php");
	$sql="insert into users ( Username, Password, Email ) VALUES ('{$username}','{$password}','{$email}')";
	//echo "SQL : {$sql}<br />";//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	if (!$result = mysql_query($sql))
	{
		//die('Could not connect: ' . mysql_error());	
		}
	else
	{
		//echo "Register done <br />";
	}
	mysql_free_result($result);
	
}

function set_sessions(){
	
	$username = $_GET['Username'];
	$sql = "select UID from users WHERE `Username`='".$username."'";
	//include_once('db_con.php');
	if (!$result = mysql_query($sql))
	{
		//return FALSE;
	}
	else
	{	
		if (mysql_num_rows($result) == 1) {
			$row = mysql_fetch_assoc($result);
			global $UID,$db_username;
			$UID = $row['UID'];
			$db_username = $row['Username'];
			$expire_cookie = 60*60*24*30*6;
			session_set_cookie_params($expire_cookie);
			session_start();
			$_SESSION['UID'] = $UID;
			
		}
		else {
			//return FALSE;
			}
	}
		mysql_free_result($result);

}


//check login 
function check_login(){

	session_start();

	if (isset($_SESSION['UID'])){

		return TRUE;

		}

	else {

		return FALSE;

		}

}

if (check_login()){
	
	echo "--1"; //refresh the page because he is loged in
	exit;
	}
else
{
	
	
	$msg ="";	
	$error_msg =array();
	$i=0;
	$error =0;
	//echo "Msg = {$msg}.<br /> Before check_Username()<br />"; ///////////////////////////////////////////////////////////////
	$error_msg['Username']=check_Username();
	//echo "after checkUsername error_msg['Username']={$error_msg['Username']}<br /> ";//////////////////////////////////////////////////////////////////
	$error_msg['Password']=check_Password();
	$error_msg['RePassword']=check_RePassword();
	$error_msg['Email']=check_Email();
//	$error_msg['Bio']=check_Bio();
	foreach ($error_msg as $err){
			
			//echo "inside foreach err = {$err}<br />";//////////////////////////////////////////////////////////////////////
			$msg .= $err."#";
			//echo "msg= {$msg}<br />";//////////////////////////////////////////////////////////////////////
			if($err != " "){	
				$error =1;
				//echo "erorr = 1 <br />";//////////////////////////////////////////////////////////////////////////
			}
			else{
				//$error=0;
			//	echo "erorr = 0 <br />";//////////////////////////////////////////////////////////////////////////
				}
		
		}
	if($error == 1)
	{
		echo $msg;
		exit;
		}
	else
	{
		insert_to_DB();
		set_sessions();
		echo "Done";
		}
	
}
?>