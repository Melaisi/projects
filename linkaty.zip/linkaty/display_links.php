<? 
/// this page to re display link that was removed and change status from 1 to 0 
/// recive 3 variabls :
///   1- LID - Link ID 
///   2- UID - User ID 
///   3- :/ 
/// return 2 :
///   1- echo 0 for errors 
///   2- echo 1 for successed 

if (!$_GET['LID'] || !$_GET['UID'])
{}
else {
	$LID = (int)$_GET['LID'];
	$UID = (int)$_GET['UID'];
	
	/// conection to data base 
	
	require_once('db_con.php');
	
	/// sql query to update status from 1 to 0 for undisplay it .
	
	$sql ="UPDATE links SET Status =0 WHERE LID ='".$LID."' AND UID='".$UID."'";
	
	if (!mysql_query($sql))
	{
		
		echo '0';
		}
	else
		{echo '1';}
	
	mysql_close($con);
}




?>