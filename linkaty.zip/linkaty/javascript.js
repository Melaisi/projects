// JavaScript Document

//window.onload=loadp();
//var uid=1;
var usern;
var totalp = new Array();
var totalid = new Array();
var xmlres;
var parser;
var xmlres;
var posts;
var postcon;
var newHTML;
var xmlresoe;
var xmlures;
var ufoar;
function getuinf()
{
if (stts==3)
{
document.getElementById("sbah").style.display="none";
$("body").animate({opacity:1},175);
signf();
}
else
{
xmlhttp=new XMLHttpRequest();
xmlhttp.open("GET","get_user_info.php?UID=" + encodeURIComponent(uid),true);
xmlhttp.send();
xmlhttp.onreadystatechange=function()
{
if (xmlhttp.readyState==4 && xmlhttp.status==200)
{
xmlures = xmlhttp.responseText;
parser = new DOMParser();
xmlures = parser.parseFromString(xmlures,"text/xml");
ufoar=xmlures.getElementsByTagName("User");
//here
usern=ufoar[0].getElementsByTagName("Username")[0].childNodes[0].nodeValue;
var tmpuhtmlv="<div id='uimg' style='background-image:url("+ufoar[0].getElementsByTagName("Pic")[0].childNodes[0].nodeValue+");'></div><div id='userdes'><span id='uname'>"+usern+"</span><hr /><p><span id='udesc'>"+ufoar[0].getElementsByTagName("Bio")[0].childNodes[0].nodeValue+"</span></p></div>";
if (stts==1 || stts==2)
{
tmpuhtmlv+="</div><div class='tlbtn' style='background-image:url(img/sout.png);' onclick='loutf()'></div>";
}
if (stts==2)
{
tmpuhtmlv+="<div id='newbtn' onclick='newp()'>";
}
if (stts==0)
{
tmpuhtmlv+="</div><div class='tlbtn' onclick='signf()'></div>";
}
document.getElementById("user").innerHTML=tmpuhtmlv;
loadp();
}
//else {getuinf();}
}
}
}

function loadp()
{
xmlhttp=new XMLHttpRequest();
xmlhttp.open("GET","get_links.xml.php?UID=" + encodeURIComponent(uid),true);
xmlhttp.send();
xmlhttp.onreadystatechange=function()
{
if (xmlhttp.readyState==4 && xmlhttp.status==200)
{
//deco xmlres = decodeURI(xmlhttp.responseText);
xmlres = xmlhttp.responseText;
parser = new DOMParser();
xmlres = parser.parseFromString(xmlres,"text/xml");
viewp();
}
}
}

function viewp()
{
totalp.splice(0,totalp.length);
totalid.splice(0,totalid.length);
posts=xmlres.getElementsByTagName("Link");
postcon=document.getElementById("postscont");
newHTML="";
for (i=0;i<=posts.length-1;i++)
{
totalp[i]=posts[i].getElementsByTagName("LID")[0].childNodes[0].nodeValue;
totalid[posts[i].getElementsByTagName("LID")[0].childNodes[0].nodeValue]=i;
var plink = "'" + posts[i].getElementsByTagName("URL")[0].childNodes[0].nodeValue + "'";
var purl = '"openl(' + plink + ',this)" ';
if (i==0)
{
newHTML+="<div name='post" + i + "' onclick=" + purl + " id='post" + posts[i].getElementsByTagName("LID")[0].childNodes[0].nodeValue + "' class='post fpost'>";
}
else
{
if(i==posts.length-1)
{
newHTML+="<div name='post" + i + "' onclick=" + purl + " id='post" + posts[i].getElementsByTagName("LID")[0].childNodes[0].nodeValue + "' class='post lpost'>";
}
else
{
newHTML+="<div name='post" + i + "' onclick=" + purl + " id='post" + posts[i].getElementsByTagName("LID")[0].childNodes[0].nodeValue + "' class='post'>";
}
}
newHTML+="<span class='posttext'><div class='ptitle'><span id='pvtitle" + posts[i].getElementsByTagName("LID")[0].childNodes[0].nodeValue + "' >" + posts[i].getElementsByTagName("Titles")[0].childNodes[0].nodeValue + "</span><div id='pvrttl" + posts[i].getElementsByTagName("LID")[0].childNodes[0].nodeValue + "' title='" + posts[i].getElementsByTagName("Rating")[0].childNodes[0].nodeValue +"' class='rate' ><span id='pvrate" + posts[i].getElementsByTagName("LID")[0].childNodes[0].nodeValue + "' >";
for (j=1;j<=parseInt(posts[i].getElementsByTagName("Rating")[0].childNodes[0].nodeValue);j++)
{
newHTML+="<div class='star' style='opacity:1'></div>";
}
if (parseInt(posts[i].getElementsByTagName("Rating")[0].childNodes[0].nodeValue)<5)
{
newHTML+="<div class='star' style='opacity:" + (posts[i].getElementsByTagName("Rating")[0].childNodes[0].nodeValue - parseInt(posts[i].getElementsByTagName("Rating")[0].childNodes[0].nodeValue)) + "'></div>";
}
for (j=1;j<=(6-parseInt(posts[i].getElementsByTagName("Rating")[0].childNodes[0].nodeValue));j++)
{
newHTML+="<div class='star' style='opacity:0'></div>";
}
newHTML+="</span></div><div class='pdate'><span id='pvdate" + posts[i].getElementsByTagName("LID")[0].childNodes[0].nodeValue + "' >" + posts[i].getElementsByTagName("Ldate")[0].childNodes[0].nodeValue + "</span></div>";
if (stts==2){
newHTML+="<div class='editbtn' id='edit" + posts[i].getElementsByTagName("LID")[0].childNodes[0].nodeValue + "' onclick='editp(this)'></div>" + "<div class='delbtn' id='del" + posts[i].getElementsByTagName("LID")[0].childNodes[0].nodeValue + "' onclick='delp(this)'></div>";
}
newHTML+="<div class='hrl'></div></div><div class='pdesc'><div class='pvcom' id='pvcom" + posts[i].getElementsByTagName("LID")[0].childNodes[0].nodeValue + "' >" + checkurlf(posts[i].getElementsByTagName("Comment")[0].childNodes[0].nodeValue) + "</div></div></div>";
}
if (totalp.length==0)
{
newHTML="<div class='noposts' id='nopsts'>" + "<span class='nopostsuser'>" + usern + "</span> " + "لم يضف أية روابط بعد" + "</div>";
}
postcon.innerHTML=newHTML;
if (totalp.length==1)
{
document.getElementById('post' + totalp[0]).style.borderRadius='12px';
}
$("body").animate({opacity:1},175);
}

var dopenl=0;
function openl(surl,senderp)
{
if ((senderp.id.substring(0,4)=='post' && dopenl==0))
{
window.open(surl,'_blank');
}
dopenl=0
}

var wkingedit=0;
function editp(p2edit)
{
dopenl=1;
if (!document.getElementById('pedit' + totalid[p2edit.id.substring(4,p2edit.id.length)]) && wkingedit==0)
{
wkingedit=1;
var uidedit=totalid[p2edit.id.substring(4,p2edit.id.length)];
//alert(posts[uidedit].getElementsByTagName("Titles")[0].childNodes[0].nodeValue);
var tmpehtml="<div id='pedit" + uidedit + "' class='pedit' onclick='dopenl=1'><div class='dbtn' onclick='dsedit(" + uidedit + ")' style='width:42px;top:199px;left:40px;";
if (totalp.length -1 == totalid[p2edit.id.substring(4,p2edit.id.length)])
{
tmpehtml+="border-bottom-left-radius:12px;";
}
else
{
tmpehtml+="border-radius:0px";
}
tmpehtml+="'>حفظ</div><div class='dbtn backbtn' onclick='hidedit("+totalid[p2edit.id.substring(4,p2edit.id.length)]+")' style='top:199px;left:86px;'>×</div><div class='editbline'><div class='tboxttl'>العنوان</div><input id='titletbedit" + uidedit + "' type='text' class='txtbox' /><div class='tboxttl' style='float:left;position:relative;left:27px;'>التقييم</div><div class='editprate' id='editrate" + uidedit + "' title='0.5'><div class='star' id='epstar1" + uidedit + "' onclick='eprate(this)' style='opacity:0.5'></div><div class='star' id='epstar2" + uidedit + "' onclick='eprate(this)'></div><div class='star' id='epstar3" + uidedit + "' onclick='eprate(this)'></div><div class='star' id='epstar4" + uidedit + "' onclick='eprate(this)'></div><div class='star' id='epstar5" + uidedit + "' onclick='eprate(this)'></div></div></div><div class='editbline'><div class='tboxttl'>الوصف</div><textarea id='commenttbedit" + uidedit + "' type='text' class='txtbox' maxlength='500' style='height:67px;width:425px;overflow:hidden;' onkeyup='tblen(this,"+uidedit+")'></textarea></div><div class='editbline' style='padding-bottom:0px;'><div class='tboxttl'>الرابط</div><input id='linktbedit" + uidedit + "' type='text' class='txtbox' /></div></div>"
document.getElementById("post" + p2edit.id.substring(4,p2edit.id.length)).innerHTML+=tmpehtml;
//document.getElementById("titletbedit"+uidedit).value=posts[uidedit].getElementsByTagName("Titles")[0].childNodes[0].nodeValue;
//document.getElementById("commenttbedit"+uidedit).value=posts[uidedit].getElementsByTagName("Comment")[0].childNodes[0].nodeValue;
//document.getElementById("linktbedit"+uidedit).value=posts[uidedit].getElementsByTagName("URL")[0].childNodes[0].nodeValue;
document.getElementById("hdftv").innerHTML=posts[uidedit].getElementsByTagName("Titles")[0].childNodes[0].nodeValue;
document.getElementById("titletbedit"+uidedit).value=document.getElementById("hdftv").textContent;
document.getElementById("hdftv").innerHTML=posts[uidedit].getElementsByTagName("Comment")[0].childNodes[0].nodeValue;
document.getElementById("commenttbedit"+uidedit).innerHTML=document.getElementById("hdftv").textContent;
document.getElementById("hdftv").innerHTML=posts[uidedit].getElementsByTagName("URL")[0].childNodes[0].nodeValue;
document.getElementById("linktbedit"+uidedit).value=document.getElementById("hdftv").textContent;
divedit(totalid[p2edit.id.substring(4,p2edit.id.length)]);
}
else
{if (wkingedit==0)
{
wkingedit=1;
hidedit(totalid[p2edit.id.substring(4,p2edit.id.length)]);
}
}
}

var wkingdel=0;
function delp(p2del)
{
dopenl=1;

if (wkingdel==0)
{
wkingdel=1;
xmlhttp=new XMLHttpRequest();
xmlhttp.open("GET","remove_links.php?UID=" + encodeURIComponent(uid) + "&LID=" + encodeURIComponent(p2del.id.substring(3,p2del.id.length)) ,true);
xmlhttp.send();
xmlhttp.onreadystatechange=function()
{
if (xmlhttp.readyState==4 && xmlhttp.status==200)
{
	if (xmlhttp.responseText>=0)
	{
		deldiv(xmlhttp.responseText,totalp);
		xmlres.documentElement.removeChild(xmlres.getElementsByTagName("Link")[totalid[xmlhttp.responseText]]);
	}
	else
	{
		wkingdel=0;
//		alert(xmlhttp.responseText);
	}
}
}}}

var wkingnew=0;
function postnewl()
{
	if(document.getElementById('titletb').value=="" || document.getElementById('commenttb').value=="" || document.getElementById('linktb').value=="")
	{
	document.getElementById("newcon").style.backgroundColor="#ffb9c9";
	setTimeout("document.getElementById('newcon').style.backgroundColor='#fff';",2000);
	}
	else{
if (wkingnew==0)
{
wkingnew=1;
xmlhttp=new XMLHttpRequest();
xmlhttp.open("GET","add_link.php?UID=" + encodeURIComponent(uid) + "&Title=" + encodeURIComponent(document.getElementById('titletb').value) + "&Comment=" + encodeURIComponent(document.getElementById('commenttb').value) + "&Link=" + encodeURIComponent(document.getElementById('linktb').value) + "&Rating=" + encodeURIComponent(setnewrate) ,true);
xmlhttp.send();
xmlhttp.onreadystatechange=function()
{
if (xmlhttp.readyState==4 && xmlhttp.status==200)
{
	if (xmlhttp.responseText==1)
	{
		greenbacknp();
		loadp();
	}
	else
	{
		wkingnew=0;
	document.getElementById("newcon").style.backgroundColor="#ffb9c9";
	setTimeout("document.getElementById('newcon').style.backgroundColor='#fff';",2000);
	}
}
}
}
}
}

var setnewrate=0.5;
function prate(senstar)
{
setnewrate=senstar.id.substring(6,7);
for (j=1;j<=parseInt(setnewrate)-1;j++)
{
document.getElementById("npstar"+j).style.opacity=1;
}
for (j=parseInt(setnewrate)+1;j<=5;j++)
{
document.getElementById("npstar"+j).style.opacity=0;
}
if (senstar.style.opacity==0.5)
{
setnewrate=parseInt(setnewrate);
senstar.style.opacity=1;
}
else
{
setnewrate=parseInt(setnewrate) - 0.5;
senstar.style.opacity=0.5;
}
document.getElementById('newrate').title=setnewrate;
}

function textCounter(field,countfield,maxlimit) {
	field.value=field.value.replace(/\n/,' ');
  if ( field.value.length > maxlimit )
  {
    field.value = field.value.substring( 0, maxlimit );
    return false;
  }
  else
  {
    countfield.innerHTML= maxlimit - field.value.length;
  }
}

function eprate(senestar)
{
var rate2ret=senestar.id.substring(6,7);
var p2eid=senestar.id.substring(7,senestar.length);
for (j=1;j<=parseInt(rate2ret)-1;j++)
{
document.getElementById("epstar"+j+p2eid).style.opacity=1;
}
for (j=parseInt(rate2ret)+1;j<=5;j++)
{
document.getElementById("epstar"+j+p2eid).style.opacity=0;
}
if (senestar.style.opacity==0.5)
{
rate2ret=parseInt(rate2ret);
senestar.style.opacity=1;
}
else
{
rate2ret=parseInt(rate2ret) - 0.5;
senestar.style.opacity=0.5;
}
document.getElementById('editrate' + p2eid).title=rate2ret;
}

function seterate(pid2s)
{
var tval=posts[pid2s].getElementsByTagName("Rating")[0].childNodes[0].nodeValue;
for (j=1;j<=parseInt(tval);j++)
{
document.getElementById("epstar"+j+pid2s).style.opacity=1;
}
for (j=parseInt(tval)+1;j<=5;j++)
{
document.getElementById("epstar"+j+pid2s).style.opacity=0;
}
if (tval - parseInt(tval)!=0)
{
document.getElementById("epstar"+(parseInt(tval)+1)+pid2s).style.opacity=0.5;
}
return tval;
}

var editscw=0;
var saveintr=0;
function dsedit(sen2dedit)
{
if (editscw==0)
{
if (saveintr==0)
{
if(document.getElementById('titletbedit'+sen2dedit).value=="" || document.getElementById('commenttbedit'+sen2dedit).value=="" || document.getElementById('linktbedit'+sen2dedit).value==""){
document.getElementById('post' + totalp[sen2dedit]).style.backgroundColor='#ffb9c9';
setTimeout("document.getElementById('post"+totalp[sen2dedit]+"').style.backgroundColor='';editscw=0;",2000)
}
else
{
saveintr=1;
editscw=1;

xmlhttp=new XMLHttpRequest();
xmlhttp.open("GET","update_links.php?UID=" + encodeURIComponent(uid) + "&LID=" + encodeURIComponent(totalp[sen2dedit]) + "&Title=" + encodeURIComponent(document.getElementById('titletbedit'+sen2dedit).value) + "&Comment=" + encodeURIComponent(document.getElementById('commenttbedit'+sen2dedit).value) + "&Link=" + encodeURIComponent(document.getElementById('linktbedit'+sen2dedit).value) + "&Rating=" + encodeURIComponent(document.getElementById('editrate'+sen2dedit).title),true);
xmlhttp.send();
xmlhttp.onreadystatechange=function()
{
if (xmlhttp.readyState==4 && xmlhttp.status==200)
{
if (xmlhttp.responseText!=0)
{
xmlresoe= xmlhttp.responseText;
parser = new DOMParser();
xmlresoe = parser.parseFromString(xmlresoe,"text/xml");
document.getElementById("post"+totalp[sen2dedit]).onclick=function(){openl(xmlresoe.getElementsByTagName("Link")[0].getElementsByTagName("URL")[0].childNodes[0].nodeValue,this)};
document.getElementById("pvtitle"+totalp[sen2dedit]).innerHTML=xmlresoe.getElementsByTagName("Link")[0].getElementsByTagName("Titles")[0].childNodes[0].nodeValue;
document.getElementById("pvdate"+totalp[sen2dedit]).innerHTML=xmlresoe.getElementsByTagName("Link")[0].getElementsByTagName("Ldate")[0].childNodes[0].nodeValue;
document.getElementById("pvcom"+totalp[sen2dedit]).innerHTML=checkurlf(xmlresoe.getElementsByTagName("Link")[0].getElementsByTagName("Comment")[0].childNodes[0].nodeValue);
posts[sen2dedit].getElementsByTagName("Titles")[0].childNodes[0].nodeValue=xmlresoe.getElementsByTagName("Link")[0].getElementsByTagName("Titles")[0].childNodes[0].nodeValue;
posts[sen2dedit].getElementsByTagName("Comment")[0].childNodes[0].nodeValue=xmlresoe.getElementsByTagName("Link")[0].getElementsByTagName("Comment")[0].childNodes[0].nodeValue;
posts[sen2dedit].getElementsByTagName("URL")[0].childNodes[0].nodeValue=xmlresoe.getElementsByTagName("Link")[0].getElementsByTagName("URL")[0].childNodes[0].nodeValue;
var raeditval=xmlresoe.getElementsByTagName("Link")[0].getElementsByTagName("Rating")[0].childNodes[0].nodeValue;
var rvaedHTML="";
for (j=1;j<=parseInt(raeditval);j++)
{
rvaedHTML+="<div class='star' style='opacity:1'></div>";
}
if (parseInt(raeditval)<5)
{
rvaedHTML+="<div class='star' style='opacity:" + (raeditval - parseInt(raeditval)) + "'></div>";
}
for (j=1;j<=(6-parseInt(raeditval));j++)
{
rvaedHTML+="<div class='star' style='opacity:0'></div>";
}
document.getElementById("pvrate"+totalp[sen2dedit]).innerHTML=rvaedHTML;
posts[sen2dedit].getElementsByTagName("Rating")[0].childNodes[0].nodeValue=raeditval;
document.getElementById("pvrttl"+totalp[sen2dedit]).title=raeditval;
document.getElementById('post'+totalp[sen2dedit]).style.backgroundColor='#c1ffc1';
saveintr=0;
setTimeout("document.getElementById('post"+totalp[sen2dedit]+"').style.backgroundColor=''",2000)
editscw=0;
hidedit(sen2dedit,1);
}
}
else
{
if (saveintr==0)
{
document.getElementById('post' + totalp[sen2dedit]).style.backgroundColor='#ffb9c9';
setTimeout("document.getElementById('post"+totalp[sen2dedit]+"').style.backgroundColor='';editscw=0;",2000)
}
}
}
}
}
}
}
function dosin()
{
//	username//password
xmlhttp=new XMLHttpRequest();
xmlhttp.open("GET","login.php?username=" + encodeURIComponent(document.getElementById("unamel").value) + "&password=" + encodeURIComponent(document.getElementById("upassl").value),true);
xmlhttp.send();
xmlhttp.onreadystatechange=function()
{
if (xmlhttp.readyState==4 && xmlhttp.status==200)
{
var valaln1=xmlhttp.responseText.substring(0,1);
var valaln2=xmlhttp.responseText.substring(1,1);
if(valaln1==1)
{
document.getElementById("signin").style.backgroundColor="#c1ffc1";
//backsignf(1,valaln2);
setTimeout(function(){$("body").animate({opacity:0},175,function(){window.location.reload();});},500);
}else{
if(valaln1==0 || valaln1==2)
{
document.getElementById("signin").style.backgroundColor="#ffb9c9";
setTimeout("document.getElementById('signin').style.backgroundColor='#fff';",2000);
}
}
}
}
}
function loutf()
{
xmlhttp=new XMLHttpRequest();
xmlhttp.open("GET","logout.php",true);
xmlhttp.send();
xmlhttp.onreadystatechange=function()
{
if (xmlhttp.readyState==4 && xmlhttp.status==200)
{
	$("body").animate({opacity:0},175,function(){window.location.reload();});
}
}
}
function tblen(tbidsed,tbsen)
{
	if (tbidsed.innerHTML.length>500)
	{
		if (tbsen=='commenttb')
		{
			document.getElementById("newcon").style.backgroundColor="#ffb9c9";
		}
		else
		{
			document.getElementById('post' + totalp[tbsen]).style.backgroundColor='#ffb9c9';
		}
	}
	else
	{
		if (tbsen=='commenttb')
		{
			document.getElementById("newcon").style.backgroundColor="";
		}
		else
		{
			document.getElementById('post' + totalp[tbsen]).style.backgroundColor='';
		}
	}
}
function checkurlf(t2ch)
{
var exr = /(ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/gi;
var regex = new RegExp(exr);
if (t2ch.match(regex))
{
for (zz=0;zz<=t2ch.match(regex).length-1;zz++)
{
var exturli = t2ch.match(regex)[zz];
t2ch=t2ch.replace(t2ch.match(regex)[zz],'<span class="sourl" onclick="dopenl=1;window.open('+"'"+exturli+"','_blank');"+'">'+t2ch.match(regex)[zz]+"</span>");
}}
return t2ch;
}
var idsu=0;
var ierip=0;
function dosinu()
{
if(idsu==0){idsu=1;
document.getElementById('unamer').style.backgroundColor='#fff';
document.getElementById('upassr').style.backgroundColor='#fff';
document.getElementById('rupassr').style.backgroundColor='#fff';
document.getElementById('emailr').style.backgroundColor='#fff';
$('.ertxt').animate({opacity:0},250);
xmlhttp=new XMLHttpRequest();
xmlhttp.open("GET","register.php?Username=" + encodeURIComponent(document.getElementById("unamer").value) + "&Password=" + encodeURIComponent(document.getElementById("upassr").value) + "&RePassword=" + encodeURIComponent(document.getElementById("rupassr").value) + "&Email=" + encodeURIComponent(document.getElementById("emailr").value),true);
xmlhttp.send();
xmlhttp.onreadystatechange=function()
{
if (xmlhttp.readyState==4 && xmlhttp.status==200)
{
var regtxtr=xmlhttp.responseText;
if (regtxtr=="--1"){window.location.reload();}else{
if (regtxtr=="Done")
{
$('.ertxt').animate({opacity:0},250);
document.getElementById('unamer').style.backgroundColor='#fff';
document.getElementById('upassr').style.backgroundColor='#fff';
document.getElementById('rupassr').style.backgroundColor='#fff';
document.getElementById('emailr').style.backgroundColor='#fff';
document.getElementById("signup").style.backgroundColor="#c1ffc1";
setTimeout(function(){$("body").animate({opacity:0},175,function(){window.location.reload();});},750);
}
else
{
	regtxtr=regtxtr.split("#",4);
	if(regtxtr[0]!=" ")
	{
		document.getElementById('unamer').style.backgroundColor='#ffb9c9';
	}else{document.getElementById('unamer').style.backgroundColor='#c1ffc1';}
	if(regtxtr[1]!=" ")
	{
		ierip=1;
		document.getElementById('upassr').style.backgroundColor='#ffb9c9';
	}else{document.getElementById('upassr').style.backgroundColor='#c1ffc1';ierip=0;}
	if(regtxtr[2]!=" ")
	{
		if(ierip==1){regtxtr[2]="  ";}
		document.getElementById('rupassr').style.backgroundColor='#ffb9c9';
	}else{document.getElementById('rupassr').style.backgroundColor='#c1ffc1';}
	if(regtxtr[3]!=" ")
	{
		document.getElementById('emailr').style.backgroundColor='#ffb9c9';
	}else{document.getElementById('emailr').style.backgroundColor='#c1ffc1';}
	for(j=0;j<4;j++)
	{
		document.getElementById('ertxt'+j).innerHTML=regtxtr[j];
	}
	$('.ertxt').animate({opacity:1},250,function(){idsu=0;});
}
}
}
}
}
}
function setwb(sentsw,sentsie)
{
	sentsw.style.backgroundColor="#fff";
	$('#ertxt'+sentsie).animate({opacity:0},250,function(){
	document.getElementById('ertxt'+sentsie).innerHTML="";
	});
}