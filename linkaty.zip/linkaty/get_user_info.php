<?php 
header("Content-Type: text/xml");
$xml = new SimpleXMLElement('<xml/>');

if ((int)$_GET['UID'])

{
	$UID = (int)$_GET['UID'];
	$sql ="select  Username, Pic, Bio FROM users WHERE UID =".$UID." AND UserDelete =0";
	require_once ('db_con.php');
	if (!$result = mysql_query($sql))
	{
		die('Could not connect: ' . mysql_error());
	}
	else
	{
		//echo "connect sucssed to table</br>";
	}
	$row = mysql_fetch_assoc($result);
	$User = $xml->addChild('User');		
	$User->addChild('UID',$UID);
	$User->addChild('Username',$row['Username']);
	$User->addChild('Pic',$row['Pic']);
	$User->addChild('Bio',$row['Bio']);
	echo $xml->asXML();
	
	mysql_free_result($result);
	mysql_close($con);
}
?>