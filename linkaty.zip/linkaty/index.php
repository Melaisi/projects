<?php 
function check_login(){
	session_start();
	if (isset($_SESSION['UID'])){
		return TRUE;
		}
	else {
		return FALSE;
		}
}
//check page 
if (isset($_GET['username'])){
		//check DB 
		$username = htmlspecialchars($_GET['username']);
		$sql ="select UID from users WHERE Username='".$username."' AND UserDelete =0";
		include('db_con.php');
		if (!$result = mysql_query($sql))
		{
			die('Could not connect: ' . mysql_error());
		}
		else
		{
			//echo "connect sucssed to table</br>";
		}
		if (mysql_num_rows($result) ==1){
			$row = mysql_fetch_assoc($result);
			$PUID = $row['UID'];
		}
		else {
			//header("Location: index.php");
			header("Location: /");
			}
		mysql_free_result($result);
		mysql_close($con);
}
else {
	//check login 
	if (check_login()){
		//True go to index.php?username=Username
		//get user name from DB;
		$UID = $_SESSION['UID'];
		$sql ="select  Username FROM users WHERE UID =".$UID." AND UserDelete =0";
		include('db_con.php');
		if (!$result = mysql_query($sql))
		{
			die('Could not connect: ' . mysql_error());
		}
		else
		{
			//echo "connect sucssed to table</br>";
		}
		if (mysql_num_rows($result) ==1){
			$row = mysql_fetch_assoc($result);
			$Username=$row['Username'];
			header("Location: index.php?username=".$Username);
		}
		mysql_free_result($result);
		mysql_close($con);
}
else { //False set stts=1
	//$status=1;
}
}?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Linkaty</title>
<link rel="stylesheet" type="text/css" href="styles.css" />
<LINK rel="shortcut icon" href="http://linkaty.co.cc/img/av/icon.ico"> 
<script type="text/javascript">//uid=1;stts=0;</script>
<script type="text/javascript" src="javascript.js"></script>
<script type="text/javascript" src="jquery.js"></script>
<script type="text/javascript">
<?php
//login + his page status=2
//login + another page status =1
//logut + another page status =0
//logout + erorr page status =3 puid=0
if (isset($PUID)){
	echo "uid=".$PUID.";\n";
	if (check_login())//check login 
	{ 	//True check puid = uid 
		if($PUID == $_SESSION['UID'])
			{//True set stts=2 //login + his page status=2
				$status=2;
			}
		else{//false set stts=3 //login + another page status =1
				$status=1;
			}
	}
	else {//false set stts=3 //logut + another page status =0
			$status=0;
	}
}
else {
	if (check_login())//check login 
		{//True go to index.php?username=Username
			$UID = $_SESSION['UID'];
			$sql ="select  Username FROM users WHERE UID =".$UID." AND UserDelete =0";
			include('db_con.php');
			if (!$result = mysql_query($sql))
			{
				die('Could not connect: ' . mysql_error());
			}
			else
			{
				//echo "connect sucssed to table</br>";
			}
			if (mysql_num_rows($result) ==1){
				$row = mysql_fetch_assoc($result);
				$Username=$row['Username'];
				//header("Location: index.php?username=".$Username);
				header("Location: /".$Username);
			}
			mysql_free_result($result);
			mysql_close($con);
			
		}
		else {
				
				echo "uid=0;\n";
				$status = 3;
			}
}
if (isset($status))
	{
		echo "stts=".$status.";\n";
	}
?>
</script>
<script type="text/javascript"> 
var olduboxy;
function newp(){
	if (opng==0)
	{
	opng=1;
    $("#user").animate({opacity:0},250,function(){
	$("#user").hide();
	$("#newcon").show();
    $("#newcon").animate({opacity:1},175,function(){
	$("#newcon").animate({height:200},175,function(){
	$("#htarea").show();
	$("#newcnt,.dbtn").animate({opacity:1},300,function(){
	wkingnew=0;
	opng=0;
	});
	});
	});
	});
	}
}
var opng=0;
function backnewp(){
	if (opng==0)
	{
		opng=1;
	$("#newcnt,.dbtn").animate({opacity:0},300,function(){
	$("#htarea").hide();
	$("#newcon").animate({height:128},175);
	$("#newcon").animate({opacity:0},175,function(){
	$("#newcon").hide();
	$("#user").show();
	$("#user").animate({opacity:1},250,function(){
		opng=0;
	});
	});
	});
	}}
function greenbacknp()
{
	document.getElementById("user").style.backgroundColor="#c1ffc1";
	backnewp();
	setTimeout("document.getElementById('user').style.backgroundColor='#fff';",2000);
}
function deldiv(sen2del,totalp){
	document.getElementById('post' + sen2del).style.backgroundColor='#ffb9c9';
	$("#post" + sen2del).animate({opacity:1},500,function(){
	$("#post" + sen2del).animate({opacity:0},250,function(){
	if (totalp.length==1){$heightval=31;}else{$heightval=0;}
	$("#post" + sen2del).animate({height:$heightval},175,function(){
	document.getElementById('post' + sen2del).parentNode.removeChild(document.getElementById('post' + sen2del));
	viewp();
	wkingdel=0;
	try{
	document.getElementById('nopsts').style.opacity=0;}catch(er){}
	$(".noposts").animate({opacity:1},250)
	});
	});
	});
}
function divedit(sen2edit)
{
	
	document.getElementById('post'+totalp[sen2edit]).style.backgroundColor='#e8f4fb';
	document.getElementById('editrate'+sen2edit).title=seterate(sen2edit);
	$("#pedit" + sen2edit).animate({height:150},250,function(){
	$("#pedit" + sen2edit).animate({opacity:1},250);
	wkingedit=0;
	});
}
function hidedit(sen2hide,dup)
{
	if (editscw==0){
	editscw=1;
	if(dup!=1){document.getElementById('post'+totalp[sen2hide]).style.backgroundColor=''};
	$("#pedit" + sen2hide).animate({opacity:0},250,function(){
	$("#pedit" + sen2hide).animate({height:0},250,function(){
	document.getElementById('pedit' + sen2hide).parentNode.removeChild(document.getElementById('pedit' + sen2hide));
	dup=0;
	wkingedit=0;
	editscw=0;
	});
	});}
}
function signf(){
		if (opng==0)
	{
		opng=1;
    $("#user").animate({opacity:0},250,function(){
	$("#user").hide();
	$("#signin").show();
    $("#signin").animate({opacity:1},175,function(){
	$("#signcnt").animate({opacity:1},300);
	$("#signin").animate({height:107},175,function(){
		if (stts==3){signuf();}
	$(".dsbtn").animate({opacity:1},300,function(){
	opng=0;
	});
	});
	});
	});
	}
}
function backsignf(dwrld,nstts){
		if (opng==0)
	{
		opng=1;
	$(".dsbtn").animate({opacity:0},300,function(){
	$("#signin").animate({height:128},175);
	$("#signcnt").animate({opacity:0},300);
    $("#signin").animate({opacity:0},175,function(){
	$("#signin").hide();
	$("#user").show();
    $("#user").animate({opacity:1},250,function(){
		opng=0;
	});
	});
	});
}}
function signuf(){
	$("#signup").show();
	$("#signup").animate({height:211},175,function(){
	$("#signupcnt").show();
	$("#signupcnt").animate({opacity:1},300);
    $("#signup").animate({opacity:1},175,function(){
	$(".dsubtn").animate({opacity:1},300,function(){
	});
	});
	});
}
</script> 
<div id="hdftv" style="display:none"></div>
</head>
<body onload="getuinf()">
<center>
<div id="centerol">
<div class="user signcnt" id="signin" style="opacity:0;display:none;">
<div class="dsbtn" onclick="dosin();" style="opacity:0;top:143px;">دخول</div>
<div id="sbah" class="dsbtn backsbtn" onclick="backsignf()" style="opacity:0;top:143px;">×</div>
<div class="frmtitle">تسجيل الدخول</div>
<div id="signcnt" class="signcnt" style="opacity:0;">
<div class="tboxline"><div class="signttl">اسم المستخدم</div><div><input id="unamel" type="text" class="txtbox" maxlength="50"/></div></div>
<div class="tboxline"><div class="signttl">كلمة المرور<div id="deschars" class="tboxttl"></div></div><div><input id="upassl" type="password" class="txtbox" maxlength="50"/></div></div>
</div></div>
<!======= Signup =======!>
<div class="user signcnt" id="signup" style="opacity:0;display:none;">
<div class="dsubtn" onclick="dosinu();" style="opacity:0;top:247px;">تسجيل</div>
<div class="frmtitle">التسجيل</div>
<div id="signupcnt" class="signcnt" style="opacity:0;display:none;">
<div class="tboxline"><div class="signttl">اسم المستخدم</div><div><input onchange="setwb(this,0)" id="unamer" type="text" class="txtbox" maxlength="50"/><div class="ertxt" id="ertxt0"></div></div></div>
<div class="tboxline"><div class="signttl">كلمة المرور<div id="deschars" class="tboxttl"></div></div><div><input onchange="setwb(this,1)" id="upassr" type="password" class="txtbox" maxlength="50"/><div class="ertxt" id="ertxt1"></div></div></div>
<div class="tboxline"><div class="signttl">تأكيد الكلمة<div id="deschars" class="tboxttl"></div></div><div><input onchange="setwb(this,2)" id="rupassr" type="password" class="txtbox" maxlength="50"/><div class="ertxt" id="ertxt2"></div></div></div>
<div class="tboxline"><div class="signttl">الإيميل</div><div><input onchange="setwb(this,3)" id="emailr" type="text" class="txtbox" maxlength="50"/><div class="ertxt" id="ertxt3"></div></div></div>
</div></div>
<!=================!>
<div class="user" id="newcon" class="newcnt" style="opacity:0;display:none;">
<div class="dbtn" onclick="postnewl()" style="opacity:0;">إضافة</div>
<div class="dbtn backbtn" onclick="backnewp()" style="opacity:0;">×</div>
<div id="newcnt" style="opacity:0;">
<div class="frmtitle">مشاركة جديدة</div>
<div class="tboxline"><div class="tboxttl">العنوان</div><div><input id="titletb" type="text" class="txtbox"/>
<div class="tboxttl" style="float:left;position:relative;left:140px;">التقييم</div>
<div class="newprate" id="newrate" title="0.5">
<div class="star" id="npstar1" onclick="prate(this)" style="opacity:0.5"></div>
<div class="star" id="npstar2" onclick="prate(this)"></div>
<div class="star" id="npstar3" onclick="prate(this)"></div>
<div class="star" id="npstar4" onclick="prate(this)"></div>
<div class="star" id="npstar5" onclick="prate(this)"></div></div></div></div>
<div id="htarea" style="display:none;">
<div class="tboxline"><div class="tboxttl">الوصف<div id="deschars" class="tboxttl"></div></div><div><textarea id="commenttb" class="txtbox" style="height:67px;width:425px;overflow:hidden;" onkeyup="tblen(this,this.id)" maxlength='500'></textarea></div></div>
</div>
<div class="tboxline"><div class="tboxttl">الرابط</div><div><input id="linktb" type="text" class="txtbox"/></div></div>
</div>
</div>

<div class="user" id="user">
</div>
<div id="postscont">
</div>
<div id="rtext">© 2012</div>
</div>
</center>
<form id="asdf" method="post">
</form>
</body>
</html>