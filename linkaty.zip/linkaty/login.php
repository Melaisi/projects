<?php

function div_form(){
	
	echo '
		<html>
	<head><title>Linkat - Login</title></head>
	<body>
	<div id="login_form">
	<form id="login" action="login.php" method="get">
	Username : <input id="username" type="text" name="username" /><br>
	Password : <input id="password" type="password" name="password" /><br>
	<input id="submit" type="submit" name="submit"  />
	</form>
	</div>
	</body>
	</html>
		';
}

function db_check_login()
{
	$username = $_GET['username'];
	$password = $_GET['password'];
	
	$sql = "
		select UID from users WHERE `Username`='".$username."' AND `Password`=md5('".$password."') 	
	";
	
	require_once ('db_con.php');
	
	if (!$result = mysql_query($sql))
	{
		return FALSE;
	}
	else
	{	
		if (mysql_num_rows($result) == 1) {
			$row = mysql_fetch_assoc($result);
			global $UID,$db_username;
			$UID = $row['UID'];
			$db_username = $row['Username'];
			return TRUE;
		}
		else {
			return FALSE;
			}
	}
	}
	
function set_SESSIONS(){
	
	$expire_cookie = 60*60*24*30*6;
	session_set_cookie_params($expire_cookie);
	session_start();
	
	$_SESSION['UID'] = $UID;
	
	
	}
//////////////////////////////////////
if (!isset($_GET['username']) || !isset($_GET['password']) /* || !isset($_GET['submit'])*/ )
{
	//div_form();
	echo 0;
	}
	
else {
	
	if(db_check_login())
	{
		set_SESSIONS();
		//header("Location: index.php");
		echo 1;
		}
	else{
		
		//div_form();	
		echo 2;
	}
	
	}
	

