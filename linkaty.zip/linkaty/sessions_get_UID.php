<?php 
	session_start();

if (isset($_SESSION['UID']))
	{
		echo "Welcom {$_SESSION['UID']}";
		
		}
else {
	echo "plese login first ";
	}
?>