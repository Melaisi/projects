<?php 

//old code:

/* 

header("Content-Type: text/xml");

//$xml = new SimpleXMLElement('<xml/>');

$xml = new SimpleXMLElement('<xml/>');

if ($_GET['UID'])

{	$UID = (int)$_GET['UID'];

	require_once('db_con.php');

	$sql ="select LID, Title, Link, Rating, Comment, Ldate FROM links WHERE UID =".$UID." AND Status =0 order by `LID` DESC";

	$result = mysql_query($sql);

	while ($row = mysql_fetch_assoc($result)) {

	$Link = $xml->addChild('Link');		

	$Link->addChild('LID',$row['LID']);

	$Link->addChild('Titles',$row['Title']);

	// temp line {

	//$row['Link'] = "http://".$row['Link'];

	//$row['Link'] = htmlentities($row['Link'] );

	// }

	$Link->addChild('URL',htmlentities($row['Link']));

	$Link->addChild('Comment',$row['Comment']);

	$Link->addChild('Rating',$row['Rating']);

	$Link->addChild('Ldate',$row['Ldate']);

}

echo $xml->asXML();

mysql_free_result($result);

mysql_close($con);

}

*/

?><?php 

header("Content-Type: text/xml");



$UID =$_GET['UID'];

$sql ="select * FROM links WHERE UID =".$UID." AND Status =0 order by `LID` DESC";

//echo "SQL = ".$sql."</br>";



require_once ('db_con.php');

if (!$result = mysql_query($sql))

{

	die('Could not connect: ' . mysql_error());

}

else

{

//echo "connect sucssed to table</br>";

}

$xml = new SimpleXMLElement('<xml/>');

while ($row = mysql_fetch_assoc($result)) {

	$Link = $xml->addChild('Link');	

	$Link->addChild('LID',$row['LID']);;

	$Link->addChild('Titles',htmlspecialchars($row['Title']));

//	$Link->addChild('URL',htmlentities($row['Link']));

	$Link->addChild('URL',htmlspecialchars($row['Link']));

	$Link->addChild('Comment',htmlspecialchars($row['Comment']));

	$Link->addChild('Rating',$row['Rating']);

	$Link->addChild('Ldate',$row['Ldate']);

}

echo $xml->asXML();



?>