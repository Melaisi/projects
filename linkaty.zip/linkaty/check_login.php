<?php 
session_start();
if (isset($_SESSION['UID']))
{
	echo "1";
	}
else 
{
	echo "0";
	}

?>