<? 
/// بيانات قاعدة البيانات العامة 

$db_server = "sql301.byethost2.com";
$db_name = "b2_9967847_db1";
$db_user = "root";
$db_password ="";


?>
