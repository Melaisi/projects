<?

/// This page to add link 

/// recive necessary  :  

///   1- UID

///   2- :/

///   3- Title 

///   4- Link

/// recive if exist 

///   1- Rateing

///   2- Comment

/// return :

///   1- echo 0; for errors. 

///   2- echo 1; for successed.



if ( !$_GET['UID'] || !$_GET['Title'] || !$_GET['Link'] )

{

	//echo "some thing messing UID , Title , Link !";

	}



else 
{
	//check login
	session_start();
	if (isset($_SESSION['UID']))
	{
		if ((int)$_GET['UID'] != $_SESSION['UID'])
		{
			echo "Access Denied";
			exit;
		}
		else 
		{
			/// varabiles and sql query to add the row:
				require_once('db_con.php');
				$UID = (int)$_GET['UID'] ;
				$Link = htmlspecialchars($_GET['Link']);
				//$Title = iconv('cp1256','utf-8',$_GET['Title']);
				$sql = "INSERT INTO links (UID ,Link, Title ";
				if ($_GET['Comment'])
				{
					$sql .=", Comment";
					}
					if ((float)$_GET['Rating'])
				{
					$sql .=", Rating";
					}
					//$sql .=") VALUES ( ".$UID." , '".$Link."' , (_utf8'".$Title."')";
				$sql .=") VALUES ( ".$UID." , '".$Link."' ,'". htmlspecialchars($_GET['Title'])."'";
				if ($_GET['Comment'])
				{
					//$Comment = iconv('cp1256','utf-8',$_GET['Comment']);
					//$sql .=", (_utf8'".$Comment."')";
					$sql .=",'".htmlspecialchars($_GET['Comment'])."'";
					}
					if ((float)$_GET['Rating'])
				{
					$sql .=", ".(float)$_GET['Rating'];
					}
					$sql .= ")";
				//echo $sql;
				/// Update :
				///  Connect to DB :
				if (!mysql_query($sql))
				{
					echo '0';
					}
					else
				{echo '1';}
				mysql_close($con);
		}
	}
	else 
	{
		echo "Access Denied";
		exit;
	}
}

?>