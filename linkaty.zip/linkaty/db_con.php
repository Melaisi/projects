<?
    
	require_once('db_config.php');
	$con = mysql_connect($db_server,$db_user,$db_password);
	if (!$con)
  		{
  			die('Could not connect: ' . mysql_error());
  		}
	// utf8 problem 
	
	//mysql_set_charset('utf8');
	//mysql_query("SET NAMES 'utf8'"); 
	//mysql_query('SET CHARACTER SET utf8');
	
	mysql_set_charset('utf8',$con);
	mysql_select_db ($db_name,$con);
	
	?>